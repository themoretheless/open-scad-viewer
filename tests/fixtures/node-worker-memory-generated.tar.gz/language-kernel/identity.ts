// Generated from the packaged WASM; not qualification evidence.
export default Object.freeze({"sha256":"d25ff0c3ac54b0ecbdf7706b99dbd2a5519fad4ef35d2de25386ac1ef3a3b897","byteLength":2578722})
