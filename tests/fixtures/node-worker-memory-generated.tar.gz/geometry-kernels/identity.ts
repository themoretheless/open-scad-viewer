// Generated from the packaged WASM; not qualification evidence.
export default Object.freeze({"sha256":"1d13d91300a279b45cbcf552ee41369262f19bfc109a3d31f5ccaed325774676","byteLength":12198500})
