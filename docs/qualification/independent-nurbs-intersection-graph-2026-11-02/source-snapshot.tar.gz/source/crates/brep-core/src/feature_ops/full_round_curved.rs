//! Full Round construction on original rational profile supports of XY prisms.
//! Contact solving proposes; original stored surface proofs admit the result.
use super::{FullRoundReport, error, full_round_caps, full_round_seams};
use crate::{Model, Result, solid_audit::audit_solid};
use nurbs_core::{
    curve::Curve,
    offset::profile_corner::full_round::{self, Proposal},
};
use std::collections::BTreeSet;
pub mod source_cover;
pub use source_cover::SourceArcCover;
pub mod material_relation;
pub use material_relation::{NoAddedProfile, SourceProfileRelation};

pub struct CurvedFullRound {
    source: Model,
    proposal: Proposal,
    construction: FullRoundReport,
}
impl CurvedFullRound {
    pub fn source(&self) -> &Model {
        &self.source
    }
    pub fn proposal(&self) -> &Proposal {
        &self.proposal
    }
    pub fn construction(&self) -> &FullRoundReport {
        &self.construction
    }
    pub fn model(&self) -> &Model {
        &self.construction.model
    }
}
fn owns(source: &Model, face: usize, profile: &Curve, z: f64) -> Result<bool> {
    let f = source
        .faces
        .get(face)
        .ok_or_else(|| error("Unknown Full Round face"))?;
    let reverse = profile.reverse()?;
    for w in std::iter::once(f.outer).chain(f.holes.iter().copied()) {
        for c in &source.loops[w].coedges {
            let mut curve = crate::prism::directed_edge(source, c)?;
            if curve.control_points.iter().any(|p| p[2] != z) {
                continue;
            }
            for p in &mut curve.control_points {
                p.truncate(2);
            }
            if curve == *profile || curve == reverse {
                return Ok(true);
            }
        }
    }
    Ok(false)
}

/// Infer the three consecutive profile owners from original face identities.
/// The middle is straight; both flanking supports may be rational curves.
/// Every active span of the contact arcs is separately authored and qualified,
/// including all additional longitudinal joins and original side surfaces.
pub fn build(source: &Model, faces: [usize; 3]) -> Result<CurvedFullRound> {
    source.validate()?;
    if source.bodies.len() != 1
        || source.shells.len() != 1
        || faces.into_iter().collect::<BTreeSet<_>>().len() != 3
    {
        return Err(error(
            "Curved Full Round needs one source body and three distinct side faces",
        ));
    }
    let mut p = crate::prism::recognize(source)?
        .ok_or_else(|| error("Curved Full Round needs a proven XY prism"))?;
    let wire = &p.loops[0];
    let mut candidates = Vec::new();
    for (i, c) in wire.iter().enumerate() {
        if owns(source, faces[1], c, p.z_max)? {
            candidates.push(i);
        }
    }
    if candidates.len() != 1 || wire.len() < 4 {
        return Err(error(
            "Curved Full Round middle must own one complete outer profile segment",
        ));
    }
    let i = candidates[0];
    let prev = (i + wire.len() - 1) % wire.len();
    let next = (i + 1) % wire.len();
    let bound = (owns(source, faces[0], &wire[prev], p.z_max)?
        && owns(source, faces[2], &wire[next], p.z_max)?)
        || (owns(source, faces[2], &wire[prev], p.z_max)?
            && owns(source, faces[0], &wire[next], p.z_max)?);
    if !bound {
        return Err(error(
            "Curved Full Round selected supports do not own the adjoining original curves",
        ));
    }
    let proposal = full_round::propose(
        &wire[prev],
        &wire[i],
        &wire[next],
        source.tolerance_mm / 32.,
    )?;
    let mut replacement = Vec::new();
    for (j, c) in wire.iter().enumerate() {
        if j == prev {
            replacement.push(proposal.incoming().clone());
        } else if j == i {
            replacement.extend(proposal.bridges().iter().cloned());
        } else if j == next {
            replacement.push(proposal.outgoing().clone());
        } else {
            replacement.push(c.clone());
        }
    }
    p.loops[0] = replacement;
    let mut model = crate::prism::extrude(&p.loops, p.z_min, p.z_max)?;
    full_round_caps::world_charts(&mut model)?;
    model.tolerance_mm = source.tolerance_mm;
    model.inherit_topology_ids(&[source]);
    model.validate()?;
    let audit = audit_solid(&model)?;
    if !audit.ok {
        return Err(error("Curved Full Round solid audit remains unproven"));
    }
    let center = proposal.center();
    let mut nodes = Vec::new();
    let mut crown = 0;
    for (bridge, arc) in proposal.bridges().iter().enumerate() {
        let [lo, hi] = arc.domain();
        let mut cuts = arc
            .knots
            .iter()
            .copied()
            .filter(|t| *t >= lo && *t <= hi)
            .collect::<Vec<_>>();
        cuts.sort_by(f64::total_cmp);
        cuts.dedup();
        for pair in cuts.windows(2) {
            let span = arc.trim(pair[0], pair[1])?;
            if nodes.is_empty() {
                let p = &span.control_points[0];
                nodes.push([p[0], p[1]]);
            }
            let p = span.control_points.last().unwrap();
            nodes.push([p[0], p[1]]);
        }
        if bridge == 0 {
            crown = nodes.len() - 1;
        }
    }
    let endpoints = nodes
        .into_iter()
        .map(|q| [p.z_min, p.z_max].map(|z| [q[0], q[1], z]))
        .collect::<Vec<_>>();
    let centers = [p.z_min, p.z_max].map(|z| [center[0], center[1], z]);
    let tangency =
        full_round_seams::qualify_chain(&model, &endpoints, crown, centers, proposal.radius())?;
    Ok(CurvedFullRound {
        source: source.clone(),
        construction: FullRoundReport {
            model,
            replaced_face: faces[1],
            support_faces: [faces[0], faces[2]],
            radius_mm: proposal.radius(),
            audit,
            tangency,
        },
        proposal,
    })
}
