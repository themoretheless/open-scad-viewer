import assert from 'node:assert/strict';import {readFileSync,writeFileSync} from 'node:fs';import {createHash} from 'node:crypto';
import {encodeBinary,decodeBinary} from '/Users/themoretheless/.codex/worktrees/nurbs-rational-reduction/open-scad-viewer/src/services/valueBinaryCodec.ts';
const q='/Users/themoretheless/.codex/tmp/architecture-recovery-20261031',results=[];
for(const [variant,path]of [['installed-generated','src/generated/geometry-kernels/kernel_bg.wasm'],['current-stock',q+'/native252-stock-optimized.wasm'],['current-outlined-merge',q+'/native252-outline-merge.wasm']]){
 const wasm=readFileSync(path),module=await WebAssembly.compile(wasm);assert.deepEqual(WebAssembly.Module.imports(module),[]);const {exports:w}=await WebAssembly.instantiate(module,{}) as any;
 const cases=[];
 for(const file of ['progressive-hollow-boundary.r','progressive-unsegmented-hollow-boundary.r']){
  const raw=readFileSync(q+'/native252-cancellation-input-'+file+'.json'),input=JSON.parse(raw.toString()),data=encodeBinary(input),start=performance.now(),ptr=w.abi_alloc(data.length);let result:any;
  new Uint8Array(w.memory.buffer,ptr,data.length).set(data);
  try{const packed=w.abi_request(0,ptr,data.length),p=Number(packed&0xffffffffn),n=Number(packed>>32n);try{result=decodeBinary(new Uint8Array(w.memory.buffer,p,n));assert.deepEqual(new Uint8Array(w.memory.buffer,ptr,data.length),data);}finally{w.abi_free(p,n);}}finally{w.abi_free(ptr,data.length);}
  const proof=result.value;cases.push({file,faces:input.model.faces.length,requestBytes:data.length,inputSha256:createHash('sha256').update(raw).digest('hex'),ok:result.ok,error:result.error,proof:proof?Object.fromEntries(['solidGeometryCertified','boundaryEmbeddingCertified','allFacesInjective','allPairsClassified','nextPair','nesting','orientation'].map(k=>[k,proof[k]])):null,elapsedMs:performance.now()-start});
 }
 results.push({variant,path,wasmBytes:wasm.length,wasmSha256:createHash('sha256').update(wasm).digest('hex'),cases});writeFileSync(q+'/native252-cancellation-abi.json',JSON.stringify({status:'running',scope:'Same actual saved model/provenance re-audited through raw ABI of each explicit artifact. No old certificate or runtime admission transferred.',results},null,2)+'\n');
}
writeFileSync(q+'/native252-cancellation-abi.json',JSON.stringify({status:'terminal',scope:'Same actual saved model/provenance re-audited through raw ABI of each explicit artifact. No old certificate or runtime admission transferred.',results},null,2)+'\n');console.log(JSON.stringify(results));
