import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {compileRushFrontend} from '/Users/themoretheless/.codex/worktrees/nurbs-rational-reduction/open-scad-viewer/src/services/rushFrontend.ts';
import {buildOwnNurbsAsync} from '/Users/themoretheless/.codex/worktrees/nurbs-rational-reduction/open-scad-viewer/src/services/rushGraphNurbsKernel.ts';
import {readNativeGeometryData} from '/Users/themoretheless/.codex/worktrees/nurbs-rational-reduction/open-scad-viewer/src/services/nativeGeometrySnapshot.ts';
import {readSweepBodyBoundaryViewportEvidence} from '/Users/themoretheless/.codex/worktrees/nurbs-rational-reduction/open-scad-viewer/src/services/sweepViewportEvidence.ts';
import {inspectProgressiveSweepSolidAdmission} from '/Users/themoretheless/.codex/worktrees/nurbs-rational-reduction/open-scad-viewer/src/services/sweepSolidAdmission.ts';
const q='/Users/themoretheless/.codex/tmp/architecture-recovery-20261031',cases=[];
for(const file of ['progressive-hollow-boundary.r','progressive-unsegmented-hollow-boundary.r']){
 const source=readFileSync('examples/rush/'+file,'utf8').replace('initial_sections: 3,max_sections: 3','initial_sections: 65,max_sections: 65');const start=performance.now();
 try{
  const built=await buildOwnNurbsAsync(compileRushFrontend(source).document,{action:'build',display:{segments:2,subdivisionLevels:0}});
  const g=built.nativeGeometry;
  if(!g){cases.push({file,nativeGeometry:false,keys:Object.keys(built),elapsedMs:performance.now()-start});continue;}
  const model=readNativeGeometryData(g).geometry;writeFileSync(q+'/native252-cancellation-input-'+file+'.json',JSON.stringify({op:'brep_sweep_solid_admission',documentJson:g.documentJson,nodeId:g.nodeId,geometryJson:g.geometryJson,model})+'\n');const admission=inspectProgressiveSweepSolidAdmission(g,model);
  cases.push({file,nativeGeometry:true,faces:model.faces?.length,boundary:readSweepBodyBoundaryViewportEvidence(g),admission,elapsedMs:performance.now()-start});
 }catch(e){cases.push({file,error:String(e),stack:e instanceof Error?e.stack:null,elapsedMs:performance.now()-start});}
}
const wasm=readFileSync('public/wasm/geometry-kernel.wasm');writeFileSync(q+'/native252-cancellation-diagnostic.json',JSON.stringify({scope:'Current frontend and installed historical WASM diagnostic, not candidate artifact qualification',installedWasmSha256:createHash('sha256').update(wasm).digest('hex'),cases},null,2)+'\n');console.log(JSON.stringify(cases));
