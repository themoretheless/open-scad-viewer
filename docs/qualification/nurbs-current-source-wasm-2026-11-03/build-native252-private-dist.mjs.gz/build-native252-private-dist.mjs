import {readFileSync,writeFileSync,mkdirSync,existsSync,cpSync,readdirSync,statSync} from 'node:fs'
import {resolve,relative} from 'node:path';import {pathToFileURL} from 'node:url';import {createHash} from 'node:crypto';import assert from 'node:assert/strict'
const root=process.cwd(),q='/Users/themoretheless/.codex/tmp/architecture-recovery-20261031',out=resolve(q,'native252-candidate-private-dist')
assert(!existsSync(out));mkdirSync(out);cpSync(resolve(root,'public'),resolve(out,'public'),{recursive:true})
const pack=resolve(q,'native252-candidate-packed'),candidate=readFileSync(resolve(pack,'kernel_bg.wasm'))
writeFileSync(resolve(out,'public/wasm/geometry-kernel.wasm'),candidate)
const protectedPaths=['public/wasm/geometry-kernel.wasm','src/generated/geometry-kernels/identity.ts','src/generated/geometry-kernels/bytes.ts'],sha=b=>createHash('sha256').update(b).digest('hex'),before=protectedPaths.map(p=>sha(readFileSync(p)))
const {build,loadConfigFromFile}=await import(pathToFileURL(resolve(root,'node_modules/vite/dist/node/index.js')))
const loaded=await loadConfigFromFile({command:'build',mode:'production'},resolve(root,'vite.config.ts'),root);assert(loaded)
const config=loaded.config,workerPlugins=config.worker?.plugins
const plugin=()=>({name:'private-native252-payload',enforce:'pre',load(id){for(const file of ['identity.ts','bytes.ts'])if(id.split('?')[0]===resolve(root,'src/generated/geometry-kernels',file))return readFileSync(resolve(pack,file),'utf8')}})
await build({...config,configFile:false,root,publicDir:resolve(out,'public'),plugins:[plugin(),...(config.plugins??[])],worker:{...config.worker,plugins:()=>[plugin(),...(workerPlugins?.()??[])]},build:{...config.build,outDir:resolve(out,'dist'),emptyOutDir:true}})
const files=[];function walk(dir){for(const e of readdirSync(dir,{withFileTypes:true})){const p=resolve(dir,e.name);if(e.isDirectory())walk(p);else files.push({path:relative(resolve(out,'dist'),p),bytes:statSync(p).size,absolute:p})}}walk(resolve(out,'dist'))
const geometry=files.filter(f=>f.path.includes('geometry-kernel-bytes')&&f.path.endsWith('.js'));assert.equal(geometry.length,1)
const {verifyPackedWasmChunk,verifyUniquePackedWasm}=await import(pathToFileURL(resolve(root,'scripts/verify-packed-wasm.mjs')))
assert.equal(verifyPackedWasmChunk(readFileSync(geometry[0].absolute,'utf8'),candidate,'private-sept-dist'),candidate.length)
verifyUniquePackedWasm(files.filter(f=>f.path.endsWith('.js')).map(f=>({path:f.path,source:readFileSync(f.absolute,'utf8')})))
assert.deepEqual(protectedPaths.map(p=>sha(readFileSync(p))),before)
const report={wasmSha256:sha(candidate),geometryChunkBytes:geometry[0].bytes,totalAssetBytes:files.filter(f=>!/^wasm\/(geometry-kernel|language-kernel|photogrammetry)\.wasm$/.test(f.path)).reduce((s,f)=>s+f.bytes,0),artifacts:files.length,productionUnchanged:true,emittedWasmIdentityVerified:true,scope:'Private actual Vite asset measurement on current source and isolated candidate payload. No runtime/profile/admission/Worker/editor qualification; installed source artifacts remain unchanged.'}
writeFileSync(resolve(out,'measurement.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report))
