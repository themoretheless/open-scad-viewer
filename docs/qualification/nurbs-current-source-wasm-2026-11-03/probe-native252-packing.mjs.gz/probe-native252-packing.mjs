import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {brotliCompressSync,brotliDecompressSync,constants as c} from 'node:zlib';
const [input,output,strategy='midpoint',block='16',mode='2']=process.argv.slice(2);
if(!input||!output||!['midpoint','prefix'].includes(strategy))throw Error('input output [midpoint|prefix] [block] [mode]');
const wasm=readFileSync(input),sha=x=>createHash('sha256').update(x).digest('hex');
const state={status:'running',input:{path:input,bytes:wasm.length,sha256:sha(wasm)},strategy,block:Number(block),mode:Number(mode),productionAdmitted:false,decodedWithinCap:wasm.length<=16*1024*1024,scope:'Private compression measurement only; no installed artifacts, budget pins or production admission. Exact byte identity and existing stream bounds required.'};
const save=()=>writeFileSync(output+'.json',JSON.stringify(state,null,2)+'\n');save();
let at=8,split=wasm.length;
while(at<wasm.length){const id=wasm[at++];let length=0,shift=0,byte;do{if(at>=wasm.length||shift>28)throw Error('Invalid section');byte=wasm[at++];length+=(byte&127)*2**shift;shift+=7;}while(byte&128);at+=length;if(at>wasm.length)throw Error('Truncated section');if(id===10)split=at;}
const chunks=split<wasm.length?[wasm.subarray(0,split),wasm.subarray(split)]:[wasm];state.sections=chunks.map(x=>x.length);state.attempts=[];
const compress=chunk=>{const out=brotliCompressSync(chunk,{params:{[c.BROTLI_PARAM_QUALITY]:11,[c.BROTLI_PARAM_LGWIN]:24,[c.BROTLI_PARAM_LGBLOCK]:Number(block),[c.BROTLI_PARAM_MODE]:Number(mode)}});state.attempts.push({raw:chunk.length,compressed:out.length});save();return out;};
const limit=4*1024*1024;
function bounded(chunk){
 let packed=compress(chunk);if(packed.length<=limit)return [{raw:chunk,packed}];
 if(strategy==='midpoint'){const mid=Math.ceil(chunk.length/2);return [...bounded(chunk.subarray(0,mid)),...bounded(chunk.subarray(mid))];}
 let cut=Math.min(chunk.length-1,Math.max(1,Math.floor(chunk.length*limit/packed.length*0.97)));
 while(true){const prefix=chunk.subarray(0,cut);packed=compress(prefix);if(packed.length<=limit)return [{raw:prefix,packed},...bounded(chunk.subarray(cut))];if(cut===1)throw Error('Unencodable prefix');cut=Math.max(1,Math.floor(cut*0.9));}
}
const streams=chunks.flatMap(bounded);if(streams.length>8)throw Error('Too many streams');
for(const {raw,packed}of streams){if(packed.length>limit||!brotliDecompressSync(packed).equals(raw))throw Error('Roundtrip mismatch');}
if(!Buffer.concat(streams.map(s=>s.raw)).equals(wasm))throw Error('Coverage mismatch');
const header=Buffer.alloc(5+8*streams.length);header.writeUInt32LE(wasm.length+0x80000000);header[4]=streams.length;
streams.forEach(({raw,packed},i)=>{header.writeUInt32LE(raw.length,5+8*i);header.writeUInt32LE(packed.length,9+8*i);});
const packed=Buffer.concat([header,...streams.map(s=>s.packed)]);if(packed.length-4>8*1024*1024)throw Error('Compressed total exceeded');
writeFileSync(output+'.bin',packed);state.status='terminal';state.streams=streams.map(({raw,packed})=>({raw:raw.length,compressed:packed.length}));state.packed={bytes:packed.length,sha256:sha(packed)};state.encodedSeptUpperBound=12+7*Math.ceil(packed.length*8/48);state.nodeRoundtripByteIdentical=true;save();console.log(JSON.stringify(state,null,2));
