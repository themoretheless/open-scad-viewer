from pathlib import Path
import os,subprocess,json,datetime,hashlib,sys
q=Path('/Users/themoretheless/.codex/tmp/architecture-recovery-20261031')
root=Path('/Users/themoretheless/.codex/worktrees/nurbs-plan-recovery/open-scad-viewer')
node='/Users/themoretheless/.codex/tmp/architecture-recovery-20261031/node-runtime-22.23.4/node-v22.23.4-darwin-arm64/bin/node'
env=os.environ.copy();env.update(CARGO_TARGET_DIR='/Users/themoretheless/.codex/tmp/osv-nurbs-plan-target-recovery-20261028',CARGO_BUILD_JOBS='2',CARGO_PROFILE_TEST_OPT_LEVEL='1',RUST_TEST_THREADS='2')
commands=[('typed-no-codec',['cargo','check','--locked','--offline','--manifest-path','crates/Cargo.toml','-p','brep-core','-p','nurbs-intersect','-p','brep-intersect','--no-default-features']),('partition',[node,'scripts/verify-native-test-partition.mjs','output/qualification/native226-v10-test-catalog']),('aag',['cargo','test','--locked','--offline','--manifest-path','crates/Cargo.toml','--workspace','aag','--','--test-threads=1']),('remaining',['cargo','test','--locked','--offline','--manifest-path','crates/Cargo.toml','--workspace','--','--skip','aag'])]
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--','crates','rust-toolchain.toml'],cwd=root,text=True).split('\0')
manifest={name:hashlib.sha256((root/name).read_bytes()).hexdigest()for name in sorted(set(files)) if name and (root/name).is_file()};(q/'native226-v10-workspace-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
state={'scope':'Final Root226/runtimev10 OwnRust85 source; full workspace gates including typed no-codec, exact partition, serial AAG and every remaining workspace test. Earlier results are not imported.','sourcePaths':len(manifest),'commands':[],'env':{k:env[k]for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_PROFILE_TEST_OPT_LEVEL','RUST_TEST_THREADS']}}
state_path=q/'native226-v10-workspace-gates-state.json'
for name,cmd in commands:
 row={'name':name,'command':cmd,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','log':f'native226-v10-workspace-{name}-20261102.log'};state['commands'].append(row);state_path.write_text(json.dumps(state,indent=2)+'\n')
 with (q/row['log']).open('w')as log:result=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 row.update(status='terminal',exitCode=result.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());state_path.write_text(json.dumps(state,indent=2)+'\n');print(name,'exit',result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
state['sourceDrift']=[name for name,digest in manifest.items()if not(root/name).is_file()or hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest];state_path.write_text(json.dumps(state,indent=2)+'\n');sys.exit(1 if state['sourceDrift']else 0)
