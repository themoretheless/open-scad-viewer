use super::*;
fn plane() -> Surface {
    Surface {
        degree_u: 1,
        degree_v: 1,
        knots_u: vec![0., 0., 1., 1.],
        knots_v: vec![0., 0., 1., 1.],
        control_points: vec![
            vec![vec![0., 0., 0.], vec![0., 10., 0.]],
            vec![vec![10., 0., 0.], vec![10., 10., 0.]],
        ],
        weights: vec![vec![1., 1.], vec![1., 1.]],
        periodic_u: false,
        periodic_v: false,
    }
}

#[test]
fn brep_transport_carries_authoritative_canonical_change_set() {
    let value = dispatch(json!({
        "op": "brep_nurbs_box",
        "min": [0., 0., 0.],
        "max": [1., 2., 3.],
    }))
    .unwrap();
    let ids = &value["topologyIds"];
    assert_eq!(ids["changeSet"]["schema"].as_u64(), Some(1));
    assert_eq!(
        ids["changeSet"]["nodes"].as_array().unwrap().len(),
        8 + 12 + 6 + 6 + 1 + 1
    );
    assert!(
        ids["faces"]
            .as_array()
            .unwrap()
            .iter()
            .all(|id| id.as_str().is_some_and(|id| {
                id.starts_with("f:")
                    && id.len() == 34
                    && id[2..]
                        .bytes()
                        .all(|byte| byte.is_ascii_hexdigit() && !byte.is_ascii_uppercase())
            }))
    );
}
#[test]
fn nurbs_to_polygons_and_back_to_exact_boundary_curves() {
    let source = plane();
    let sampled = tessellate_nurbs(
        &source,
        &Options {
            segments_u: 4,
            segments_v: 3,
            trim: None,
            max_triangles: None,
        },
    )
    .unwrap();
    let loops = sampled.mesh.boundary_loops().unwrap();
    let curves = boundary_curves(&sampled.mesh).unwrap();
    assert_eq!(curves.len(), 1);
    assert_eq!(curves[0].degree, 1);
    assert!(!curves[0].periodic);
    for (i, index) in loops[0].iter().enumerate() {
        assert_eq!(
            curves[0].evaluate(i as f64).unwrap().point,
            sampled.mesh.point(*index).unwrap().to_vec()
        );
    }
    let solid = sampled.mesh.thicken([0., 0., 2.]).unwrap();
    assert!(solid.report.closed);
    assert!((solid.report.signed_volume_mm3 - 200.).abs() < 1e-9);
    assert!(solid.mesh.uv.is_none());
    assert_eq!(source.control_points[0][0], vec![0., 0., 0.]);
}
#[test]
fn mesh_boundary_can_construct_a_new_nurbs_surface() {
    let source = plane();
    let mesh = tessellate_nurbs(
        &source,
        &Options {
            segments_u: 2,
            segments_v: 2,
            trim: None,
            max_triangles: None,
        },
    )
    .unwrap();
    let curves = boundary_curves(&mesh.mesh).unwrap();
    let walls = nurbs_core::surface::extrude(&curves[0], [0., 0., 3.]).unwrap();
    let result = tessellate_nurbs(
        &walls,
        &Options {
            segments_u: 8,
            segments_v: 2,
            trim: None,
            max_triangles: None,
        },
    )
    .unwrap();
    assert_eq!(result.report.non_manifold_edges, 0);
    assert!(result.report.parameter_seams_welded.unwrap().u);
}
#[test]
fn invalid_surface_is_rejected_before_polygons_are_created() {
    let mut source = plane();
    source.weights[0][0] = 0.;
    assert!(
        tessellate_nurbs(
            &source,
            &Options {
                segments_u: 2,
                segments_v: 2,
                trim: None,
                max_triangles: None
            }
        )
        .is_err()
    );
}

#[test]
fn brep_tessellation_preserves_faces_and_interchanges_both_kernels() {
    let model = brep_core::cuboid([0.; 3], [2., 3., 4.]).unwrap();
    for segments in [1, 2, 4] {
        let mesh = crate::brep::nurbs(&model, segments).unwrap();
        assert!(mesh.built.report.closed);
        assert!((mesh.built.report.signed_volume_mm3 - 24.).abs() < 1e-8);
        assert_eq!(
            mesh.face_ids
                .iter()
                .copied()
                .collect::<std::collections::BTreeSet<_>>()
                .len(),
            6
        );
        let polygon =
            polygon_core::solid::brep::from_mesh(&mesh.built.mesh, Some(&mesh.face_ids)).unwrap();
        assert_eq!(polygon.faces.len(), 6);
        assert_eq!(polygon.bodies.len(), 1);
        let back = crate::brep::polygons(&polygon).unwrap();
        assert!(back.built.report.closed);
        assert!((back.built.report.signed_volume_mm3 - 24.).abs() < 1e-8);
    }
}

#[test]
fn brep_operations_dispatch_to_closed_tessellated_solids() {
    let a = brep_core::cuboid([0.; 3], [2., 2., 2.]).unwrap();
    let b = brep_core::cuboid([1., 1., 0.], [3., 3., 2.]).unwrap();
    for operation in ["union", "difference", "intersection"] {
        let result = brep_core::boolean(&a, &b, operation).unwrap();
        let tessellation = crate::brep::nurbs(&result, 2).unwrap();
        assert!(tessellation.built.report.closed);
        assert_eq!(tessellation.built.report.non_manifold_edges, 0);
    }
    for result in [
        brep_core::chamfer(&a, 0, 0.25).unwrap(),
        brep_core::fillet(&a, 0, 0.25, 8).unwrap(),
    ] {
        let tessellation = crate::brep::nurbs(&result, 2).unwrap();
        assert!(tessellation.built.report.closed);
        assert_eq!(tessellation.built.report.orientation_conflicts, 0);
    }

    let separated = brep_core::cuboid([4., 0., 0.], [5., 1., 1.]).unwrap();
    let multi_body = brep_core::boolean(&a, &separated, "union").unwrap();
    assert_eq!(multi_body.bodies.len(), 2);
    let tessellation = crate::brep::nurbs(&multi_body, 2).unwrap();
    assert!(tessellation.built.report.closed);
    assert!((tessellation.built.report.signed_volume_mm3 - 9.).abs() < 1e-8);
}

#[test]
fn mesh_section_and_toolpath_ops_cut_a_box() {
    let mesh = polygon_core::solid::primitives::cube([10., 10., 10.], false).unwrap();
    let mesh_value = value_codec::to_value(&mesh).unwrap();
    let section = dispatch(json!({
        "op": "mesh_section",
        "mesh": mesh_value,
        "z": 1.0,
    }))
    .unwrap();
    assert!(!section["contours"].as_array().unwrap().is_empty());

    let toolpaths = dispatch(json!({
        "op": "mesh_toolpaths",
        "mesh": mesh_value,
        "zMin": 0.0,
        "zMax": 2.0,
        "layerHeightMm": 0.5,
        "wallCount": 1,
    }))
    .unwrap();
    assert!(!toolpaths["layers"].as_array().unwrap().is_empty());

    let gcode = dispatch(json!({
        "op": "mesh_gcode",
        "mesh": mesh_value,
        "zMin": 0.0,
        "zMax": 1.0,
        "layerHeightMm": 0.5,
        "wallCount": 1,
    }))
    .unwrap();
    assert!(gcode["gcode"].as_str().unwrap().contains("G1"));
}

#[test]
fn analytic_step_export_import_roundtrip() {
    let model = encode(brep_core::cylinder(2., 4.).unwrap()).unwrap();
    let exported = dispatch(json!({
        "op": "brep_nurbs_export_step",
        "model": model,
    }))
    .unwrap();
    let text = exported["text"].as_str().unwrap();
    assert!(text.contains("CYLINDRICAL_SURFACE"));
    assert!(text.contains("CIRCLE"));
    assert!(text.contains("ADVANCED_FACE"));
    assert!(!text.contains("OSCAD_SOLID"));
    assert!(!text.contains("FACETED_BREP"));
    assert_eq!(
        exported["certificate"]["capability"].as_str(),
        Some("step-interchange/1")
    );
    assert_eq!(exported["certificate"]["complete"], true);
    let imported = dispatch(json!({
        "op": "brep_nurbs_import_step",
        "text": text,
    }))
    .unwrap();
    assert_eq!(imported["certificate"]["complete"], true);
    assert!(imported["model"]["faces"].as_array().unwrap().len() >= 6);
    let faceted = "ISO-10303-21;\nDATA;\n#1=FACETED_BREP('',#2);\nENDSEC;\nEND-ISO-10303-21;\n";
    assert!(
        dispatch(json!({"op": "brep_nurbs_import_step", "text": faceted})).is_err(),
        "faceted must refuse on analytic import"
    );
}

#[test]
fn step_successor_bridge_reports_identity_preservation_and_loss() {
    let model = encode(brep_core::cuboid([0., 0., 0.], [2., 3., 4.]).unwrap()).unwrap();
    let exported = dispatch(json!({
        "op": "brep_nurbs_export_step_v2",
        "model": model,
    }))
    .unwrap();
    assert_eq!(
        exported["certificate"]["capability"].as_str(),
        Some("step-interchange/2")
    );
    assert_eq!(exported["identity"]["preserved"], true);
    let text = exported["text"].as_str().unwrap();
    assert!(text.contains("GLOBAL_UNIT_ASSIGNED_CONTEXT"));
    assert!(text.contains("OSCAD_TOPO/2|face|"));
    let imported = dispatch(json!({
        "op": "brep_nurbs_import_step_v2",
        "text": text,
    }))
    .unwrap();
    assert_eq!(imported["identity"]["preserved"], true);

    let stripped = text
        .lines()
        .map(|line| {
            if let Some(start) = line.find("'OSCAD_TOPO/2|") {
                let end = line[start + 1..].find('\'').unwrap() + start + 1;
                format!("{}''{}", &line[..start], &line[end + 1..])
            } else {
                line.to_string()
            }
        })
        .collect::<Vec<_>>()
        .join("\n");
    let external = dispatch(json!({
        "op": "brep_nurbs_import_step_v2",
        "text": stripped,
    }))
    .unwrap();
    assert_eq!(external["identity"]["preserved"], false);
    assert!(external["identity"]["createdCount"].as_u64().unwrap() > 0);
}

#[test]
fn direct_step_v3_bridge_preserves_exact_graph() {
    let model = brep_core::freeform_cuboid_solid([0., 0., 0.], [2., 3., 4.]).unwrap();
    let expected = encode(model).unwrap();
    let exported = dispatch(json!({
        "op": "brep_nurbs_export_step_v3",
        "model": expected,
    }))
    .unwrap();
    assert_eq!(
        exported["certificate"]["capability"].as_str(),
        Some("step-interchange/3")
    );
    assert_eq!(exported["identity"]["preserved"], true);
    let imported = dispatch(json!({
        "op": "brep_nurbs_import_step_v3",
        "text": exported["text"],
    }))
    .unwrap();
    assert_eq!(imported["identity"]["preserved"], true);
    assert_eq!(imported["model"]["vertices"].as_array().unwrap().len(), 8);
    assert_eq!(imported["model"]["edges"].as_array().unwrap().len(), 12);
    assert_eq!(imported["model"]["faces"].as_array().unwrap().len(), 6);
    assert_eq!(imported["model"]["bodies"].as_array().unwrap().len(), 1);
}

#[test]
fn direct_step_v5_bridge_exposes_ap242_report() {
    let model = brep_core::freeform_cuboid_solid([0., 0., 0.], [2., 3., 4.]).unwrap();
    let exported =
        dispatch(json!({"op":"brep_nurbs_export_step_v5","model":encode(model).unwrap()})).unwrap();
    assert_eq!(exported["certificate"]["capability"], "step-interchange/5");
    assert!(
        exported["text"]
            .as_str()
            .unwrap()
            .contains("SHAPE_DEFINITION_REPRESENTATION")
    );
    let imported =
        dispatch(json!({"op":"brep_nurbs_import_step_v5","text":exported["text"]})).unwrap();
    assert_eq!(imported["identity"]["preserved"], true);
    assert_eq!(imported["metadataLoss"].as_array().unwrap().len(), 0);
}

#[test]
fn direct_step_v6_bridge_roundtrips_poles_and_reports_identities() {
    let model = brep_core::frustum(2., 0., 3.).unwrap();
    let exported =
        dispatch(json!({"op":"brep_nurbs_export_step_v6","model":encode(model).unwrap()})).unwrap();
    assert_eq!(exported["certificate"]["capability"], "step-interchange/6");
    let imported =
        dispatch(json!({"op":"brep_nurbs_import_step_v6","text":exported["text"]})).unwrap();
    assert_eq!(imported["model"]["bodies"].as_array().unwrap().len(), 1);
    assert_eq!(
        imported["definitionIdentities"].as_array().unwrap().len(),
        1
    );
    assert_eq!(
        imported["occurrenceIdentities"].as_array().unwrap().len(),
        1
    );
}

#[test]
fn direct_step_v7_bridge_composes_occurrence_topology() {
    let model = brep_core::freeform_cuboid_solid([0., 0., 0.], [1., 1., 1.]).unwrap();
    let exported =
        dispatch(json!({"op":"brep_nurbs_export_step_v7","model":encode(model).unwrap()})).unwrap();
    assert_eq!(exported["certificate"]["capability"], "step-interchange/7");
    let imported =
        dispatch(json!({"op":"brep_nurbs_import_step_v7","text":exported["text"]})).unwrap();
    let composed=dispatch(json!({"op":"brep_nurbs_compose_step_v7","models":[imported["model"].clone(),imported["model"].clone()]})).unwrap();
    assert_eq!(composed["bodies"].as_array().unwrap().len(), 2);
    let ids = composed["topologyIds"]["bodies"].as_array().unwrap();
    assert_eq!(ids.len(), 2);
    assert_ne!(ids[0], ids[1]);
}

#[test]
fn direct_step_v8_bridge_exposes_whole_domain_certificate() {
    let model = brep_core::sphere(2.).unwrap();
    let exported =
        dispatch(json!({"op":"brep_nurbs_export_step_v8","model":encode(model).unwrap()})).unwrap();
    assert_eq!(exported["certificate"]["capability"], "step-interchange/8");
    assert_eq!(exported["certificate"]["coupledSenseCases"], 128);
    assert_eq!(
        exported["certificate"]["regularity"][0]["carrier"],
        "sphere"
    );
    let imported =
        dispatch(json!({"op":"brep_nurbs_import_step_v8","text":exported["text"]})).unwrap();
    assert_eq!(imported["certificate"]["complete"], true);
    assert_eq!(
        imported["certificate"]["regularity"][0]["collapsedBoundaries"]
            .as_array()
            .unwrap()
            .len(),
        2
    );
}

#[test]
fn direct_step_v9_bridge_retains_open_shell() {
    let control_points = (0..4)
        .map(|u| {
            (0..4)
                .map(|v| vec![u as f64 / 3., v as f64 / 3., (u * v) as f64 / 90.])
                .collect()
        })
        .collect();
    let surface = nurbs_core::surface::Surface {
        degree_u: 3,
        degree_v: 3,
        knots_u: vec![0., 0., 0., 0., 1., 1., 1., 1.],
        knots_v: vec![0., 0., 0., 0., 1., 1., 1., 1.],
        control_points,
        weights: vec![vec![1.; 4]; 4],
        periodic_u: false,
        periodic_v: false,
    };
    let model = brep_core::bicubic_open_face(surface).unwrap();
    let exported =
        dispatch(json!({"op":"brep_nurbs_export_step_v9","model":encode(model).unwrap()})).unwrap();
    assert_eq!(exported["certificate"]["capability"], "step-interchange/9");
    assert!(
        exported["text"]
            .as_str()
            .unwrap()
            .contains("SHELL_BASED_SURFACE_MODEL")
    );
    let imported =
        dispatch(json!({"op":"brep_nurbs_import_step_v9","text":exported["text"]})).unwrap();
    assert_eq!(imported["model"]["bodies"].as_array().unwrap().len(), 0);
    assert_eq!(imported["model"]["shells"][0]["closed"], false);
}

#[test]
fn direct_iges_v2_bridge_preserves_exact_graph() {
    let model = brep_core::freeform_cuboid_solid([0., 0., 0.], [2., 3., 4.]).unwrap();
    let exported = dispatch(json!({
        "op":"brep_nurbs_export_iges_v2",
        "model":encode(model).unwrap(),
    }))
    .unwrap();
    assert_eq!(
        exported["certificate"]["capability"].as_str(),
        Some("iges-interchange/2")
    );
    assert_eq!(exported["identity"]["preserved"], true);
    assert!(
        exported["text"]
            .as_str()
            .unwrap()
            .lines()
            .all(|line| line.len() == 80)
    );
    let imported =
        dispatch(json!({"op":"brep_nurbs_import_iges_v2","text":exported["text"]})).unwrap();
    assert_eq!(imported["identity"]["preserved"], true);
    assert_eq!(imported["model"]["vertices"].as_array().unwrap().len(), 8);
    assert_eq!(imported["model"]["edges"].as_array().unwrap().len(), 12);
    assert_eq!(imported["model"]["faces"].as_array().unwrap().len(), 6);
}

#[test]
fn audited_feature_successors_cross_the_bridge_with_certificates() {
    let model = brep_core::cuboid([0., 0., 0.], [10., 8., 6.]).unwrap();
    let edges = model
        .edges
        .iter()
        .enumerate()
        .filter_map(|(index, edge)| {
            let a = model.vertices[edge.vertices[0]].point;
            let b = model.vertices[edge.vertices[1]].point;
            ((a[0] - b[0]).abs() <= 1e-12 && (a[1] - b[1]).abs() <= 1e-12).then_some(index)
        })
        .take(2)
        .collect::<Vec<_>>();
    let fillet = dispatch(json!({
        "op":"brep_nurbs_audited_multi_edge_fillet",
        "model":encode(model.clone()).unwrap(),
        "edges":edges.clone(),
        "radius":0.5
    }))
    .unwrap();
    assert_eq!(
        fillet["certificate"]["capability"].as_str(),
        Some("analytic-multi-edge-fillet/1")
    );
    assert_eq!(fillet["certificate"]["complete"], true);
    assert_eq!(fillet["audit"]["ok"], true);
    assert_eq!(fillet["namingComplete"], true);
    let exact_fillet = dispatch(json!({
        "op":"brep_nurbs_exact_convex_prism_fillet",
        "model":encode(model.clone()).unwrap(),
        "edges":edges.clone(),
        "radius":0.4
    }))
    .unwrap();
    assert_eq!(
        exact_fillet["certificate"]["capability"].as_str(),
        Some("exact-convex-prism-edge-fillet/1")
    );
    assert_eq!(exact_fillet["audit"]["ok"], true);
    let vertical = edges[0];
    let connected = model.edges[0]
        .vertices
        .iter()
        .find_map(|vertex| {
            (1..model.edges.len()).find(|edge| model.edges[*edge].vertices.contains(vertex))
        })
        .unwrap();
    let chamfer = dispatch(json!({
        "op":"brep_nurbs_exact_convex_chamfer",
        "model":encode(model.clone()).unwrap(),
        "edges":[0,connected],
        "distance":0.5
    }))
    .unwrap();
    assert_eq!(
        chamfer["certificate"]["capability"].as_str(),
        Some("exact-convex-straight-edge-chamfer/1")
    );
    assert_eq!(chamfer["audit"]["ok"], true);
    let variable = dispatch(json!({
        "op":"brep_nurbs_exact_variable_radius_fillet",
        "model":encode(model.clone()).unwrap(),
        "edges":[vertical],
        "radii":[[0.4,0.6]]
    }))
    .unwrap();
    assert_eq!(
        variable["certificate"]["capability"].as_str(),
        Some("exact-variable-radius-fillet/1")
    );
    assert_eq!(variable["audit"]["ok"], true);
    assert!(
        dispatch(json!({
            "op":"brep_nurbs_exact_variable_radius_fillet",
            "model":encode(model.clone()).unwrap(),
            "edges":[vertical],
            "radii":[[0.5,0.5]]
        }))
        .is_err()
    );
    let max = [10., 8., 6.];
    let corner_edges: Vec<usize> = model
        .edges
        .iter()
        .enumerate()
        .filter_map(|(index, edge)| {
            let touches = edge.vertices.iter().any(|&v| {
                let p = model.vertices[v].point;
                (0..3).all(|i| (p[i] - max[i]).abs() <= 1e-9)
            });
            let a = model.vertices[edge.vertices[0]].point;
            let b = model.vertices[edge.vertices[1]].point;
            let mid = [
                0.5 * (a[0] + b[0]),
                0.5 * (a[1] + b[1]),
                0.5 * (a[2] + b[2]),
            ];
            let axis = ((mid[0] - max[0]).abs() <= 1e-9 && (mid[1] - max[1]).abs() <= 1e-9)
                || ((mid[0] - max[0]).abs() <= 1e-9 && (mid[2] - max[2]).abs() <= 1e-9)
                || ((mid[1] - max[1]).abs() <= 1e-9 && (mid[2] - max[2]).abs() <= 1e-9);
            (touches && axis).then_some(index)
        })
        .collect();
    assert_eq!(corner_edges.len(), 3);
    let valence3 = dispatch(json!({
        "op":"brep_nurbs_exact_valence3_corner_blend",
        "model":encode(model).unwrap(),
        "edges":corner_edges,
        "radius":1.0
    }))
    .unwrap();
    assert_eq!(
        valence3["certificate"]["capability"].as_str(),
        Some("exact-valence3-corner-blend/1")
    );
    assert_eq!(valence3["audit"]["ok"], true);

    let sweep = dispatch(json!({
        "op":"brep_nurbs_audited_parallel_frame_sweep",
        "profile":[[0.,0.],[2.,0.],[2.,1.],[0.,1.]],
        "path":[[3.,-1.,0.],[3.,-1.,4.]],
        "frameLaw":"rmf"
    }))
    .unwrap();
    assert_eq!(
        sweep["certificate"]["capability"].as_str(),
        Some("exact-parallel-frame-sweep/1")
    );
    assert_eq!(sweep["audit"]["ok"], true);
    assert_eq!(sweep["namingComplete"], true);
    assert!(
        dispatch(json!({
            "op":"brep_nurbs_audited_parallel_frame_sweep",
            "profile":[[0.,0.],[2.,0.],[2.,1.],[0.,1.]],
            "path":[[0.,0.,0.],[0.,0.,2.],[0.,1.,4.]],
            "frameLaw":"rmf"
        }))
        .is_err()
    );
}

#[test]
fn exact_analytic_shell_crosses_bridge_with_audited_certificate() {
    let model = brep_core::cuboid([0., 0., 0.], [10., 8., 6.]).unwrap();
    let before = value_codec::to_string(&model).unwrap();
    let result = dispatch(json!({
        "op":"brep_nurbs_exact_analytic_shell",
        "model":encode(model.clone()).unwrap(),
        "openings":[0,1],
        "thickness":0.5,
        "direction":"inward"
    }))
    .unwrap();
    assert_eq!(
        result["certificate"]["capability"].as_str(),
        Some("analytic-shell/2")
    );
    assert_eq!(result["certificate"]["complete"], true);
    assert_eq!(result["audit"]["ok"], true);
    assert_eq!(result["namingComplete"], true);
    assert!(
        !result["changeSet"]["changes"]
            .as_array()
            .unwrap()
            .is_empty()
    );
    assert_eq!(before, value_codec::to_string(&model).unwrap());
    assert!(
        dispatch(json!({
            "op":"brep_nurbs_exact_analytic_shell",
            "model":encode(model).unwrap(),
            "openings":[0,2],
            "thickness":0.5,
            "direction":"inward"
        }))
        .is_err()
    );
}

#[test]
fn exact_loft_and_bent_rmf_successors_cross_bridge_atomically() {
    let loft = dispatch(json!({
        "op":"brep_nurbs_audited_multi_section_loft_v2",
        "sections":[
            [[-1.,-1.,0.],[1.,-1.,0.],[1.,1.,0.],[-1.,1.,0.]],
            [[-1.5,-1.,2.],[1.5,-1.,2.],[1.5,1.,2.],[-1.5,1.,2.]],
            [[-1.,-0.75,5.],[1.,-0.75,5.],[1.,0.75,5.],[-1.,0.75,5.]]
        ]
    }))
    .unwrap();
    assert_eq!(
        loft["certificate"]["capability"].as_str(),
        Some("analytic-solid-loft/2")
    );
    assert_eq!(loft["audit"]["ok"], true);
    assert_eq!(loft["model"]["faces"].as_array().unwrap().len(), 10);

    let sweep = dispatch(json!({
        "op":"brep_nurbs_audited_bent_rmf_sweep_v2",
        "profile":[[-0.2,-0.2],[0.2,-0.2],[0.2,0.2],[-0.2,0.2]],
        "path":[[0.,0.,0.],[0.,0.,3.],[0.,1.,6.],[0.,3.,9.]],
        "twistRadians":[0.,0.1,0.2,0.3],
        "scales":[1.,1.1,1.2,1.25]
    }))
    .unwrap();
    assert_eq!(
        sweep["certificate"]["capability"].as_str(),
        Some("exact-parallel-frame-sweep/2")
    );
    assert_eq!(sweep["audit"]["ok"], true);
    assert_eq!(sweep["namingComplete"], true);
    assert_eq!(sweep["model"]["faces"].as_array().unwrap().len(), 14);
    assert!(
        dispatch(json!({
            "op":"brep_nurbs_audited_bent_rmf_sweep_v2",
            "profile":[[-0.2,-0.2],[0.2,-0.2],[0.2,0.2],[-0.2,0.2]],
            "path":[[0.,0.,0.],[0.,0.,3.],[0.,0.,0.]],
            "twistRadians":[0.,0.,0.],
            "scales":[1.,1.,1.]
        }))
        .is_err()
    );
}

#[test]
fn freeform_nurbs_step_export_import_roundtrip() {
    let mut cps = Vec::new();
    for y in 0..4 {
        cps.push(
            (0..4)
                .map(|x| vec![x as f64, y as f64, 0.05 * (x + y) as f64])
                .collect::<Vec<_>>(),
        );
    }
    let surface = nurbs_core::surface::Surface {
        degree_u: 3,
        degree_v: 3,
        knots_u: vec![0., 0., 0., 0., 1., 1., 1., 1.],
        knots_v: vec![0., 0., 0., 0., 1., 1., 1., 1.],
        control_points: cps,
        weights: vec![vec![1.; 4]; 4],
        periodic_u: false,
        periodic_v: false,
    };
    let model = encode(brep_core::bicubic_open_face(surface).unwrap()).unwrap();
    let exported = dispatch(json!({
        "op": "brep_nurbs_export_step_freeform",
        "model": model,
    }))
    .unwrap();
    let text = exported["text"].as_str().unwrap();
    assert!(text.contains("B_SPLINE_SURFACE_WITH_KNOTS"));
    assert!(text.contains("OPEN_SHELL"));
    assert!(!text.contains("MANIFOLD_SOLID_BREP"));
    assert!(!text.contains("OSCAD_SOLID"));
    assert_eq!(
        exported["certificate"]["capability"].as_str(),
        Some("nurbs-step-bicubic-face/1")
    );
    let imported = dispatch(json!({
        "op": "brep_nurbs_import_step_freeform",
        "text": text,
    }))
    .unwrap();
    assert_eq!(imported["certificate"]["complete"], true);
    assert_eq!(imported["model"]["faces"].as_array().unwrap().len(), 1);
    assert!(
        dispatch(json!({
            "op": "brep_nurbs_export_step_freeform",
            "model": encode(brep_core::cuboid([0.,0.,0.],[1.,1.,1.]).unwrap()).unwrap(),
        }))
        .is_err(),
        "constructor solid must refuse on freeform export"
    );
}

#[test]
fn freeform_nurbs_step_trimmed_and_solid_bridge() {
    let mut cps = Vec::new();
    for y in 0..4 {
        cps.push(
            (0..4)
                .map(|x| vec![x as f64, y as f64, 0.02 * (x + y) as f64])
                .collect::<Vec<_>>(),
        );
    }
    let surface = nurbs_core::surface::Surface {
        degree_u: 3,
        degree_v: 3,
        knots_u: vec![0., 0., 0., 0., 1., 1., 1., 1.],
        knots_v: vec![0., 0., 0., 0., 1., 1., 1., 1.],
        control_points: cps,
        weights: vec![vec![1.; 4]; 4],
        periodic_u: false,
        periodic_v: false,
    };
    let hole = [[0.2, 0.2], [0.8, 0.2], [0.8, 0.8], [0.2, 0.8]];
    let trimmed = encode(brep_core::bicubic_trimmed_face(surface, hole).unwrap()).unwrap();
    let exported = dispatch(json!({
        "op": "brep_nurbs_export_step_trimmed",
        "model": trimmed,
    }))
    .unwrap();
    assert!(exported["text"].as_str().unwrap().contains("FACE_BOUND"));
    assert_eq!(
        exported["certificate"]["capability"].as_str(),
        Some("nurbs-step-trimmed-bicubic/1")
    );
    let imported = dispatch(json!({
        "op": "brep_nurbs_import_step_trimmed",
        "text": exported["text"],
    }))
    .unwrap();
    assert_eq!(
        imported["model"]["faces"][0]["holes"]
            .as_array()
            .unwrap()
            .len(),
        1
    );

    let solid =
        encode(brep_core::freeform_cuboid_solid([0., 0., 0.], [2., 2., 2.]).unwrap()).unwrap();
    let sexported = dispatch(json!({
        "op": "brep_nurbs_export_step_solid",
        "model": solid,
    }))
    .unwrap();
    let stext = sexported["text"].as_str().unwrap();
    assert!(stext.contains("MANIFOLD_SOLID_BREP"));
    assert!(!stext.contains("OSCAD_SOLID"));
    assert!(!stext.contains("AABB"));
    assert_eq!(
        sexported["certificate"]["capability"].as_str(),
        Some("nurbs-step-solid/1")
    );
    let simported = dispatch(json!({
        "op": "brep_nurbs_import_step_solid",
        "text": sexported["text"],
    }))
    .unwrap();
    assert_eq!(simported["model"]["faces"].as_array().unwrap().len(), 6);

    let outer = brep_core::freeform_cuboid_solid([0., 0., 0.], [4., 4., 4.]).unwrap();
    let inner = brep_core::freeform_cuboid_solid([2., -1., 0.], [5., 3., 4.]).unwrap();
    let (boolean_result, boolean_cert) =
        brep_core::nurbs_boolean_imprint_solids(&outer, &inner, "difference").unwrap();
    assert_eq!(boolean_cert.capability, "nurbs-boolean-bezier-le3/2");
    assert!(boolean_cert.permits_topology_change());
    boolean_result.validate().unwrap();
}

#[test]
fn authorized_heal_v2_bridge_derives_evidence_and_preserves_source() {
    let model = brep_core::cuboid([0., 0., 0.], [2., 2., 2.]).unwrap();
    let vertex = model.edges[0].vertices[0];
    let incident = model
        .edges
        .iter()
        .filter(|edge| edge.vertices.contains(&vertex))
        .count();
    let mut to = model.vertices[vertex].point;
    to[1] += model
        .tolerance_context()
        .unwrap()
        .spatial_bounds()
        .absolute_mm
        / (incident + 1) as f64
        * 0.25;
    let source = encode(model).unwrap();
    let before = source.clone();
    let result = dispatch(json!({
        "op":"brep_nurbs_authorized_heal_v2",
        "model":source,
        "operation":{"kind":"endpointSnap","vertex":vertex,"to":to}
    }))
    .unwrap();
    assert_eq!(source, before);
    assert_eq!(
        result["certificate"]["capability"].as_str(),
        Some("authorized-heal-gap-le1/2")
    );
    assert_eq!(result["certificate"]["status"].as_str(), Some("Complete"));
    assert_eq!(
        result["certificate"]["namingComplete"].as_bool(),
        Some(true)
    );
    assert!(
        result["certificate"]["displacementLedger"][0]["actualMm"]
            .as_f64()
            .unwrap()
            > 0.
    );
    assert!(
        dispatch(json!({
            "op":"brep_nurbs_authorized_heal_v2",
            "model":source,
            "operation":{"kind":"endpointSnap","vertex":vertex,"to":to,"evidence":true}
        }))
        .unwrap_err()
        .message
        .contains("unauthorized fields")
    );
}

#[test]
fn curved_graph_boolean_v3_bridge_serializes_audited_authority() {
    let graph = dispatch(json!({
        "op":"brep_nurbs_canonical_graph_solid_v3",
        "degreeU":3,
        "degreeV":2
    }))
    .unwrap();
    let cutter = encode(brep_core::cuboid([0.5, -1., -1.], [2., 2., 3.]).unwrap()).unwrap();
    let result = dispatch(json!({
        "op":"brep_nurbs_boolean_bezier_le3_v3",
        "a":graph,
        "b":cutter,
        "operation":"intersection"
    }))
    .unwrap();
    assert_eq!(
        result["certificate"]["capability"].as_str(),
        Some("nurbs-boolean-bezier-le3/3")
    );
    assert_eq!(result["certificate"]["status"].as_str(), Some("Complete"));
    assert_eq!(result["certificate"]["axis"].as_str(), Some("U"));
    assert_eq!(result["certificate"]["tensorCells"].as_u64(), Some(3));
    assert_eq!(
        result["certificate"]["lineage"]["generatedIntersectionEdge"]
            .as_str()
            .map(str::is_empty),
        Some(false)
    );
    assert_eq!(result["certificate"]["audit"]["ok"].as_bool(), Some(true));
    assert_eq!(
        result["certificate"]["namingComplete"].as_bool(),
        Some(true)
    );
    assert!(
        dispatch(json!({
            "op":"brep_nurbs_boolean_bezier_le3_v3",
            "a":graph,
            "b":cutter,
            "operation":"union"
        }))
        .is_err()
    );
}

#[test]
fn curved_graph_boolean_v4_v5_bridge_serializes_cell_specific_authority() {
    let graph = dispatch(json!({
        "op":"brep_nurbs_canonical_graph_solid_v3",
        "degreeU":3,
        "degreeV":3
    }))
    .unwrap();
    let unequal = encode(brep_core::cuboid([0.5, -2., -3.], [2., 3., 4.]).unwrap()).unwrap();
    let v4 = dispatch(json!({
        "op":"brep_nurbs_boolean_bezier_le3_v4_unequal",
        "a":graph,
        "b":unequal,
        "operation":"intersection"
    }))
    .unwrap();
    assert_eq!(
        v4["certificate"]["capability"].as_str(),
        Some("nurbs-boolean-bezier-le3/4")
    );

    let inner = encode(brep_core::cuboid([0.2; 3], [0.8; 3]).unwrap()).unwrap();
    let contained = dispatch(json!({
        "op":"brep_nurbs_boolean_bezier_le3_v4_containment",
        "graph":graph,
        "cutter":inner,
        "operation":"difference"
    }))
    .unwrap();
    assert_eq!(
        contained["certificate"]["cavityProof"].as_bool(),
        Some(true)
    );
    assert_eq!(
        contained["certificate"]["audit"]["shellCount"].as_u64(),
        Some(2)
    );

    let rational = dispatch(json!({
        "op":"brep_nurbs_canonical_rational_graph_solid_v5",
        "degreeU":3,
        "degreeV":3
    }))
    .unwrap();
    let v5 = dispatch(json!({
        "op":"brep_nurbs_boolean_bezier_le3_v5_rational",
        "a":rational,
        "b":unequal,
        "operation":"difference"
    }))
    .unwrap();
    assert_eq!(
        v5["certificate"]["capability"].as_str(),
        Some("nurbs-boolean-bezier-le3/5")
    );
    assert_eq!(
        v5["certificate"]["homogeneousRootProof"].as_bool(),
        Some(true)
    );
    assert!(v5["certificate"]["denominatorLowerBound"].as_f64().unwrap() >= 0.25);
    assert!(v5["certificate"]["weightConditionNumber"].as_f64().unwrap() <= 8.);
    assert!(v5["certificate"]["resourceBound"].as_u64().unwrap() <= 16);
}

#[test]
fn general_multispan_boolean_bridge_is_strict_and_audited() {
    for (u, v) in [(2, 1), (1, 2), (2, 2)] {
        let graph = dispatch(json!({
            "op":"brep_nurbs_canonical_multispan_graph_solid",
            "spansU":u,
            "spansV":v
        }))
        .unwrap();
        let cutter = encode(brep_core::cuboid([0.25, -1., -1.], [0.75, 2., 3.]).unwrap()).unwrap();
        for (operation, components, faces) in [
            ("intersection", 1, 6),
            ("difference", 2, 12),
            ("union", 3, 18),
        ] {
            let result = dispatch(json!({
                "op":"brep_nurbs_boolean_general",
                "a":graph,
                "b":cutter,
                "operation":operation
            }))
            .unwrap();
            assert_eq!(
                result["certificate"]["capability"].as_str(),
                Some("nurbs-boolean/1")
            );
            assert_eq!(
                result["certificate"]["authority"].as_str(),
                Some("author-general-nurbs-boolean")
            );
            assert_eq!(result["certificate"]["status"].as_str(), Some("Complete"));
            assert_eq!(
                result["certificate"]["operandOrder"].as_str(),
                Some("source-tool")
            );
            assert_eq!(
                result["certificate"]["exactRegionMembership"].as_bool(),
                Some(true)
            );
            assert_eq!(
                result["certificate"]["ssReportsComplete"].as_bool(),
                Some(true)
            );
            assert!(result["certificate"]["ssFacePairs"].as_u64().unwrap_or(0) > 0);
            assert_eq!(
                result["certificate"]["branchGraph"]["components"].as_u64(),
                Some(2)
            );
            assert_eq!(
                result["certificate"]["branchGraph"]["complete"].as_bool(),
                Some(true)
            );
            assert_eq!(
                result["certificate"]["uv"]["complete"].as_bool(),
                Some(true)
            );
            assert_eq!(
                result["certificate"]["resultComponents"].as_u64(),
                Some(components)
            );
            assert_eq!(result["certificate"]["resultFaces"].as_u64(), Some(faces));
            assert_eq!(result["certificate"]["audit"]["ok"].as_bool(), Some(true));
            assert_eq!(result["certificate"]["noFallback"].as_bool(), Some(true));
        }
        let reversed = dispatch(json!({
            "op":"brep_nurbs_boolean_general",
            "a":cutter,
            "b":graph,
            "operation":"difference"
        }))
        .unwrap();
        assert_eq!(
            reversed["certificate"]["operandOrder"].as_str(),
            Some("tool-source")
        );
        assert_eq!(reversed["certificate"]["partitionCells"].as_u64(), Some(4));
        assert!(
            dispatch(json!({
                "op":"brep_nurbs_boolean_general",
                "a":graph,
                "b":cutter,
                "operation":"intersection",
                "fallback":"mesh"
            }))
            .is_err()
        );
    }
}

#[test]
fn certified_freeform_tessellation_crosses_bridge() {
    let planar =
        encode(brep_core::freeform_cuboid_solid([0., 0., 0.], [2., 3., 4.]).unwrap()).unwrap();
    assert!(
        dispatch(json!({
            "op":"brep_nurbs_certified_tessellate",
            "model":planar,
            "chordToleranceMm":0.1,
            "maxTriangles":20000
        }))
        .is_err()
    );
    let planar_cert = dispatch(json!({
        "op":"brep_nurbs_certified_freeform_tessellate",
        "model":planar,
        "chordToleranceMm":0.1,
        "maxTriangles":20000
    }))
    .unwrap();
    assert_eq!(
        planar_cert["capability"].as_str(),
        Some("certified-generic-rational-freeform-tessellation/1")
    );
    assert!(planar_cert["surfaceToMeshDeviationMm"].as_f64().unwrap() <= 1e-12);
    assert_eq!(planar_cert["namingComplete"], true);
    assert_eq!(planar_cert["audit"]["ok"], true);

    let bump =
        encode(brep_core::freeform_cuboid_with_bump_face([0., 0., 0.], [2., 2., 2.]).unwrap())
            .unwrap();
    let bump_cert = dispatch(json!({
        "op":"brep_nurbs_certified_freeform_tessellate",
        "model":bump,
        "chordToleranceMm":0.5,
        "maxTriangles":20000
    }))
    .unwrap();
    assert_eq!(
        bump_cert["capability"].as_str(),
        Some("certified-generic-rational-freeform-tessellation/1")
    );
    assert!(bump_cert["surfaceToMeshDeviationMm"].as_f64().unwrap() <= 0.5);
    assert!(
        bump_cert["resourceProof"]["subdivisionsPerPatch"]
            .as_u64()
            .unwrap()
            >= 1
    );
}

#[test]
fn certified_freeform_mass_crosses_bridge() {
    let planar =
        encode(brep_core::freeform_cuboid_solid([1., 2., 3.], [3., 6., 9.]).unwrap()).unwrap();
    assert!(
        dispatch(json!({
            "op":"brep_nurbs_certified_mass_properties",
            "model":planar
        }))
        .is_err()
    );
    let mass = dispatch(json!({
        "op":"brep_nurbs_certified_freeform_mass_properties",
        "model":planar
    }))
    .unwrap();
    assert_eq!(
        mass["capability"].as_str(),
        Some("certified-generic-rational-freeform-mass-quadrature/1")
    );
    let volume = &mass["volumeMm3"];
    assert!(volume["lower"].as_f64().unwrap() <= 48.);
    assert!(volume["upper"].as_f64().unwrap() >= 48.);
    assert_eq!(mass["namingComplete"], true);

    let bump =
        encode(brep_core::freeform_cuboid_with_bump_face([0., 0., 0.], [2., 2., 2.]).unwrap())
            .unwrap();
    assert!(
        dispatch(json!({
            "op":"brep_nurbs_certified_freeform_mass_properties",
            "model":bump
        }))
        .is_err()
    );
}

#[test]
fn simple_prism_fillet_bridge_reports_distinct_capability() {
    let model = brep_core::extrude_polygon(
        &[
            [0., 0.],
            [40., 0.],
            [40., 5.],
            [5., 5.],
            [5., 30.],
            [0., 30.],
        ],
        0.,
        20.,
    )
    .unwrap();
    let edge = model
        .edges
        .iter()
        .position(|e| {
            let [a, b] = e.vertices.map(|v| model.vertices[v].point);
            a[0] == 0. && b[0] == 0. && a[1] == 0. && b[1] == 0. && (a[2] - b[2]).abs() > 19.
        })
        .unwrap();
    let result=dispatch(json!({"op":"brep_nurbs_exact_simple_prism_fillet","model":encode(model).unwrap(),"edges":[edge],"radius":1.})).unwrap();
    assert_eq!(
        result["certificate"]["capability"].as_str(),
        Some("exact-simple-prism-convex-edge-fillet/1")
    );
    assert_eq!(result["certificate"]["complete"], true);
    assert_eq!(result["audit"]["ok"], true);
    assert_eq!(result["namingComplete"], true);
}

#[test]
fn annular_fillet_bridge_requires_complete_rim() {
    let model = brep_core::tube(20., 5., 6.).unwrap();
    let edges: Vec<_> = model
        .edges
        .iter()
        .enumerate()
        .filter(|(_, e)| {
            e.curve.degree == 2
                && e.vertices.iter().all(|v| {
                    let p = model.vertices[*v].point;
                    p[2] > 5. && p[0].hypot(p[1]) > 19.
                })
        })
        .map(|(i, _)| i)
        .collect();
    assert_eq!(edges.len(), 4);
    let encoded = encode(model).unwrap();
    let result=dispatch(json!({"op":"brep_nurbs_exact_annular_fillet","model":encoded.clone(),"edges":edges.clone(),"radius":1.})).unwrap();
    assert_eq!(
        result["certificate"]["capability"].as_str(),
        Some("exact-annular-circular-edge-fillet/1")
    );
    assert_eq!(result["certificate"]["complete"], true);
    assert_eq!(result["audit"]["ok"], true);
    assert_eq!(result["namingComplete"], true);
    assert!(dispatch(json!({"op":"brep_nurbs_exact_annular_fillet","model":encoded,"edges":[edges[0]],"radius":1.})).is_err());
}

#[test]
fn layered_fillet_bridge_checks_chain_and_cavity() {
    let outer = brep_core::cuboid([0., 0., 0.], [40., 30., 20.]).unwrap();
    let cutter = brep_core::cuboid([2., 2., 2.], [38., 28., 22.]).unwrap();
    let model = brep_core::boolean(&outer, &cutter, "difference").unwrap();
    let edges: Vec<_> = model
        .edges
        .iter()
        .enumerate()
        .filter(|(_, e)| {
            e.vertices.iter().all(|v| {
                let p = model.vertices[*v].point;
                p[0] == 0. && p[1] == 0.
            })
        })
        .map(|(i, _)| i)
        .collect();
    assert!(edges.len() > 1);
    let encoded = encode(model).unwrap();
    let request = json!({"op":"brep_nurbs_exact_layered_prism_fillet","model":encoded.clone(),"edges":edges.clone(),"radius":1.});
    let result = dispatch(request.clone()).unwrap();
    assert_eq!(
        result["certificate"]["capability"].as_str(),
        Some("exact-layered-prism-edge-fillet/1")
    );
    assert_eq!(result["audit"]["ok"], true);
    assert_eq!(result["namingComplete"], true);
    let mut extra = request.clone();
    extra["unexpected"] = json!(true);
    assert!(dispatch(extra).is_err());
    for radius in [0., -1., 8.] {
        let mut bad = request.clone();
        bad["radius"] = json!(radius);
        assert!(dispatch(bad).is_err());
    }
    let mut partial = request;
    partial["edges"] = json!([edges[0]]);
    assert!(dispatch(partial).is_err());
}

#[test]
fn native_section_preserves_legacy_input_error_code() {
    let error = dispatch(
        json!({"op":"mesh_section","mesh":{"positions":[0.,0.,0.],"indices":[0,1,2]},"z":0.}),
    )
    .unwrap_err();
    assert_eq!(error.code, "POLYGON_INVALID_INPUT");
    for code in [
        "MESH_INVALID_INPUT",
        "MESH_QUERY_INVALID_INPUT",
        "MESH_SECTION_INVALID_INPUT",
        "MESH_IO_INVALID_INPUT",
    ] {
        let error = crate::legacy_mesh_error(crate::Error::new(code, "the mesh resource budget"));
        assert_eq!(error.code, "POLYGON_INVALID_INPUT");
        assert_eq!(error.message, "the polygon resource budget");
    }
}

#[test]
fn raw_hollow_endpoint_caps_keep_the_exact_refusal_cause() {
    use nurbs_core::primitives::{circle,line};
    for orientation in ["oblique-rmf","frenet","rmf"] {
        let oblique=orientation=="oblique-rmf";
        let axis=if oblique {[3.,4.,0.]} else {[1.,0.,0.]};
        let path=if oblique {line([0.;3],axis).unwrap()} else {
            nurbs_core::paths::bezier(vec![vec![0.,0.,0.],vec![0.5,0.,0.],vec![1.,1.,0.]],None).unwrap()
        };
        let request=json!({"op":"brep_nurbs_progressive_profile_body",
            "loops":[[circle([0.;3],axis,0.1).unwrap()],[circle([0.;3],axis,0.05).unwrap().reverse().unwrap()]],
            "path":path,"scale":if oblique {line([1.,0.,0.],[2.,0.,0.]).unwrap()} else {nurbs_core::progressive_sweep::constant_vector_law([1.,0.,0.]).unwrap()},
            "twist":nurbs_core::progressive_sweep::constant_vector_law([0.;3]).unwrap(),
            "normal":[0.,0.,1.],"orientation":if oblique {"rmf"} else {orientation},"spacing":"parameter",
            "initial_sections":if oblique {2} else {3},"max_sections":if oblique {2} else {129},"max_deviation":0.01});
        let original=request.clone();
        let report=dispatch(request.clone()).unwrap();
        assert_eq!(request,original);
        assert_eq!(report["retainedWalls"]["certified"],true);
        assert_eq!(report["boundaryContinuousBound"],false);
        assert_eq!(report["retainedCaps"]["reason"],"cap-coedge-identity-different","{orientation}: {}",report["retainedCaps"]);
        assert!(report["filledCapErrorUpper"].is_null());
    }
}

#[test]
fn corrected_oblique_circle_caps_transport_complete_and_component_scopes() {
    use nurbs_core::primitives::{circle, line};
    let outer = circle([0.; 3], [3., 4., 0.], 0.1).unwrap();
    let hole = circle([0.; 3], [3., 4., 0.], 0.05)
        .unwrap()
        .reverse()
        .unwrap();
    let request = json!({"op":"brep_nurbs_progressive_profile_body",
        "loops":[[outer],[hole]],"path":line([0.;3],[3.,4.,0.]).unwrap(),
        "scale":line([1.,0.,0.],[2.,0.,0.]).unwrap(),
        "twist":nurbs_core::progressive_sweep::constant_vector_law([0.;3]).unwrap(),
        "normal":[0.,0.,1.],"orientation":"rmf","spacing":"parameter",
        "initial_sections":2,"max_sections":2,"max_deviation":0.01,
        "cap_correction_tolerance":1e-9,"cap_correction_quantum":2_f64.powi(-40),
        "cap_correction_max_work":1000000});
    let before = request.clone();
    let report = dispatch(request.clone()).unwrap();
    assert_eq!(report["boundaryContinuousBound"].as_bool(), Some(true));
    assert_eq!(report["boundaryErrorWithinBudget"].as_bool(), Some(true));
    assert!(report["boundaryErrorUpper"].as_f64().unwrap() <= 0.01);
    let cap_errors = report["filledCapErrorUpper"].as_array().unwrap();
    assert_eq!(cap_errors.len(), 2);
    assert!(
        cap_errors
            .iter()
            .all(|v| v.as_f64().is_some_and(|e| e >= 0. && e <= 0.01))
    );
    assert_eq!(report["retainedCaps"]["exact"].as_bool(), Some(true));
    assert_eq!(
        report["retainedCaps"]["continuousBound"].as_bool(),
        Some(false)
    );
    assert_eq!(report["globalEmbeddingCertified"].as_bool(), Some(false));
    assert_eq!(request, before);
    let mut exhausted = request;
    exhausted["cap_correction_max_work"] = json!(1);
    assert!(dispatch(exhausted).is_err());
}

#[test]
fn nonplanar_corrected_regular_body_owns_filled_cap_union() {
    let profile = nurbs_core::primitives::circle([0.; 3], [1., 0., 0.], 0.1).unwrap();
    let path = nurbs_core::paths::bezier(
        vec![
            vec![0., 0., 0.],
            vec![1., 0., 0.],
            vec![2., 1., 0.],
            vec![3., 1., 1.],
        ],
        None,
    )
    .unwrap();
    let mut scale = nurbs_core::primitives::line([0.; 3], [1., 0., 0.]).unwrap();
    scale.control_points = vec![vec![1., 0., 0.]; 2];
    let mut twist = scale.clone();
    twist.control_points = vec![vec![0.; 3]; 2];
    let request = value_codec::json!({"op":"brep_nurbs_progressive_profile_body","loops":[[profile]],"path":path,"scale":scale,"twist":twist,
 "normal":[0.,0.,1.],"orientation":"corrected_frenet","spacing":"parameter","initial_sections":3,"max_sections":129,"max_deviation":0.05,
 "cap_correction_tolerance":1e-9,"cap_correction_quantum":2_f64.powi(-40),"cap_correction_max_work":1000000});
    let saved = request.clone();
    let result = crate::dispatch(request.clone()).unwrap();
    assert_eq!(request, saved);
    assert_eq!(result["boundaryContinuousBound"], true, "{result}");
    assert_eq!(result["boundaryErrorWithinBudget"], true);
    assert_eq!(result["filledCapErrorUpper"].as_array().unwrap().len(), 2);
    assert!(result["boundaryErrorUpper"].as_f64().unwrap() <= 0.05);
    assert_eq!(result["globalEmbeddingCertified"], false);
    let mut hollow = request.clone();
    let hole = nurbs_core::primitives::circle([0.; 3], [1., 0., 0.], 0.05)
        .unwrap()
        .reverse()
        .unwrap();
    hollow["loops"]
        .as_array_mut()
        .unwrap()
        .push(value_codec::json!([hole]));
    for affine in [false, true] {
        let mut variant = hollow.clone();
        if affine {
            let mut axes = scale.clone();
            axes.control_points = vec![vec![1.25, 0.75, 1.1]; 2];
            let mut center = scale.clone();
            center.control_points = vec![vec![0.01, -0.02, 0.03]; 2];
            variant["axis_scale"] = value_codec::json!(axes);
            variant["center_law"] = value_codec::json!(center);
        }
        let report = crate::dispatch(variant).unwrap();
        assert_eq!(
            report["boundaryContinuousBound"], true,
            "affine={affine}: {report}"
        );
        assert_eq!(report["boundaryErrorWithinBudget"], true);
        assert_eq!(report["filledCapErrorUpper"].as_array().unwrap().len(), 2);
    }
}

#[test]
fn literal_straight_corrected_affine_65_body_keeps_default_error_work() {
    let ring = |points: Vec<[f64; 3]>| {
        points
            .windows(2)
            .map(|p| nurbs_core::primitives::line(p[0], p[1]).unwrap())
            .collect::<Vec<_>>()
    };
    let outer = ring(vec![
        [0., 0., 0.],
        [2., 0., 0.],
        [2., 2., 0.],
        [0., 2., 0.],
        [0., 0., 0.],
    ]);
    let hole = ring(vec![
        [0.5, 0.5, 0.],
        [0.5, 1.5, 0.],
        [1.5, 1.5, 0.],
        [1.5, 0.5, 0.],
        [0.5, 0.5, 0.],
    ]);
    let constant = |v| nurbs_core::progressive_sweep::constant_vector_law(v).unwrap();
    let result=crate::dispatch(value_codec::json!({"op":"brep_nurbs_progressive_profile_body","loops":[outer,hole],
 "path":nurbs_core::primitives::line([0.;3],[0.,0.,10.]).unwrap(),"scale":constant([1.,0.,0.]),"twist":constant([0.;3]),
 "axis_scale":constant([2.,3.,1.]),"center_law":constant([0.125,-0.25,0.]),"normal":[1.,0.,0.],"orientation":"corrected_frenet","spacing":"parameter",
 "initial_sections":65,"max_sections":65,"max_deviation":0.01})).unwrap();
    assert_eq!(result["model"]["faces"].as_array().unwrap().len(), 514);
    assert_eq!(result["boundaryContinuousBound"], true, "{result}");
    assert_eq!(result["boundaryErrorWithinBudget"], true);
    assert!(
        result["approximation"]["report"]["errorCertificateCells"]
            .as_u64()
            .unwrap()
            <= 10000
    );
}

#[test]
fn nonplanar_corrected_regular_arc_body_owns_filled_caps() {
    let profile = nurbs_core::primitives::circle([0.; 3], [1., 0., 0.], 0.1).unwrap();
    let hole = nurbs_core::primitives::circle([0.; 3], [1., 0., 0.], 0.05)
        .unwrap()
        .reverse()
        .unwrap();
    let path = nurbs_core::paths::bezier(
        vec![
            vec![0., 0., 0.],
            vec![1., 0., 0.],
            vec![2., 1., 0.],
            vec![3., 1., 1.],
        ],
        None,
    )
    .unwrap();
    let constant = |v| nurbs_core::progressive_sweep::constant_vector_law(v).unwrap();
    let result=crate::dispatch(value_codec::json!({"op":"brep_nurbs_progressive_profile_body","loops":[[profile],[hole]],
 "path":path,"scale":constant([1.,0.,0.]),"twist":constant([0.;3]),"axis_scale":constant([1.25,0.75,1.1]),"center_law":constant([0.01,-0.02,0.03]),
 "normal":[0.,0.,1.],"orientation":"corrected_frenet","spacing":"arc_length","length_tolerance":1e-6,"length_max_cells":100000,
 "initial_sections":3,"max_sections":129,"max_deviation":0.05,
 "cap_correction_tolerance":1e-9,"cap_correction_quantum":2_f64.powi(-40),"cap_correction_max_work":1000000})).unwrap();
    assert_eq!(result["boundaryContinuousBound"], true, "{result}");
    assert_eq!(result["boundaryErrorWithinBudget"], true);
    assert_eq!(result["filledCapErrorUpper"].as_array().unwrap().len(), 2);
    assert!(result["boundaryErrorUpper"].as_f64().unwrap() <= 0.05);
    assert_eq!(result["globalEmbeddingCertified"], false);
}

#[test]
fn progressive_profile_circle_correction_transports_native_bound_and_refusals() {
    let profile=nurbs_core::primitives::circle([0.;3],[0.,0.,1.],0.5).unwrap();
    let path=nurbs_core::primitives::line([0.;3],[0.,0.,2.]).unwrap();
    let scale=nurbs_core::progressive_sweep::constant_vector_law([1.,0.,0.]).unwrap();
    let twist=nurbs_core::progressive_sweep::constant_vector_law([0.;3]).unwrap();
    let request=json!({"op":"brep_nurbs_progressive_profile_body","loops":[[profile]],"path":path,"scale":scale,"twist":twist,
        "normal":[1.,0.,0.],"orientation":"fixed","spacing":"parameter","initial_sections":3,"max_sections":3,"max_deviation":0.01,
        "circle_correction_tolerance":1e-9,"circle_correction_quantum":2_f64.powi(-40),"circle_correction_max_work":1000000,
        "cap_correction_tolerance":1e-9});
    let saved=request.clone();let result=dispatch(request.clone()).unwrap();assert_eq!(request,saved);
    assert_eq!(result["boundaryContinuousBound"],true);assert_eq!(result["boundaryErrorWithinBudget"],true);
    let displacement=result["profileCorrectionErrorUpper"].as_f64().unwrap();assert!(displacement>0. && displacement<=1e-9);
    assert!(result["filledCapErrorUpper"].as_array().unwrap().iter().all(|e|e.as_f64().unwrap()>=displacement));
    assert_eq!(result["globalEmbeddingCertified"],false);
    let mut exhausted=request.clone();exhausted["circle_correction_max_work"]=json!(0);
    assert!(dispatch(exhausted).err().unwrap().message.contains("profile circle correction refused"));
    let mut missing=request;missing.as_object_mut().unwrap().remove("circle_correction_tolerance");
    assert!(dispatch(missing).err().unwrap().message.contains("requires a displacement tolerance"));
}

#[test]
fn progressive_station_reconstruction_replays_source_and_audits_retained_jets(){
    use nurbs_core::{primitives::{circle,line},progressive_sweep::constant_vector_law};
    let request=json!({"op":"brep_nurbs_progressive_profile_body_reconstruct_stations",
        "loops":[[circle([0.;3],[0.,0.,1.],0.5).unwrap()]],
        "path":line([0.;3],[0.,0.,10.]).unwrap(),
        "scale":constant_vector_law([1.,0.,0.]).unwrap(),"twist":constant_vector_law([0.;3]).unwrap(),
        "normal":[1.,0.,0.],"orientation":"rmf","spacing":"parameter",
        "initial_sections":3,"max_sections":3,"max_deviation":0.01,
        "circle_correction_tolerance":1e-9,"circle_correction_quantum":0.125,"circle_correction_max_work":1000000,
        "station_quantum":0.125,"station_tolerance":1e-9,"station_max_work":1000000,"smoothness_max_work":2000000});
    let result=dispatch(request.clone()).unwrap();
    let r=&result["stationReconstruction"];
    assert_eq!(r["source"],"original-progressive-profile-request");
    assert_eq!(r["boundaryCertificate"]["continuousBound"],true);
    assert_eq!(r["boundaryCertificate"]["withinBudget"],true);
    assert_eq!(r["boundaryCertificate"]["budget"],0.01);
    assert_eq!(r["profileSmoothness"]["profile"]["exactG1G2Certified"],true);
    assert_eq!(r["profileSmoothness"]["station"]["stationG2Certified"],true);
    assert_eq!(r["globalEmbeddingCertified"],false);
    let model:brep_core::Model=field(&r["reconstruction"],"model").unwrap();
    let original:brep_core::Model=field(&result,"model").unwrap();
    brep_core::sweep_station_reconstruction::preserve_caps(&original,&model,false).unwrap();
    let mut bound=request.clone();bound["expected_source_model"]=result["model"].clone();
    assert_eq!(dispatch(bound.clone()).unwrap(),result);
    let coordinate=bound["expected_source_model"]["vertices"][0]["point"][0].as_f64().unwrap();
    bound["expected_source_model"]["vertices"][0]["point"][0]=json!(f64::from_bits(coordinate.to_bits()+1));
    let error=dispatch(bound).unwrap_err();
    assert!(error.to_string().contains("differs from native original constructor"));
    let mut forged=request.clone();forged["boundaryErrorUpper"]=json!(0.);
    forged["sections"]=json!([]);forged["model"]=json!({"invalid":true});
    assert_eq!(dispatch(forged).unwrap(),result);
    let mut exhausted=request.clone();exhausted["station_max_work"]=json!(0);
    let denied=dispatch(exhausted).unwrap();
    assert!(denied["stationReconstruction"]["reconstruction"].is_null());
    assert!(denied["stationReconstruction"]["profileSmoothness"].is_null());
    let mut missing=request;missing.as_object_mut().unwrap().remove("station_tolerance");
    assert!(dispatch(missing).is_err());
}

#[test]
fn curved_frame_station_reconstruction_preserves_transverse_profile_g2() {
    let law=|x|nurbs_core::progressive_sweep::constant_vector_law(x).unwrap();
    for orientation in ["rmf","fixed_normal","frenet","corrected_frenet"] {
    for spacing in ["parameter","arc_length"] {
    let request=json!({"op":"brep_nurbs_progressive_profile_body_reconstruct_stations",
        "loops":[[nurbs_core::primitives::circle([0.;3],[1.,0.,0.],0.05).unwrap()],
            [nurbs_core::primitives::circle([0.;3],[1.,0.,0.],0.025).unwrap().reverse().unwrap()]],
        "path":nurbs_core::paths::bezier(vec![vec![0.,0.,0.],vec![0.5,0.,0.],vec![1.,1.,0.]],None).unwrap(),
        "scale":law([1.,0.,0.]),"twist":law([0.;3]),"normal":[0.,0.,1.],"orientation":orientation,"spacing":spacing,"length_tolerance":0.0001,"length_max_cells":100000,
        "initial_sections":17,"max_sections":17,"max_deviation":0.05,
        "circle_correction_quantum":2_f64.powi(-40),"circle_correction_tolerance":1e-9,"circle_correction_max_work":1000000,
        "cap_correction_quantum":2_f64.powi(-40),"cap_correction_tolerance":1e-9,"cap_correction_max_work":1000000,
        "station_quantum":2_f64.powi(-40),"station_tolerance":0.01,"station_max_work":1000000,"smoothness_max_work":2000000});
    let original=request.clone();
    let result=dispatch(request.clone()).unwrap();
    assert_eq!(request,original);
    let r=&result["stationReconstruction"];
    assert_eq!(r["boundaryCertificate"]["withinBudget"],true,"{orientation}/{spacing}: {}",r["boundaryCertificate"]);
    assert_eq!(r["profileSmoothness"]["station"]["stationG2Certified"],true);
    assert_eq!(r["profileSmoothness"]["profile"]["exactG1G2Certified"],true,"{}",r["profileSmoothness"]);
    let source:brep_core::Model=field(&result,"model").unwrap();
    let retained:brep_core::Model=field(&r["reconstruction"],"model").unwrap();
    brep_core::sweep_station_reconstruction::preserve_caps(&source,&retained,false).unwrap();
    let caps=[retained.faces.len()-2,retained.faces.len()-1];
    let global=dispatch(json!({"op":"brep_sweep_volume_audit","model":retained,"capFaces":caps,
        "toleranceUv":1e-8,"maxExactWork":1000000,"maxTrimPairs":10000,"maxTrimCells":100000,"maxTrimDomainCells":1000000,
        "maxSpans":1024,"maxLinearCells":100000,"maxPairs":20000,"maxCells":200000,"maxDomainCells":1000000,
        "cellsPerPair":1000,"domainCellsPerPair":10000,"nestingPairs":1000,"nestingCells":100000,"nestingDomainCells":1000000,
        "orientationCells":100000,"orientationDomainCells":1000000,"orientationSpans":100,
        "capBudgets":{"maxWalls":1024,"maxExactWork":1000000,"maxChartCells":1000,"maxTrimPairs":100000,"maxTrimCells":100000,"maxTrimDomainCells":1000000}
    })).unwrap();
    assert_eq!(global["solidGeometryCertified"],true,"{orientation}: {global}");
    assert_eq!(global["allFacesInjective"],true);
    assert_eq!(global["allPairsClassified"],true);
    }
    }
}

#[test]
fn periodic_authored_arc_station_candidate_keeps_original_budgets() {
    let mut request: Value = value_codec::from_str(include_str!("fixtures/periodic-authored-station-request.json")).unwrap();
    request["loops"] = json!([[nurbs_core::primitives::circle(
        [-1.336111111111111,3.1694444444444443,-0.3388888888888889],
        [-20.133333333333333,-7.866666666666666,-4.266666666666667],0.01).unwrap()]]);
    request["scale"]=json!(nurbs_core::progressive_sweep::constant_vector_law([1.,0.,0.]).unwrap());
    request["twist"]=json!(nurbs_core::progressive_sweep::constant_vector_law([0.;3]).unwrap());
    let original=request.clone();
    let result=dispatch(request.clone()).unwrap();
    assert_eq!(request,original);
    let r=&result["stationReconstruction"];
    assert!(r["reconstruction"].is_object(),"{r}");
    assert_eq!(r["boundaryCertificate"]["continuousBound"],true,"{r}");
    assert_eq!(r["boundaryCertificate"]["withinBudget"],true);
    assert_eq!(r["boundaryCertificate"]["budget"],0.5);
    assert_eq!(r["profileSmoothness"]["station"]["stationG2Certified"],true,"{}",r["profileSmoothness"]);
    let model: brep_core::Model=field(&r["reconstruction"],"model").unwrap();
    assert!(model.faces.iter().all(|f| [5,13,25].contains(&f.surface.degree_v)));
    assert_eq!(r["profileSmoothness"]["profile"]["exactG1G2Certified"],true,"{}",r["profileSmoothness"]);
    let agreement=brep_core::boundary_agreement::verify_exact(&model,1000000).unwrap();
    assert!(agreement.all_equal && agreement.all_joins_exact,"work={} unresolved={:?}",agreement.work,
        agreement.uses.iter().filter(|u|!u.decision.as_ref().is_some_and(|d|d.outcome==cad_predicates::BezierIdentity::Equal)).map(|u|(u.face,u.coedge)).collect::<Vec<_>>());
    assert_eq!(agreement.uses.len(),model.faces.len()*4);
    let mut changed=model.clone();
    changed.faces[0].surface.control_points[0][3][0]=changed.faces[0].surface.control_points[0][3][0].next_up();
    assert!(!brep_core::boundary_agreement::verify_exact(&changed,1000000).unwrap().all_equal);
    let global=dispatch(json!({"op":"brep_sweep_volume_charts_audit","model":model,"capFaces":[],
        "toleranceUv":1e-8,"maxExactWork":1000000,"maxTrimPairs":10000,"maxTrimCells":100000,"maxTrimDomainCells":1000000,
        "maxSpans":1024,"maxLinearCells":100000,"maxPairs":20000,"maxCells":200000,"maxDomainCells":1000000,
        "cellsPerPair":1000,"domainCellsPerPair":10000,"nestingPairs":1000,"nestingCells":100000,"nestingDomainCells":1000000,
        "orientationCells":100000,"orientationDomainCells":1000000,"orientationSpans":100,
        "capBudgets":{"maxWalls":1024,"maxExactWork":1000000,"maxChartCells":1000,"maxTrimPairs":100000,"maxTrimCells":100000,"maxTrimDomainCells":1000000}
    })).unwrap();
    assert_eq!(global["solidGeometryCertified"],true,"{global}");
    assert_eq!(global["allFacesInjective"],true);
    assert_eq!(global["allPairsClassified"],true);
    let charts=dispatch(json!({"op":"brep_sweep_retained_charts_audit","model":model,"capFaces":[],"maxCells":100000})).unwrap();
    assert_eq!(global["retainedWallCharts"],charts,"Same actual chart proofs and original logical work must be preserved");
    assert_eq!(global["retainedWallCharts"]["allChartsCertified"],true);
    assert_eq!(global["retainedWallCharts"]["charts"].as_array().unwrap().len(),model.faces.len());
    request["expected_source_model"]=result["model"].clone();
    assert_eq!(dispatch(request).unwrap(),result);
}

#[test]
fn fresh_volume_chart_rpc_preserves_separate_reports_and_refuses_supplied_proofs() {
    let model=brep_core::cuboid([0.;3],[1.;3]).unwrap();
    let request=json!({"op":"brep_sweep_volume_audit","model":model,"capFaces":[4,5],
        "toleranceUv":1e-8,"maxExactWork":1000000,"maxTrimPairs":10000,"maxTrimCells":100000,"maxTrimDomainCells":1000000,
        "maxSpans":1024,"maxLinearCells":100000,"maxPairs":20000,"maxCells":200000,"maxDomainCells":1000000,
        "cellsPerPair":1000,"domainCellsPerPair":10000,"nestingPairs":1000,"nestingCells":100000,"nestingDomainCells":1000000,
        "orientationCells":100000,"orientationDomainCells":1000000,"orientationSpans":100,
        "capBudgets":{"maxWalls":1024,"maxExactWork":1000000,"maxChartCells":1000,"maxTrimPairs":100000,"maxTrimCells":100000,"maxTrimDomainCells":1000000}});
    let original=request.clone();
    let separate=dispatch(request.clone()).unwrap();
    let charts=dispatch(json!({"op":"brep_sweep_retained_charts_audit","model":model,"capFaces":[4,5],"maxCells":100000})).unwrap();
    let mut paired=request.clone();paired["op"]=json!("brep_sweep_volume_charts_audit");
    paired["retainedWallCharts"]=json!({"allChartsCertified":false,"cells":0});
    let combined=dispatch(paired.clone()).unwrap();
    assert_eq!(combined["retainedWallCharts"],charts);
    assert_eq!(combined["retainedWallCharts"]["charts"].as_array().unwrap().len(),4);
    let mut volume=combined;volume.as_object_mut().unwrap().remove("retainedWallCharts");
    assert_eq!(volume,separate);assert_eq!(request,original);
    let mut zero=paired.clone();zero["maxLinearCells"]=json!(0);
    zero["retainedWallCharts"]=json!({"allChartsCertified":true,"cells":0});
    let zero_result=dispatch(zero).unwrap();
    assert_eq!(zero_result["retainedWallCharts"]["allChartsCertified"],false);
    assert_eq!(zero_result["retainedWallCharts"]["cells"],0);
    paired["capFaces"]=json!([4,4]);assert!(dispatch(paired).is_err());
}

#[test]
fn closed_frenet_arc_station_bodies_keep_original_bounds_and_fresh_global_solid() {
    let law=|x|nurbs_core::progressive_sweep::constant_vector_law(x).unwrap();
    for periodic in [false,true] {for hollow in [false,true] {
        let path=if periodic {
            let mut points=vec![vec![4.,0.,0.],vec![3.,3.,1.],vec![0.,4.,0.],vec![-3.,3.,-1.],vec![-4.,0.,0.],vec![-3.,-3.,1.],vec![0.,-4.,0.],vec![3.,-3.,-1.]];points.extend_from_within(..6);
            Curve{degree:6,knots:(0..=20).map(|i|(i as f64-6.)/8.).collect(),control_points:points,weights:vec![1.;14],periodic:true}
        } else {nurbs_core::primitives::circle([0.;3],[0.,0.,1.],5.).unwrap()};
        let (center,tangent)=if periodic {([-1.336111111111111,3.1694444444444443,-0.3388888888888889],[-20.133333333333333,-7.866666666666666,-4.266666666666667])}
            else {([5.,0.,0.],[0.,1.,0.])};
        let mut loops=vec![vec![nurbs_core::primitives::circle(center,tangent,0.01).unwrap()]];
        if hollow {loops.push(vec![nurbs_core::primitives::circle(center,tangent,0.005).unwrap().reverse().unwrap()]);}
        let budget=if periodic {0.5}else{2.};
        let request=json!({"op":"brep_nurbs_progressive_profile_body_reconstruct_stations","loops":loops,
            "path":path,"scale":law([1.,0.,0.]),"twist":law([0.;3]),"normal":[0.,0.,1.],"orientation":"frenet","spacing":"arc_length",
            "length_tolerance":0.0001,"length_max_cells":100000,"initial_sections":33,"max_sections":129,"max_deviation":budget,
            "circle_correction_quantum":2_f64.powi(-40),"circle_correction_tolerance":1e-9,"circle_correction_max_work":1000000,
            "station_quantum":2_f64.powi(-40),"station_tolerance":0.01,"station_max_work":1000000,"smoothness_max_work":2000000});
        let original=request.clone();let result=dispatch(request.clone()).unwrap();assert_eq!(request,original);
        let r=&result["stationReconstruction"];
        assert_eq!(r["boundaryCertificate"]["continuousBound"],true,"periodic={periodic}, hollow={hollow}: {r}");
        assert_eq!(r["boundaryCertificate"]["withinBudget"],true,"periodic={periodic}, hollow={hollow}: {}",r["boundaryCertificate"]);
        assert_eq!(r["boundaryCertificate"]["budget"],budget);
        assert_eq!(r["profileSmoothness"]["profile"]["exactG1G2Certified"],true,"{}",r["profileSmoothness"]);
        assert_eq!(r["profileSmoothness"]["station"]["stationG2Certified"],true,"{}",r["profileSmoothness"]);
        let model:brep_core::Model=field(&r["reconstruction"],"model").unwrap();
        assert_eq!(model.shells.len(),if hollow {2}else{1});
        let agreement=brep_core::boundary_agreement::verify_exact(&model,1000000).unwrap();
        assert!(agreement.all_equal&&agreement.all_joins_exact,"work={}, unresolved={:?}",agreement.work,agreement.uses.iter().filter(|u|!u.decision.as_ref().is_some_and(|d|d.outcome==cad_predicates::BezierIdentity::Equal)).map(|u|(u.face,u.coedge)).collect::<Vec<_>>());
        let global=dispatch(json!({"op":"brep_sweep_volume_charts_audit","model":model,"capFaces":[],
            "toleranceUv":1e-8,"maxExactWork":1000000,"maxTrimPairs":10000,"maxTrimCells":100000,"maxTrimDomainCells":1000000,
            "maxSpans":1024,"maxLinearCells":100000,"maxPairs":20000,"maxCells":200000,"maxDomainCells":1000000,
            "cellsPerPair":1000,"domainCellsPerPair":10000,"nestingPairs":1000,"nestingCells":100000,"nestingDomainCells":1000000,
            "orientationCells":100000,"orientationDomainCells":1000000,"orientationSpans":100,
            "capBudgets":{"maxWalls":1024,"maxExactWork":1000000,"maxChartCells":1000,"maxTrimPairs":100000,"maxTrimCells":100000,"maxTrimDomainCells":1000000}})).unwrap();
        assert_eq!(global["solidGeometryCertified"],true,"periodic={periodic}, hollow={hollow}: {global}");
        assert_eq!(global["allFacesInjective"],true);assert_eq!(global["allPairsClassified"],true);
        assert_eq!(global["retainedWallCharts"]["allChartsCertified"],true);
        assert_eq!(global["retainedWallCharts"]["charts"].as_array().unwrap().len(),model.faces.len());
        eprintln!("closed Frenet retained body: periodic={periodic}, hollow={hollow}, faces={}, bound={}",model.faces.len(),r["boundaryCertificate"]["errorUpper"]);
    }}
}

#[test]
fn closed_frenet_hollow_first_independent_pair_keeps_original_contact_limits() {
    let law=|x|nurbs_core::progressive_sweep::constant_vector_law(x).unwrap();
    let request=json!({"op":"brep_nurbs_progressive_profile_body_reconstruct_stations",
        "loops":[[nurbs_core::primitives::circle([5.,0.,0.],[0.,1.,0.],0.01).unwrap()],
            [nurbs_core::primitives::circle([5.,0.,0.],[0.,1.,0.],0.005).unwrap().reverse().unwrap()]],
        "path":nurbs_core::primitives::circle([0.;3],[0.,0.,1.],5.).unwrap(),
        "scale":law([1.,0.,0.]),"twist":law([0.;3]),"normal":[0.,0.,1.],"orientation":"frenet","spacing":"arc_length",
        "length_tolerance":0.0001,"length_max_cells":100000,"initial_sections":33,"max_sections":129,"max_deviation":2.,
        "circle_correction_quantum":2_f64.powi(-40),"circle_correction_tolerance":1e-9,"circle_correction_max_work":1000000,
        "station_quantum":2_f64.powi(-40),"station_tolerance":0.01,"station_max_work":1000000,"smoothness_max_work":2000000});
    let original=request.clone();let result=dispatch(request.clone()).unwrap();assert_eq!(request,original);
    let retained=&result["stationReconstruction"];
    assert_eq!(retained["boundaryCertificate"]["withinBudget"],true);
    assert_eq!(retained["profileSmoothness"]["profile"]["exactG1G2Certified"],true);
    assert_eq!(retained["profileSmoothness"]["station"]["stationG2Certified"],true);
    let model:brep_core::Model=field(&retained["reconstruction"],"model").unwrap();
    assert_eq!(model.faces.len(),256);assert_eq!(model.shells.len(),2);
    if let Ok(path)=std::env::var("SWEEP_MODEL_DUMP") {
        std::fs::write(path,value_codec::to_string(&model).unwrap()).unwrap();
    }
    let domains=[0,7].map(|index|{
        let face=&model.faces[index];
        let loops=std::iter::once(face.outer).chain(face.holes.iter().copied())
            .map(|wire|model.loops[wire].coedges.iter().map(|c|c.pcurve.clone()).collect::<Vec<_>>()).collect::<Vec<_>>();
        nurbs_core::trim_domain::TrimDomain::new(&loops,1e-8).unwrap()
    });
    let report=nurbs_core::surface_contact_search::search_trimmed_with_control_hulls(
        &model.faces[0].surface,&model.faces[7].surface,[&domains[0],&domains[1]],1000,10000).unwrap();
    assert_eq!(report.cells, 361);
    assert_eq!(report.domain_cells, 2889);
    eprintln!("original hollow pair[0,7]: cells={}, domain_cells={}, unresolved={}, witness={}",
        report.cells,report.domain_cells,report.unresolved.len(),report.contact.is_some());
    assert!(report.absence_proven,"Original independent outer/inner pair must be covered at unchanged limits");
    assert!(report.contact.is_none());
}

// Prepared for isolated Q after its current full bridge process is terminal.
// Original periodic source, circles, tolerances and full global budgets retained.
#[test]
fn periodic_fixed_normal_arc_station_bodies_keep_original_bounds_and_fresh_global_solid() {
    let law=|x|nurbs_core::progressive_sweep::constant_vector_law(x).unwrap();
    for joint in [false,true] {for periodic in [true] {for hollow in [false,true] {
        let path=if periodic {
            let mut points=vec![vec![4.,0.,0.],vec![3.,3.,1.],vec![0.,4.,0.],vec![-3.,3.,-1.],vec![-4.,0.,0.],vec![-3.,-3.,1.],vec![0.,-4.,0.],vec![3.,-3.,-1.]];points.extend_from_within(..6);
            Curve{degree:6,knots:(0..=20).map(|i|(i as f64-6.)/8.).collect(),control_points:points,weights:vec![1.;14],periodic:true}
        } else {nurbs_core::primitives::circle([0.;3],[0.,0.,1.],5.).unwrap()};
        let (center,tangent)=if periodic {([-1.336111111111111,3.1694444444444443,-0.3388888888888889],[-20.133333333333333,-7.866666666666666,-4.266666666666667])}
            else {([5.,0.,0.],[0.,1.,0.])};
        let mut loops=vec![vec![nurbs_core::primitives::circle(center,tangent,0.01).unwrap()]];
        if hollow {loops.push(vec![nurbs_core::primitives::circle(center,tangent,0.005).unwrap().reverse().unwrap()]);}
        let budget=if periodic {0.5}else{2.};
        let mut request=json!({"op":"brep_nurbs_progressive_profile_body_reconstruct_stations","loops":loops,
            "path":path,"scale":law([1.,0.,0.]),"twist":law([0.;3]),"normal":[0.,0.,1.],"orientation":"fixed_normal","spacing":"arc_length",
            "length_tolerance":0.0001,"length_max_cells":100000,"initial_sections":33,"max_sections":129,"max_deviation":budget,
            "circle_correction_quantum":2_f64.powi(-40),"circle_correction_tolerance":1e-9,"circle_correction_max_work":1000000,
            "station_quantum":2_f64.powi(-40),"station_tolerance":0.01,"station_max_work":1000000,"smoothness_max_work":2000000});
        if joint {
            request["axis_scale"]=json!(law([1.5,0.75,1.]));
            request["center_law"]=json!(law([0.005,-0.0025,0.]));
        }
        let original=request.clone();let result=dispatch(request.clone()).unwrap();assert_eq!(request,original);
        let r=&result["stationReconstruction"];
        assert_eq!(r["boundaryCertificate"]["continuousBound"],true,"periodic={periodic}, hollow={hollow}: {r}");
        assert_eq!(r["boundaryCertificate"]["withinBudget"],true,"periodic={periodic}, hollow={hollow}: {}",r["boundaryCertificate"]);
        assert_eq!(r["boundaryCertificate"]["budget"],budget);
        assert_eq!(r["profileSmoothness"]["profile"]["exactG1G2Certified"],true,"{}",r["profileSmoothness"]);
        assert_eq!(r["profileSmoothness"]["station"]["stationG2Certified"],true,"{}",r["profileSmoothness"]);
        let model:brep_core::Model=field(&r["reconstruction"],"model").unwrap();
        assert_eq!(model.shells.len(),if hollow {2}else{1});
        let agreement=brep_core::boundary_agreement::verify_exact(&model,1000000).unwrap();
        assert!(agreement.all_equal&&agreement.all_joins_exact,"work={}, unresolved={:?}",agreement.work,agreement.uses.iter().filter(|u|!u.decision.as_ref().is_some_and(|d|d.outcome==cad_predicates::BezierIdentity::Equal)).map(|u|(u.face,u.coedge)).collect::<Vec<_>>());
        let global=dispatch(json!({"op":"brep_sweep_volume_charts_audit","model":model,"capFaces":[],
            "toleranceUv":1e-8,"maxExactWork":1000000,"maxTrimPairs":10000,"maxTrimCells":100000,"maxTrimDomainCells":1000000,
            "maxSpans":1024,"maxLinearCells":100000,"maxPairs":20000,"maxCells":200000,"maxDomainCells":1000000,
            "cellsPerPair":1000,"domainCellsPerPair":10000,"nestingPairs":1000,"nestingCells":100000,"nestingDomainCells":1000000,
            "orientationCells":100000,"orientationDomainCells":1000000,"orientationSpans":100,
            "capBudgets":{"maxWalls":1024,"maxExactWork":1000000,"maxChartCells":1000,"maxTrimPairs":100000,"maxTrimCells":100000,"maxTrimDomainCells":1000000}})).unwrap();
        assert_eq!(global["solidGeometryCertified"],true,"periodic={periodic}, hollow={hollow}: {global}");
        assert_eq!(global["allFacesInjective"],true);assert_eq!(global["allPairsClassified"],true);
        assert_eq!(global["retainedWallCharts"]["allChartsCertified"],true);
        assert_eq!(global["retainedWallCharts"]["charts"].as_array().unwrap().len(),model.faces.len());
        eprintln!("periodic FixedNormal retained body: joint={joint}, periodic={periodic}, hollow={hollow}, faces={}, bound={}",model.faces.len(),r["boundaryCertificate"]["errorUpper"]);
    }}}
}

#[test]
fn original_periodic_fixed_normal_affine_hollow_requires_complete_global_cover() {
    let model:brep_core::Model=value_codec::from_str(include_str!("fixtures/periodic-fixed-normal-affine-hollow-model.json")).unwrap();
    assert_eq!(model.faces.len(),256);assert_eq!(model.shells.len(),2);
    let result=dispatch(json!({"op":"brep_sweep_volume_charts_audit","model":model,"capFaces":[],
        "toleranceUv":1e-8,"maxExactWork":1000000,"maxTrimPairs":10000,"maxTrimCells":100000,"maxTrimDomainCells":1000000,
        "maxSpans":1024,"maxLinearCells":100000,"maxPairs":20000,"maxCells":200000,"maxDomainCells":1000000,
        "cellsPerPair":1000,"domainCellsPerPair":10000,"nestingPairs":1000,"nestingCells":100000,"nestingDomainCells":1000000,
        "orientationCells":100000,"orientationDomainCells":1000000,"orientationSpans":100,
        "capBudgets":{"maxWalls":1024,"maxExactWork":1000000,"maxChartCells":1000,"maxTrimPairs":100000,"maxTrimCells":100000,"maxTrimDomainCells":1000000}})).unwrap();
    if let Ok(path)=std::env::var("SWEEP_DUAL_GLOBAL_DUMP") {
        std::fs::write(path,value_codec::to_string(&result).unwrap()).unwrap();
    }
    eprintln!("original affine hollow: charts={}, unresolved={}, pairs={}, cells={}, domainCells={}",
        result["retainedWallCharts"]["allChartsCertified"],result["retainedWallCharts"]["unresolvedFaces"],
        result["allPairsClassified"],result["contactCells"],result["contactDomainCells"]);
    assert_eq!(result["retainedWallCharts"]["allChartsCertified"],true,"{}",result["retainedWallCharts"]["unresolvedFaces"]);
    assert_eq!(result["allFacesInjective"],true);assert_eq!(result["allPairsClassified"],true);
    assert_eq!(result["solidGeometryCertified"],true);
}
