//! Bounded enumeration of different face pairs. Adjacent faces are not skipped:
//! sharing topology does not prove the absence of extra interior intersections.
#[path = "boundary_stitched_contact.rs"]
mod boundary_stitched_contact;
#[path = "source_volume_contact.rs"]
mod source_volume_contact;
#[path = "same_support_contact.rs"]
mod same_support_contact;
#[path = "projected_trim_contact.rs"]
mod projected_trim_contact;
#[path = "projected_trim_network.rs"]
mod projected_trim_network;
use crate::face_contact_groups::Certificate as DisjointGroup;
use crate::{Error, Model, Result, face_domain::FaceDomain};
use nurbs_core::surface_contact_search::{self, Report as Search};
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    /// Maximum individually classified pairs. Sweep range certificates use
    /// the shared geometry-cell budget instead and are reported separately.
    pub pairs: usize,
    pub cells: usize,
    pub domain_cells: usize,
    pub cells_per_pair: usize,
    pub domain_cells_per_pair: usize,
}
#[derive(Clone, Debug)]
pub enum SharedBoundary {
    SweepCap {
        cap: usize,
        wall: usize,
        edge: usize,
    },
    ExactHull(crate::boundary_hull_contact::Certificate),
    PlanarFace(crate::shared_boundary::Certificate),
    OppositeSides(crate::shared_boundary::OppositeSidesCertificate),
    BilinearGraph(crate::shared_boundary::bilinear_graph::Certificate),
    ClosedGraph(crate::shared_boundary::closed_graph::Certificate),
    JoinedSourceCharts(boundary_stitched_contact::Certificate),
    SourceVolumeBoundary(source_volume_contact::Certificate),
    OwnedVertex(crate::trimmed_vertex_contact::Certificate),
    SameSupportPartition(same_support_contact::Certificate),
    ProjectedTrimPartition(projected_trim_contact::Certificate),
    ProjectedTrimNetwork(projected_trim_network::Certificate),
}
#[derive(Clone, Debug)]
pub struct Pair {
    pub faces: [usize; 2],
    pub result: Option<Search>,
    pub boundary: Option<SharedBoundary>,
    /// Disjointness was proven exactly by control-hull separation, so no
    /// trimmed search report exists for this pair.
    pub hull_disjoint: bool,
    /// Exact control-hull separation work spent on this pair. Attributed to
    /// the pair so per-pair work adds up to the report totals.
    pub hull_cells: usize,
    /// Charged shared-boundary admission work, including exact vertex contacts.
    pub boundary_cells: usize,
    pub source_chart_cells: usize,
    pub volume_separation: Option<source_volume_contact::Certificate>,
    pub reason: &'static str,
}
#[derive(Clone, Debug)]
pub struct Report {
    pub pairs: Vec<Pair>,
    pub disjoint_groups: Vec<DisjointGroup>,
    pub grouped_pairs: usize,
    /// Includes preparation and unsuccessful group attempts.
    pub group_cells: usize,
    pub total_pairs: usize,
    /// First unvisited pair in lexicographic order; the entire suffix is pending.
    pub next_pair: Option<[usize; 2]>,
    pub cells: usize,
    pub domain_cells: usize,
    /// All distinct face pairs were proven disjoint. This says nothing about
    /// self-intersection inside one face or geometric validity of a volume.
    pub all_pairs_disjoint: bool,
    pub all_pairs_classified: bool,
}
pub fn inspect(model: &Model, tolerance_uv: f64, limits: Limits) -> Result<Report> {
    inspect_with_hulls(model, tolerance_uv, limits, &[])
}
/// Scope is exactly the pairs incident to `face`; this cannot certify the
/// remaining body pairs or self-intersections within any individual face.
pub struct IncidentReport {
    pub face: usize,
    pub pairs: Vec<Pair>,
    pub total_pairs: usize,
    pub next_pair: Option<[usize; 2]>,
    pub cells: usize,
    pub domain_cells: usize,
    pub all_incident_pairs_classified: bool,
    pub all_incident_pairs_disjoint: bool,
    /// Additional exact vertex work; legacy pair-search work is separate.
    pub vertex_exact_work: u64,
}
pub fn inspect_incident(
    model: &Model,
    face: usize,
    tolerance_uv: f64,
    limits: Limits,
) -> Result<IncidentReport> {
    if face >= model.faces.len() {
        return Err(Error::new(
            "BREP_CONTACT_FACE",
            "Incident face index is out of range",
        ));
    }
    let mut inspector = Inspector::new(
        std::sync::Arc::new(model.clone()),
        tolerance_uv,
        limits,
        vec![],
        vec![],
        false,
        false,
        None,
    )?;
    inspector.incident = Some(face);
    inspector.report.total_pairs = model.faces.len() - 1;
    while !inspector.finished() {
        inspector.advance(64)?;
    }
    let r = inspector.finish()?;
    Ok(IncidentReport {
        face,
        pairs: r.pairs,
        total_pairs: r.total_pairs,
        next_pair: r.next_pair,
        cells: r.cells,
        domain_cells: r.domain_cells,
        all_incident_pairs_classified: r.all_pairs_classified,
        all_incident_pairs_disjoint: r.all_pairs_disjoint,
        vertex_exact_work: 0,
    })
}
/// Extend the same scoped search with freshly proven exact owned-vertex
/// contacts. A metric locality bound never promotes the pair's exact status.
pub fn inspect_incident_with_vertices(
    model: &Model,
    face: usize,
    tolerance_uv: f64,
    limits: Limits,
    max_exact: u64,
) -> Result<IncidentReport> {
    if max_exact > 1000000 {
        return Err(Error::new(
            "BREP_CONTACT_BUDGET",
            "Exact vertex work exceeds its bounded allowance",
        ));
    }
    let mut report = inspect_incident(model, face, tolerance_uv, limits)?;
    for pair in &mut report.pairs {
        if pair.reason != "pair-unresolved" {
            continue;
        }
        if report.cells == limits.cells
            || report.domain_cells == limits.domain_cells
            || report.vertex_exact_work == max_exact
        {
            break;
        }
        let allowance = (limits.cells - report.cells)
            .min(limits.domain_cells - report.domain_cells)
            .min(100000);
        let attempt = crate::trimmed_vertex_contact::inspect(
            model,
            pair.faces,
            allowance,
            max_exact - report.vertex_exact_work,
        )?;
        report.cells += attempt.cells;
        report.vertex_exact_work += attempt.exact_work;
        // The vertex primitive has one combined geometry/trim ledger. Charge
        // all its work to the UV allowance too, rather than omit trim work.
        report.domain_cells += attempt.cells;
        pair.boundary_cells += attempt.cells;
        if let Some(c) = attempt.certificate.filter(|c| c.exact_vertex_contact) {
            pair.boundary = Some(SharedBoundary::OwnedVertex(c));
            pair.reason = "shared-vertex";
        }
    }
    report.all_incident_pairs_classified = report.next_pair.is_none()
        && report.pairs.len() == report.total_pairs
        && report.pairs.iter().all(|p| {
            p.boundary.is_some()
                || p.hull_disjoint
                || p.result.as_ref().is_some_and(|r| r.absence_proven)
        });
    // Exact vertex contact is a real contact, never a disjointness proof.
    Ok(report)
}
/// Hull certificates are admitted only by the exact boundary embedding audit.
pub(crate) fn inspect_with_hulls(
    model: &Model,
    tolerance_uv: f64,
    limits: Limits,
    hulls: &[crate::boundary_hull_contact::Certificate],
) -> Result<Report> {
    inspect_with_certificates(model, tolerance_uv, limits, hulls, &[], false)
}
/// Cap tuples originate only from native recomputation in boundary embedding.
pub(crate) fn inspect_with_certificates(
    model: &Model,
    tolerance_uv: f64,
    limits: Limits,
    hulls: &[crate::boundary_hull_contact::Certificate],
    caps: &[[usize; 3]],
    joint_exact_domain: bool,
) -> Result<Report> {
    inspect_impl(
        model,
        tolerance_uv,
        limits,
        hulls,
        caps,
        !caps.is_empty(),
        joint_exact_domain,
        None,
    )
}
/// Sweep-only exact hull separation, also for closed bodies without caps.
/// Every plane is proved on actual positive rational control coefficients.
#[allow(dead_code)]
pub(crate) fn inspect_with_sweep_certificates(
    model: &Model,
    tolerance_uv: f64,
    limits: Limits,
    hulls: &[crate::boundary_hull_contact::Certificate],
    caps: &[[usize; 3]],
    joint_exact_domain: bool,
) -> Result<Report> {
    inspect_impl(
        model,
        tolerance_uv,
        limits,
        hulls,
        caps,
        true,
        joint_exact_domain,
        None,
    )
}
/// Prepared only by the same immutable-model boundary audit. The charged
/// count includes preparation and any earlier cap separation queries.
#[allow(dead_code)]
pub(crate) fn inspect_with_prepared_sweep_certificates(
    model: &Model,
    tolerance_uv: f64,
    limits: Limits,
    hulls: &[crate::boundary_hull_contact::Certificate],
    caps: &[[usize; 3]],
    joint_exact_domain: bool,
    prepared: (Option<crate::face_contact_groups::Cover>, usize),
) -> Result<Report> {
    inspect_impl(
        model,
        tolerance_uv,
        limits,
        hulls,
        caps,
        true,
        joint_exact_domain,
        Some(prepared),
    )
}
fn inspect_impl(
    model: &Model,
    tolerance_uv: f64,
    limits: Limits,
    hulls: &[crate::boundary_hull_contact::Certificate],
    caps: &[[usize; 3]],
    sweep_hulls: bool,
    joint_exact_domain: bool,
    prepared: Option<(Option<crate::face_contact_groups::Cover>, usize)>,
) -> Result<Report> {
    let mut inspector = Inspector::new(std::sync::Arc::new(model.clone()), tolerance_uv,
        limits, hulls.to_vec(), caps.to_vec(), sweep_hulls, joint_exact_domain, prepared)?;
    while !inspector.finished() { inspector.advance(64)?; }
    inspector.finish()
}

/// Owns the exact model and cumulative work ledger throughout pair traversal.
/// Intermediate steps expose work counts, never a partial positive certificate.
pub(crate) struct Inspector {
    model: std::sync::Arc<Model>,
    limits: Limits,
    hulls: Vec<crate::boundary_hull_contact::Certificate>,
    caps: Vec<[usize; 3]>,
    sweep_hulls: bool,
    joint_exact_domain: bool,
    domains: Vec<FaceDomain>,
    cover: Option<crate::face_contact_groups::Cover>,
    report: Report,
    cursor: usize,
    pending: Vec<usize>,
    scalar_next: usize,
    done: bool,
    failed: bool,
    incident: Option<usize>,
}
impl Inspector {
    pub(crate) fn new(
        model: std::sync::Arc<Model>,
        tolerance_uv: f64,
        limits: Limits,
        hulls: Vec<crate::boundary_hull_contact::Certificate>,
        caps: Vec<[usize; 3]>,
        sweep_hulls: bool,
        joint_exact_domain: bool,
        prepared: Option<(Option<crate::face_contact_groups::Cover>, usize)>,
    ) -> Result<Self> {
        model.validate_boundary_diagnostic_inputs()?;
        if !(1..=100_000).contains(&limits.pairs)
            || !(1..=1_000_000).contains(&limits.cells)
            || !(1..=8_000_000).contains(&limits.domain_cells)
            || !(1..=100_000).contains(&limits.cells_per_pair)
            || !(1..=1_000_000).contains(&limits.domain_cells_per_pair)
            || !tolerance_uv.is_finite()
            || tolerance_uv <= 0.
        {
            return Err(Error::new(
                "BREP_CONTACT_BUDGET",
                "Use positive bounded pair, geometry and UV budgets and finite positive UV tolerance",
            ));
        }
        // Prepare each chart once, rather than validate/copy the model per pair.
        let domains = (0..model.faces.len())
            .map(|f| FaceDomain::new(&model, f, tolerance_uv))
            .collect::<Result<Vec<_>>>()?;
        let n = model.faces.len();
        let total_pairs = n
            .checked_mul(n.saturating_sub(1))
            .ok_or_else(|| Error::new("BREP_CONTACT_BUDGET", "Too many face pairs"))?
            / 2;
        let mut out = Report {
            pairs: Vec::new(),
            disjoint_groups: Vec::new(),
            grouped_pairs: 0,
            group_cells: 0,
            total_pairs,
            next_pair: None,
            cells: 0,
            domain_cells: 0,
            all_pairs_disjoint: true,
            all_pairs_classified: true,
        };
        let cover = if sweep_hulls && n > 1 {
            let (cover, cells) = prepared.unwrap_or_else(|| {
                crate::face_contact_groups::Cover::prepare(&model, limits.cells)
            });
            out.cells += cells;
            out.group_cells += cells;
            cover
        } else {
            None
        };
        let pending = cover.as_ref().map(|c| vec![c.root]).unwrap_or_default();
        Ok(Self {
            model,
            limits,
            hulls,
            caps,
            sweep_hulls,
            joint_exact_domain,
            domains,
            cover,
            report: out,
            cursor: 0,
            pending,
            scalar_next: 1,
            done: n < 2,
            failed: false,
            incident: None,
        })
    }
    pub(crate) fn finished(&self) -> bool {
        self.done
    }
    /// One unit visits a cover node or attempts the next scalar pair.
    pub(crate) fn advance(&mut self, max_units: usize) -> Result<usize> {
        if !(1..=100_000).contains(&max_units) {
            return Err(Error::new(
                "BREP_CONTACT_STEP",
                "Use a positive bounded traversal step",
            ));
        }
        if self.failed {
            return Err(Error::new(
                "BREP_CONTACT_FAILED",
                "Discard a failed traversal before retrying",
            ));
        }
        let result = self.advance_inner(max_units);
        self.failed = result.is_err();
        result
    }
    fn advance_inner(&mut self, max_units: usize) -> Result<usize> {
        if self.done {
            return Ok(0);
        }
        let model = self.model.as_ref();
        let source_volume_context = self
            .joint_exact_domain
            .then(|| source_volume_contact::Prepared::new(model));
        let limits = self.limits;
        let hulls = &self.hulls;
        let caps = &self.caps;
        let sweep_hulls = self.sweep_hulls;
        let joint_exact_domain = self.joint_exact_domain;
        let domains = &self.domains;
        let cover = &self.cover;
        let out = &mut self.report;
        let cursor = &mut self.cursor;
        let pending = &mut self.pending;
        let scalar_next = &mut self.scalar_next;
        let done = &mut self.done;
        let n = model.faces.len();
        let incident=self.incident;
        let mut used = 0;
        while *cursor < n && used < max_units {
            used += 1;
            let a = *cursor;
            let b = if let Some(cover) = &cover {
                let Some(index) = pending.pop() else {
                    *cursor += 1;
                    *scalar_next = *cursor + 1;
                    pending.push(cover.root);
                    continue;
                };
                let node = &cover.nodes[index];
                if node.range[1] <= a + 1 {
                    continue;
                }
                if node.range[0] > a && node.children.is_some() {
                    if out.cells == limits.cells {
                        out.next_pair = Some([a, node.range[0]]);
                        out.all_pairs_disjoint = false;
                        out.all_pairs_classified = false;
                        *done = true;
                        return Ok(used);
                    }
                    out.cells += 1;
                    out.group_cells += 1;
                    if let Some(certificate) = cover.certify(a, index) {
                        out.grouped_pairs += certificate.range[1] - certificate.range[0];
                        out.disjoint_groups.push(certificate);
                        continue;
                    }
                }
                if let Some([left, right]) = node.children {
                    pending.push(right);
                    pending.push(left);
                    continue;
                }
                node.range[0]
            } else {
                if let Some(face)=incident {
                    if a<face {
                        *cursor+=1;*scalar_next=*cursor+1;
                        face
                    }else if a>face {
                        *cursor=n;continue;
                    }else {
                        if *scalar_next==n {*cursor=n;continue;}
                        let b=*scalar_next;*scalar_next+=1;b
                    }
                }else {
                if *scalar_next == n {
                    *cursor += 1;
                    *scalar_next = *cursor + 1;
                    continue;
                }
                let b = *scalar_next;
                *scalar_next += 1;
                b
                }
            };
            if out.pairs.len() == limits.pairs
                || out.cells == limits.cells
                || out.domain_cells == limits.domain_cells
            {
                out.next_pair = Some([a, b]);
                out.all_pairs_disjoint = false;
                out.all_pairs_classified = false;
                *done = true;
                        return Ok(used);
            }
            let sa = &model.faces[a].surface;
            let sb = &model.faces[b].surface;
            let mut boundary = if let Some(c) = caps
                .iter()
                .find(|c| [c[0].min(c[1]), c[0].max(c[1])] == [a, b])
            {
                Some(SharedBoundary::SweepCap {
                    cap: c[0],
                    wall: c[1],
                    edge: c[2],
                })
            } else if let Some(c) = hulls.iter().find(|c| c.faces == [a, b]) {
                Some(SharedBoundary::ExactHull(c.clone()))
            } else if let Some(c) = joint_exact_domain
                .then(|| crate::boundary_hull_contact::certify(model, [a, b]))
                .flatten()
            {
                // Only the joint embedding audit authorizes this recomputation.
                // The same individual-pair limit bounds all such attempts,
                // including pairs beyond the old lexicographic prefix.
                Some(SharedBoundary::ExactHull(c))
            } else if let Some(c) = crate::shared_boundary::certify(model, [a, b]) {
                Some(SharedBoundary::PlanarFace(c))
            } else if let Some(c) = joint_exact_domain.then(|| crate::shared_boundary::bilinear_graph::certify(model, [a,b], 131072)).flatten() {
                Some(SharedBoundary::BilinearGraph(c))
            } else {
                crate::shared_boundary::certify_opposite(model, [a, b])?
                    .map(SharedBoundary::OppositeSides)
            };
            let mut boundary_cells = 0;


            if boundary.is_none() && sweep_hulls && joint_exact_domain {
                let allowance = (limits.cells - out.cells)
                    .min(limits.cells_per_pair.saturating_sub(boundary_cells))
                    .min(100000);
                let (certificate, used) =
                    crate::shared_boundary::certify_opposite_with_budget(model, [a, b], allowance);
                boundary_cells += used;
                out.cells += used;
                if let Some(c) = certificate {
                    boundary = Some(SharedBoundary::OppositeSides(c));
                }
            }
            let periodic = sa.periodic_u || sa.periodic_v || sb.periodic_u || sb.periodic_v;
            let pair_allowance = limits.cells_per_pair.saturating_sub(boundary_cells);
            let mut source_chart_cells=0;
            let mut volume_separation=None;
            // Quintic polygon corner charts need a source-volume proof: their
            // piecewise profile weights need not have one global chart map.
            // Try the exact four-wall cell before spending the pair budget on
            // a stitched surface. Other chart families keep their ordering.
            let volume_first=sa.degree_u==1 && sa.degree_v==5 && sb.degree_u==1 && sb.degree_v==5;
            if volume_first && boundary.is_none()&&!periodic&&joint_exact_domain&&source_chart_cells<pair_allowance&&out.cells<limits.cells {
                let separated=source_volume_context.as_ref().unwrap().certify([a,b],
                    (limits.cells-out.cells).min(pair_allowance-source_chart_cells))?;
                source_chart_cells+=separated.cells;out.cells+=separated.cells;
                if let Some(c)=separated.certificate {
                    if c.shared_edge.is_some() {boundary=Some(SharedBoundary::SourceVolumeBoundary(c));}
                    else {volume_separation=Some(c);}
                }
            }
            // Exact control-hull separation is the fast path only for sweep
            // certification, including closed no-cap bodies: the plain face-contact
            // API keeps the frozen trim-search work accounting byte-for-byte.
            let (hull_disjoint, hull_cells) = if boundary.is_none() && volume_separation.is_none() && !periodic && (sweep_hulls || joint_exact_domain) {
                let allowance = (limits.cells - out.cells)
                    .min(limits.cells_per_pair.saturating_sub(boundary_cells + source_chart_cells) / 2)
                    .min(64);
                let cached = if allowance > 0 {
                    cover.as_ref().and_then(|c| c.pair_separated(a, b))
                } else {
                    None
                };
                match cached {
                    Some(true) => (true, 1),
                    Some(false) => {
                        let (separated, work) =
                            crate::control_hull_separation::inspect(sa, sb, allowance - 1);
                        (separated, work + 1)
                    }
                    None => crate::control_hull_separation::inspect(sa, sb, allowance),
                }
            } else {
                (false, 0)
            };
            out.cells += hull_cells;
            let pair_allowance = pair_allowance.saturating_sub(hull_cells);
            if boundary.is_none() && !hull_disjoint && volume_separation.is_none() && joint_exact_domain
                && source_chart_cells < pair_allowance && out.cells < limits.cells
                && projected_trim_network::multiple_shared_edges(model,[a,b]) {
                let attempt=crate::shared_boundary::opposite_rows::certify(model,[a,b],
                    (limits.cells-out.cells).min(pair_allowance-source_chart_cells));
                source_chart_cells+=attempt.cells;out.cells+=attempt.cells;
                boundary=attempt.certificate.map(SharedBoundary::ExactHull);
            }
            if boundary.is_none() && !hull_disjoint && volume_separation.is_none() && joint_exact_domain
                && source_chart_cells<pair_allowance && out.cells<limits.cells {
                let attempt=crate::shared_boundary::opposite_rows::certify_restricted(model,[a,b],
                    (limits.cells-out.cells).min(pair_allowance-source_chart_cells).min(256));
                source_chart_cells+=attempt.cells;out.cells+=attempt.cells;
                boundary=attempt.certificate.map(SharedBoundary::ExactHull);
            }
            if boundary.is_none() && !hull_disjoint && volume_separation.is_none() && joint_exact_domain
                && source_chart_cells < pair_allowance && out.cells < limits.cells
                && projected_trim_network::multiple_shared_edges(model,[a,b]) {
                let attempt = projected_trim_network::certify(model,[a,b],
                    (limits.cells-out.cells).min(pair_allowance-source_chart_cells).min(100_000))?;
                source_chart_cells += attempt.cells; out.cells += attempt.cells;
                boundary = attempt.certificate.map(SharedBoundary::ProjectedTrimNetwork);
            }
            if boundary.is_none() && !hull_disjoint && volume_separation.is_none() && joint_exact_domain && source_chart_cells < pair_allowance && out.cells < limits.cells {
                let attempt = same_support_contact::certify(model, [a,b],
                    (limits.cells-out.cells).min(pair_allowance-source_chart_cells).min(100_000))?;
                source_chart_cells += attempt.cells; out.cells += attempt.cells;
                boundary = attempt.certificate.map(SharedBoundary::SameSupportPartition);
            }
            if boundary.is_none() && !hull_disjoint && volume_separation.is_none() && joint_exact_domain && source_chart_cells < pair_allowance && out.cells < limits.cells {
                let attempt = projected_trim_contact::certify(model,[a,b],
                    (limits.cells-out.cells).min(pair_allowance-source_chart_cells).min(100_000))?;
                source_chart_cells += attempt.cells; out.cells += attempt.cells;
                boundary = attempt.certificate.map(SharedBoundary::ProjectedTrimPartition);
            }
            if boundary.is_none()&&!hull_disjoint&&volume_separation.is_none()&&!periodic&&joint_exact_domain&&source_chart_cells<pair_allowance&&out.cells<limits.cells {
                let joined=boundary_stitched_contact::certify(model,[a,b],
                    (limits.cells-out.cells).min(pair_allowance-source_chart_cells))?;
                source_chart_cells+=joined.cells;out.cells+=joined.cells;
                boundary=joined.certificate.map(SharedBoundary::JoinedSourceCharts);
            }
            if !volume_first&&!hull_disjoint&&boundary.is_none()&&!periodic&&joint_exact_domain&&source_chart_cells<pair_allowance&&out.cells<limits.cells {
                let separated=source_volume_context.as_ref().unwrap().certify([a,b],
                    (limits.cells-out.cells).min(pair_allowance-source_chart_cells))?;
                source_chart_cells+=separated.cells;out.cells+=separated.cells;
                if let Some(c)=separated.certificate {
                    if c.shared_edge.is_some() {boundary=Some(SharedBoundary::SourceVolumeBoundary(c));}
                    else {volume_separation=Some(c);}
                }
            }

            if boundary.is_none() && !hull_disjoint && volume_separation.is_none() && joint_exact_domain {
                let allowance = (limits.cells - out.cells).min(limits.cells_per_pair.saturating_sub(boundary_cells + source_chart_cells + hull_cells));
                let (certificate, used) = crate::shared_boundary::closed_graph::certify(model, [a,b], allowance);
                boundary_cells += used;
                out.cells += used;
                boundary = certificate.map(SharedBoundary::ClosedGraph);
            }
            let result = if boundary.is_some()
                || hull_disjoint
                || volume_separation.is_some()
                || periodic
                || out.cells == limits.cells
                || boundary_cells + source_chart_cells + hull_cells == limits.cells_per_pair
            {
                None
            } else {
                let search = if sweep_hulls {
                    surface_contact_search::search_trimmed_with_control_hulls
                } else {
                    surface_contact_search::search_trimmed
                };
                Some(search(
                    sa,
                    sb,
                    [&domains[a].region, &domains[b].region],
                    (limits.cells - out.cells)
                        .min(limits.cells_per_pair - boundary_cells - source_chart_cells - hull_cells),
                    (limits.domain_cells - out.domain_cells).min(limits.domain_cells_per_pair),
                )?)
            };
            let reason = match &result {
                None if hull_disjoint || volume_separation.is_some() => "pair-disjoint",
                None if boundary.is_some() => "shared-boundary",
                None if sa.periodic_u || sa.periodic_v || sb.periodic_u || sb.periodic_v => {
                    "periodic-trim-not-supported"
                }
                None => "pair-unresolved",
                Some(r) if r.absence_proven => "pair-disjoint",
                Some(r) if r.contact.is_some() => "interior-contact",
                Some(_) => "pair-unresolved",
            };
            out.all_pairs_classified &= boundary.is_some()
                || hull_disjoint
                || volume_separation.is_some()
                || result.as_ref().is_some_and(|r| r.absence_proven);
            out.all_pairs_disjoint &=
                hull_disjoint || volume_separation.is_some() || result.as_ref().is_some_and(|r| r.absence_proven);
            if let Some(r) = &result {
                out.cells += r.cells;
                out.domain_cells += r.domain_cells;
            }
            out.pairs.push(Pair {
                faces: [a, b],
                result,
                boundary,
                hull_disjoint,
                hull_cells,
                boundary_cells,
                source_chart_cells,
                volume_separation,
                reason,
            });
        }
        if *cursor == n {
            debug_assert_eq!(out.pairs.len() + out.grouped_pairs, out.total_pairs);
            *done = true;
        }
        Ok(used)
    }
    pub(crate) fn finish(self) -> Result<Report> {
        if self.failed { return Err(Error::new("BREP_CONTACT_FAILED", "Discard a failed traversal")); }
        if !self.done { return Err(Error::new("BREP_CONTACT_PENDING", "Complete pair traversal before requesting its report")); }
        Ok(self.report)
    }
}


#[cfg(test)]
#[path = "face_contacts/tests/tests_integration.rs"]
mod tests;

#[path = "face_contacts/frozen_contacts.rs"]
mod frozen_contacts;
#[cfg(test)]
use frozen_contacts::frozen_inspect_impl;
