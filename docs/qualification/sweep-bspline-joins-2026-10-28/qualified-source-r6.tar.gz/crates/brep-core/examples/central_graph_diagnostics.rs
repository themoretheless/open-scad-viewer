use brep_core::region_replacement as r;
fn main() {
    let m = brep_core::cuboid([0.; 3], [10.; 3]).unwrap();
    let requests: Vec<_> = m
        .edges
        .iter()
        .enumerate()
        .filter(|(_, e)| e.vertices.contains(&0))
        .enumerate()
        .map(|(i, (edge, _))| r::EdgeRadius {
            edge,
            radius_mm: [0.1, 0.2, 0.35][i],
        })
        .collect();
    let limits = r::StripLimits {
        tolerances: [1e-7, 1e-5, 1e-4],
        tolerance_uv: 1e-8,
        max_geometry_work: 10000,
        max_cells: 300000,
        max_exact: 1000000,
        max_coefficients: 2000000,
    };
    let strips = r::build_trihedral_strips(&m, 0, 0, &requests, 0.1, 2., limits).unwrap();
    let collars = r::prepare_trihedral_collars(
        &m,
        &strips,
        [1e-7, 1e-5, 1e-4],
        1e-8,
        0.001,
        100000,
        20000000,
        1000000,
    )
    .unwrap();
    let a = 1. / 2_f64.sqrt();
    let b = 1. / 6_f64.sqrt();
    let c = 1. / 3_f64.sqrt();
    let requested: Vec<usize> = std::env::args()
        .skip(1)
        .map(|s| s.parse().expect("knot interval count"))
        .collect();
    let requested = if requested.is_empty() {
        vec![2, 4, 6]
    } else {
        requested
    };
    let degree: usize = std::env::var("OSV_CENTRAL_GRAPH_DEGREE")
        .ok()
        .map(|s| s.parse().expect("graph degree"))
        .unwrap_or(5);
    for spans in requested {
        let options = r::GraphOptions {
            frame: [[a, -a, 0.], [b, b, -2. * b], [c, c, c]],
            degree,
            spans,
            align_junctions: true,
            stations_per_side: 129,
            regularization: 1e-12,
        };
        let degree = options.degree;
        match r::propose_central_graph(&collars, options) {
            Ok(candidate) => {
                println!(
                    "degree={degree} spans={spans} sampled_jet_residual={:?}",
                    candidate.sampled_jet_residual
                );
                if let Some(path) = std::env::var_os("OSV_CENTRAL_GRAPH_EVIDENCE") {
                    let directory = std::path::PathBuf::from(path);
                    std::fs::create_dir_all(&directory).unwrap();
                    let boundaries=collars.boundaries.iter().zip(&candidate.pcurves).map(|(c,p)|value_codec::json!({
                        "curve":c.curve,"originalSurface":c.original_surface,"originalPcurve":c.original_pcurve,"candidatePcurve":p
                    })).collect::<Vec<_>>();
                    let data = value_codec::json!({"surface":candidate.surface,"boundaries":boundaries,
                        "sampledJetResidual":candidate.sampled_jet_residual,"degree":degree,"spans":spans,"closedBody":false,"admitted":false});
                    std::fs::write(
                        directory.join(format!("candidate-{degree}-{spans}.json")),
                        value_codec::to_string(&data).unwrap(),
                    )
                    .unwrap();
                }
                if std::env::var_os("OSV_CENTRAL_GRAPH_INSPECT").is_some() {
                    let report = r::inspect_central_graph(
                        &collars,
                        &candidate,
                        [[1, -1, 0], [1, 1, -2]],
                        [1e-7, 1e-5, 1e-4],
                        600000,
                        1000000,
                    )
                    .unwrap();
                    println!(
                        "degree={degree} spans={spans} admitted={} interior={} cells={} seams={:?}",
                        report.admitted,
                        report.interior.certified,
                        report.cells,
                        report
                            .seams
                            .iter()
                            .map(|s| (s.positions.proven, s.positions.upper, s.geometric.decision))
                            .collect::<Vec<_>>()
                    );
                }
            }
            Err(e) => println!("degree={degree} spans={spans} refused={e:?}"),
        }
    }
}
