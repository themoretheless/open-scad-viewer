//! Exact implicit continuation through overlapping, independently bounded charts.
//! No algebraic inverse endpoint is approximated or made into a source leaf.
use super::*;
type T = Vec<P>;
fn divide(a: &Q, b: &Q, ctx: &mut PredicateContext<'_>) -> Result<Q, Reason> {
    if b.n.sign() == Sign::Negative {
        Q::zero()
            .sub(a, ctx)?
            .div_positive(&Q::zero().sub(b, ctx)?, ctx)
    } else {
        a.div_positive(b, ctx)
    }
}
fn division(mut a: P, b: &P, ctx: &mut PredicateContext<'_>) -> Result<(P, P), Reason> {
    if zero(b) {
        return Err(Reason::MissingProof);
    }
    let mut q = vec![Q::zero(); a.len().saturating_sub(b.len()) + 1];
    while !zero(&a) && a.len() >= b.len() {
        ctx.charge(1)?;
        let at = a.len() - b.len();
        let c = divide(a.last().unwrap(), b.last().unwrap(), ctx)?;
        q[at] = c.clone();
        for (i, v) in b.iter().enumerate() {
            a[i + at] = a[i + at].sub(&v.mul(&c, ctx)?, ctx)?;
        }
        a = trim(a);
    }
    Ok((trim(q), a))
}
fn monic(a: P, ctx: &mut PredicateContext<'_>) -> Result<P, Reason> {
    if zero(&a) {
        return Ok(a);
    }
    let lead = a.last().unwrap();
    a.iter().map(|x| divide(x, lead, ctx)).collect()
}
fn gcd(mut a: P, mut b: P, ctx: &mut PredicateContext<'_>) -> Result<P, Reason> {
    while !zero(&b) {
        let r = division(a, &b, ctx)?.1;
        a = b;
        b = r;
    }
    monic(a, ctx)
}
fn trim_t(mut a: T) -> T {
    while a.last().is_some_and(|x| zero(x)) {
        a.pop();
    }
    a
}
fn primitive(a: T, ctx: &mut PredicateContext<'_>) -> Result<T, Reason> {
    let a = trim_t(a);
    if a.is_empty() {
        return Ok(a);
    }
    let mut content = vec![Q::zero()];
    for c in &a {
        content = gcd(content, c.clone(), ctx)?;
        if content.len() == 1 {
            break;
        }
    }
    let mut out = Vec::new();
    for c in a {
        let (q, r) = division(c, &content, ctx)?;
        if !zero(&r) {
            return Err(Reason::MissingProof);
        }
        out.push(q);
    }
    // A constant normalization controls coefficient growth without a rounded pivot.
    let lead = out.last().unwrap().last().unwrap().clone();
    for c in &mut out {
        for q in c {
            *q = divide(q, &lead, ctx)?;
        }
    }
    Ok(out)
}
fn to_t(a: &B) -> T {
    let mut out = Vec::new();
    for (&(i, j), q) in a {
        if out.len() <= j {
            out.resize_with(j + 1, || vec![Q::zero()]);
        }
        if out[j].len() <= i {
            out[j].resize(i + 1, Q::zero());
        }
        out[j][i] = q.clone();
    }
    out.into_iter().map(trim).collect()
}
fn from_t(a: T) -> B {
    let mut out = B::new();
    for (j, p) in a.into_iter().enumerate() {
        for (i, q) in p.into_iter().enumerate() {
            if q.n.sign() != Sign::Zero {
                out.insert((i, j), q);
            }
        }
    }
    out
}
fn common(a: &B, b: &B, ctx: &mut PredicateContext<'_>) -> Result<B, Reason> {
    let mut a = primitive(to_t(a), ctx)?;
    let mut b = primitive(to_t(b), ctx)?;
    while !b.is_empty() {
        let mut r = a;
        while !r.is_empty() && r.len() >= b.len() {
            ctx.charge(1)?;
            let at = r.len() - b.len();
            let lc = r.last().unwrap().clone();
            let bc = b.last().unwrap();
            for row in &mut r {
                *row = mul(row, bc, ctx)?;
            }
            for (i, row) in b.iter().enumerate() {
                r[i + at] = sub(&r[i + at], &mul(row, &lc, ctx)?, ctx)?;
            }
            r = trim_t(r);
        }
        a = b;
        b = primitive(r, ctx)?;
    }
    Ok(from_t(primitive(a, ctx)?))
}
struct Pair {
    cofactors: [B; 3],
}
fn pair(
    a: &[H],
    b: &[H],
    scale: &Q,
    order: usize,
    ctx: &mut PredicateContext<'_>,
) -> Result<Option<Pair>, Reason> {
    let mut residuals = Vec::new();
    let mut f = B::new();
    for k in 0..3 {
        let p = difference(&a[0][k], &b[0][3], &a[0][3], &b[0][k], ctx)?;
        if !p.is_empty() {
            f = if f.is_empty() {
                p.clone()
            } else {
                common(&f, &p, ctx)?
            };
        }
        residuals.push(p);
    }
    // A source-only polynomial or a nonzero constant cannot own a graph cover.
    if !f.keys().any(|&(i, _)| i > 0) || !f.keys().any(|&(_, j)| j > 0) {
        return Ok(None);
    }
    if !jets_mod(a, b, &f, scale, order, ctx)? {
        return Ok(None);
    }
    let mut cofactors = std::array::from_fn(|_| B::new());
    for (k, p) in residuals.into_iter().enumerate() {
        let Some(q) = quotient(p, &f, ctx)? else {
            return Ok(None);
        };
        cofactors[k] = q;
    }
    Ok(Some(Pair { cofactors }))
}
fn point(h: &[H], t: &Q, ctx: &mut PredicateContext<'_>) -> Result<[Q; 3], Reason> {
    let d = value(&h[0][3], t, ctx)?;
    let mut p = std::array::from_fn(|_| Q::zero());
    for k in 0..3 {
        p[k] = value(&h[0][k], t, ctx)?.div_positive(&d, ctx)?;
    }
    Ok(p)
}
fn same(a: &[Q; 3], b: &[Q; 3], ctx: &mut PredicateContext<'_>) -> Result<bool, Reason> {
    for k in 0..3 {
        if !a[k].equal(&b[k], ctx)? {
            return Ok(false);
        }
    }
    Ok(true)
}
fn bernstein(p: &P, ctx: &mut PredicateContext<'_>) -> Result<P, Reason> {
    let n = p.len() - 1;
    let mut out = Vec::new();
    for i in 0..=n {
        let mut b = Q::zero();
        let mut ratio = one();
        for k in 0..=i {
            if k > 0 {
                ratio = ratio
                    .mul(&integer(i + 1 - k), ctx)?
                    .div_positive(&integer(n + 1 - k), ctx)?;
            }
            b = b.add(&p[k].mul(&ratio, ctx)?, ctx)?;
        }
        out.push(b);
    }
    Ok(out)
}
// Strict tensor Bernstein sign on the complete source/target rectangle.
fn nonzero_on(
    p: &B,
    a: [&Q; 2],
    b: [&Q; 2],
    ctx: &mut PredicateContext<'_>,
) -> Result<bool, Reason> {
    if p.is_empty() {
        return Ok(false);
    }
    let mut rows = to_t(p);
    let degree = rows.iter().map(Vec::len).max().unwrap() - 1;
    let linear = vec![a[0].clone(), a[1].sub(a[0], ctx)?];
    for row in &mut rows {
        *row = compose(row, &linear, &vec![one()], row.len() - 1, ctx)?;
        row.resize(degree + 1, Q::zero());
        *row = bernstein(row, ctx)?;
    }
    let linear = vec![b[0].clone(), b[1].sub(b[0], ctx)?];
    let mut sign = None;
    for i in 0..=degree {
        let p = rows.iter().map(|row| row[i].clone()).collect::<P>();
        let p = compose(&p, &linear, &vec![one()], p.len() - 1, ctx)?;
        for c in bernstein(&p, ctx)? {
            let s = c.n.sign();
            if s == Sign::Zero || sign.is_some_and(|x| x != s) {
                return Ok(false);
            }
            sign = Some(s);
        }
    }
    Ok(true)
}
struct Cell {
    span: usize,
    lo: Q,
    hi: Q,
    first: [Q; 3],
    last: [Q; 3],
}
fn cells(
    spans: &[(usize, Vec<H>)],
    u: &[Q],
    level: usize,
    ctx: &mut PredicateContext<'_>,
) -> Result<Vec<Cell>, Reason> {
    let mut out: Vec<Cell> = Vec::new();
    let parts = 1usize << level;
    for (span, (i, h)) in spans.iter().enumerate() {
        let width = u[i + 1]
            .sub(&u[*i], ctx)?
            .div_positive(&integer(parts), ctx)?;
        for j in 0..parts {
            let lo = u[*i].add(&width.mul(&integer(j), ctx)?, ctx)?;
            let hi = u[*i].add(&width.mul(&integer(j + 1), ctx)?, ctx)?;
            let first = point(h, &lo, ctx)?;
            let last = point(h, &hi, ctx)?;
            if let Some(prev) = out.last() {
                if !same(&prev.last, &first, ctx)? {
                    return Err(Reason::MissingProof);
                }
            }
            out.push(Cell {
                span,
                lo,
                hi,
                first,
                last,
            });
        }
    }
    Ok(out)
}
fn slope(
    h: &[H],
    axis: usize,
    cell: &Cell,
    sign: Sign,
    ctx: &mut PredicateContext<'_>,
) -> Result<bool, Reason> {
    let n = &h[0][axis];
    let d = &h[0][3];
    let mut p = sub(
        &mul(&derivative(n, ctx)?, d, ctx)?,
        &mul(n, &derivative(d, ctx)?, ctx)?,
        ctx,
    )?;
    if sign == Sign::Negative {
        p = neg(&p, ctx)?;
    }
    positive(&p, &cell.lo, &cell.hi, ctx)
}
/// Continue the unique positively oriented correspondence through overlapping
/// local charts. At every node at least one parameter is an exact rational
/// original/subdivision endpoint; the other may be an unrepresented algebraic
/// root. Its Cartesian point is known by exact divisibility and uniqueness.
pub(crate) fn compare(
    ctx: &mut PredicateContext<'_>,
    spans: &[Vec<(usize, Vec<H>)>],
    u: &[Vec<Q>],
    scale: &Q,
    order: usize,
) -> Result<BezierIdentity, Reason> {
    let mut cache: BTreeMap<(usize, usize), Option<Pair>> = BTreeMap::new();
    let mut spent_cells = 0usize;
    // Existing 4096-cell/depth-12 ceilings; every failed refinement also spends
    // this caller's one exact-work ledger. No fresh budget on a chart switch.
    for level in 0..=12 {
        let count = (spans[0].len() + spans[1].len()) * (1usize << level);
        if spent_cells + count > 4096 {
            return Err(Reason::MissingProof);
        }
        spent_cells += count;
        ctx.charge(count as u64)?;
        let a = cells(&spans[0], &u[0], level, ctx)?;
        let b = cells(&spans[1], &u[1], level, ctx)?;
        if a.is_empty()
            || b.is_empty()
            || !same(&a[0].first, &b[0].first, ctx)?
            || !same(&a.last().unwrap().last, &b.last().unwrap().last, ctx)?
        {
            return Err(Reason::MissingProof);
        }
        let mut current = a[0].first.clone();
        let (mut i, mut j) = (0, 0);
        while i < a.len() && j < b.len() {
            let (x, y) = (&a[i], &b[j]);
            let key = (x.span, y.span);
            if !cache.contains_key(&key) {
                cache.insert(
                    key,
                    pair(&spans[0][x.span].1, &spans[1][y.span].1, scale, order, ctx)?,
                );
            }
            let Some(proof) = cache[&key].as_ref() else {
                return Err(Reason::MissingProof);
            };
            let mut advance = None;
            for axis in 0..3 {
                let sign = x.last[axis].sub(&x.first[axis], ctx)?.n.sign();
                if sign == Sign::Zero || y.last[axis].sub(&y.first[axis], ctx)?.n.sign() != sign {
                    continue;
                }
                let factor = if sign == Sign::Positive {
                    one()
                } else {
                    Q::zero().sub(&one(), ctx)?
                };
                let mut inside = true;
                for cell in [x, y] {
                    if current[axis]
                        .sub(&cell.first[axis], ctx)?
                        .mul(&factor, ctx)?
                        .n
                        .sign()
                        == Sign::Negative
                        || cell.last[axis]
                            .sub(&current[axis], ctx)?
                            .mul(&factor, ctx)?
                            .n
                            .sign()
                            != Sign::Positive
                    {
                        inside = false;
                        break;
                    }
                }
                if !inside
                    || !slope(&spans[0][x.span].1, axis, x, sign, ctx)?
                    || !slope(&spans[1][y.span].1, axis, y, sign, ctx)?
                {
                    continue;
                }
                if !nonzero_on(&proof.cofactors[axis], [&x.lo, &x.hi], [&y.lo, &y.hi], ctx)? {
                    continue;
                }
                let end = x.last[axis]
                    .sub(&y.last[axis], ctx)?
                    .mul(&factor, ctx)?
                    .n
                    .sign();
                if end == Sign::Zero && !same(&x.last, &y.last, ctx)? {
                    return Err(Reason::MissingProof);
                }
                advance = Some(end);
                break;
            }
            let Some(end) = advance else {
                break;
            };
            if end != Sign::Positive {
                current = x.last.clone();
                i += 1;
            }
            if end != Sign::Negative {
                current = y.last.clone();
                j += 1;
            }
        }
        if i == a.len() && j == b.len() {
            ctx.charge(0)?;
            return Ok(BezierIdentity::Equal);
        }
        // Reaching just one final endpoint leaves an uncovered original tail.
        if i == a.len() || j == b.len() {
            return Err(Reason::MissingProof);
        }
    }
    Err(Reason::MissingProof)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{AuthoredScalar, Limits, SourceArena, ToleranceContext};
    fn setup(ctx: &mut PredicateContext<'_>) -> (Vec<Vec<(usize, Vec<H>)>>, Vec<Vec<Q>>, Q) {
        let half = one().div_positive(&integer(2), ctx).unwrap();
        let mut spans = Vec::new();
        let mut knots = Vec::new();
        for side in 0..2 {
            // An open parameter interval whose endpoints meet in space. Neither
            // x=q-q³ nor y=q² is monotone on this complete regular curve.
            let mut clock = if side == 0 {
                vec![Q::zero(), half.clone(), half.clone()]
            } else {
                vec![Q::zero(), half.clone(), Q::zero(), half.clone()]
            };
            clock = scaled(&clock, &integer(2), ctx).unwrap();
            clock[0] = Q::zero().sub(&one(), ctx).unwrap();
            let q2 = mul(&clock, &clock, ctx).unwrap();
            let q3 = mul(&q2, &clock, ctx).unwrap();
            let h = vec![
                [
                    sub(&clock, &q3, ctx).unwrap(),
                    q2,
                    vec![Q::zero()],
                    vec![one()],
                ],
                [
                    vec![Q::zero()],
                    vec![Q::zero()],
                    vec![one()],
                    vec![Q::zero()],
                ],
                std::array::from_fn(|_| vec![Q::zero()]),
            ];
            // Deliberately staggered original cuts; none of the interior
            // Cartesian endpoints agrees with an endpoint on the other side.
            let us = if side == 0 {
                vec![Q::zero(), half.clone(), one()]
            } else {
                vec![
                    Q::zero(),
                    one().div_positive(&integer(4), ctx).unwrap(),
                    one(),
                ]
            };
            spans.push((0..us.len() - 1).map(|i| (i, h.clone())).collect());
            knots.push(us);
        }
        (spans, knots, Q::zero().sub(&one(), ctx).unwrap())
    }
    #[test]
    fn implicit_overlap_changes_axes_without_shared_chart_endpoints() {
        let arena =
            SourceArena::authored("overlap", 1, vec![AuthoredScalar::Binary64Bits(0)]).unwrap();
        let tol = ToleranceContext::default_valid();
        let mut ctx = PredicateContext::new(&arena, &tol, Limits::default(), None);
        let (spans, u, scale) = setup(&mut ctx);
        let mut proof = PredicateContext::new(&arena, &tol, Limits::default(), None);
        assert!(
            matches!(
                compare(&mut proof, &spans, &u, &scale, 2),
                Ok(BezierIdentity::Equal)
            ),
            "work={}",
            proof.work_used()
        );
        let work = proof.work_used();
        let mut short = PredicateContext::new(
            &arena,
            &tol,
            Limits {
                max_work: work - 1,
                ..Limits::default()
            },
            None,
        );
        assert!(compare(&mut short, &spans, &u, &scale, 2).is_err());
        let mut broken = spans.clone();
        broken[1][1].1[1][2] = vec![integer(2)];
        let mut fresh = PredicateContext::new(&arena, &tol, Limits::default(), None);
        assert!(compare(&mut fresh, &broken, &u, &scale, 1).is_err());
    }
}
