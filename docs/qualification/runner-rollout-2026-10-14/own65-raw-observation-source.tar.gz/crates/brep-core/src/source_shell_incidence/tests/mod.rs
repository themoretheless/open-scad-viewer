use super::*;
use crate::source_boundary_fragment::{Endpoint, Fragment};
use nurbs_core::surface::Surface;
#[test]
fn full_turn_caps_contract_poles_and_have_one_vertex_link_cycle() {
    for (radii, sweep) in [[0.5, 1.25], [1.25, 0.5], [0., 1.], [1., 0.]]
        .into_iter()
        .flat_map(|r| [std::f64::consts::TAU, -std::f64::consts::TAU].map(|s| (r, s)))
    {
        let spans = crate::linear_canal::construct(
            [[10., -7., 5.], [13., -3., 17.]],
            radii,
            [1., 0., 0.],
            sweep,
        )
        .unwrap();
        let model = crate::linear_canal::to_capped_region(&spans, 1e-7).unwrap();
        let mut faces = Vec::new();
        let mut regions = Vec::new();
        let mut poles = Vec::new();
        let mut pending = BTreeMap::new();
        let mut pairs = Vec::new();
        for (face, f) in model.faces.iter().enumerate() {
            let mut fragments = Vec::new();
            for (edge, use_) in model.loops[f.outer].coedges.iter().enumerate() {
                let a = Address {
                    face,
                    wire: 0,
                    edge,
                };
                fragments.push(
                    Fragment::new(
                        &f.surface,
                        &use_.pcurve,
                        Endpoint::Parameter(0.),
                        Endpoint::Parameter(1.),
                    )
                    .unwrap(),
                );
                let world = &model.edges[use_.edge];
                if world.degenerate {
                    poles.push(Pole {
                        use_: a,
                        point: model.vertices[world.vertices[0]].point,
                    });
                } else if let Some((other, reversed)) = pending.remove(&use_.edge) {
                    pairs.push(Pair {
                        uses: [other, a],
                        world: world.curve.clone(),
                        world_reversed: [reversed, use_.reversed],
                        cutters: [None, None],
                    });
                } else {
                    pending.insert(use_.edge, (a, use_.reversed));
                }
            }
            let boundaries = model.loops[f.outer]
                .coedges
                .iter()
                .map(|use_| crate::trimmed_face_recipe::Boundary {
                    curve: model.edges[use_.edge].curve.clone(),
                    pcurve: use_.pcurve.clone(),
                    reversed: use_.reversed,
                })
                .collect::<Vec<_>>();
            let qualified = crate::source_contour_proposal::qualify_original_region(
                &cad_predicates::ToleranceContext::default_valid(),
                &f.surface,
                &[boundaries],
                1e-8,
                crate::trimmed_face_recipe::Limits {
                    pairs: 10000,
                    region_cells: 10000,
                    domain_cells: 10000,
                    agreement_cells: 10000,
                },
            )
            .unwrap();
            regions.push(qualified.region.expect(qualified.reason));
            faces.push(vec![Wire::new(&fragments).unwrap()]);
        }
        assert!(pending.is_empty());
        let report =
            assemble_regions_with_poles(&regions, &pairs, &poles, 100_000_000).unwrap();
        let shell = report.shell.expect(report.reason);
        crate::source_shell_restore::assert_replay(&shell);
        assert_eq!(shell.poles().len(), poles.len());
        assert!(shell.regions().is_some());
        let authored = crate::linear_canal::to_capped_source_shell(
            &spans,
            1e-7,
            1e-8,
            crate::trimmed_face_recipe::Limits {
                pairs: 10000,
                region_cells: 10000,
                domain_cells: 10000,
                agreement_cells: 10000,
            },
            100_000_000,
        )
        .unwrap()
        .shell
        .unwrap();
        assert_eq!(authored.vertices(), shell.vertices());
        assert_eq!(authored.uses(), shell.uses());

        let charts = shell.inspect_face_charts(100000, 100000).unwrap();
        for (address, _) in shell.poles() {
            let face = &charts.faces[address.face];
            assert!(face.quotient.is_some(), "missing pole diagnostic");
            if shell.faces()[address.face][0].edges()[0].surface().degree_u == 1 {
                assert!(
                    face.ruled_quotient.as_ref().is_some_and(|q| q.proven),
                    "{:?}",
                    face.ruled_quotient
                );
            } else {
                assert!(
                    face.polar_quotient.as_ref().is_some_and(|q| q.proven),
                    "sphere cap: {:?}",
                    face.polar_quotient
                );
            }
        }
        assert!(
            charts.all_injective,
            "unproven faces: {:?}",
            charts
                .faces
                .iter()
                .filter(|f| !f.injectivity_proven())
                .map(|f| (
                    f.face,
                    f.contraction.as_ref().map(|r| r.reason),
                    f.linear.as_ref().map(|r| r.certified)
                ))
                .collect::<Vec<_>>()
        );
        let limited = shell.inspect_face_charts(1, 0).unwrap();
        assert!(!limited.all_injective && limited.spans <= 1);

        let links = crate::source_vertex_links::inspect(&shell, 100000).unwrap();
        assert_eq!(links.euler_characteristic, Some(2));
        assert_eq!(links.genus, Some(0));
        assert!(
            links.all_manifold,
            "{} {:?}",
            links.reason, links.uncertain_vertex
        );
        assert_eq!(
            links.links.len() as i64 - shell.edges().len() as i64 + faces.len() as i64,
            2
        );
        assert!(
            assemble_with_poles(&faces, &pairs, &poles, 1)
                .unwrap()
                .shell
                .is_none()
        );
        assert!(assemble_with_poles(&faces, &pairs, &poles[1..], 100_000_000).is_err());
        let mut duplicate = poles
            .iter()
            .map(|p| Pole {
                use_: p.use_,
                point: p.point,
            })
            .collect::<Vec<_>>();
        duplicate[1].use_ = duplicate[0].use_;
        assert!(assemble_with_poles(&faces, &pairs, &duplicate, 100_000_000).is_err());
        let mut bad = poles;
        bad[0].point[0] += 1e-12;
        assert!(
            assemble_with_poles(&faces, &pairs, &bad, 100_000_000)
                .unwrap()
                .shell
                .is_none()
        );
    }
}
#[test]
fn qualified_source_pole_enables_the_existing_weighted_quotient_proof() {
    let surface = Surface {
        degree_u: 2,
        degree_v: 1,
        knots_u: vec![0., 0., 0., 1., 1., 1.],
        knots_v: vec![0., 0., 1., 1.],
        control_points: vec![
            vec![vec![0., 0., 0.], vec![0., 0., 0.]],
            vec![vec![0.5, 0., 0.], vec![0.5, 0., 0.]],
            vec![vec![1., 0., 0.], vec![1., 1., 0.]],
        ],
        weights: vec![vec![1.; 2]; 3],
        periodic_u: false,
        periodic_v: false,
    };
    let corners = [[0., 0.], [1., 0.], [1., 1.], [0., 1.]];
    let curves = [
        surface.iso(nurbs_core::surface::Axis::V, 0.).unwrap(),
        surface.iso(nurbs_core::surface::Axis::U, 1.).unwrap(),
        surface
            .iso(nurbs_core::surface::Axis::V, 1.)
            .unwrap()
            .reverse()
            .unwrap(),
        surface
            .iso(nurbs_core::surface::Axis::U, 0.)
            .unwrap()
            .reverse()
            .unwrap(),
    ];
    let uv = (0..4)
        .map(|i| {
            Curve::from_polyline(vec![corners[i].to_vec(), corners[(i + 1) % 4].to_vec()])
                .unwrap()
        })
        .collect::<Vec<_>>();
    let fragment = |c: &Curve| {
        Fragment::new(
            &surface,
            c,
            Endpoint::Parameter(0.),
            Endpoint::Parameter(1.),
        )
        .unwrap()
    };
    let a = uv.iter().map(fragment).collect::<Vec<_>>();
    let b = uv
        .iter()
        .rev()
        .map(|c| fragment(&c.reverse().unwrap()))
        .collect::<Vec<_>>();
    let faces = vec![vec![Wire::new(&a).unwrap()], vec![Wire::new(&b).unwrap()]];
    let pairs = (0..3)
        .map(|edge| Pair {
            uses: [
                Address {
                    face: 0,
                    wire: 0,
                    edge,
                },
                Address {
                    face: 1,
                    wire: 0,
                    edge: 3 - edge,
                },
            ],
            world: curves[edge].clone(),
            world_reversed: [false, true],
            cutters: [None, None],
        })
        .collect::<Vec<_>>();
    let poles = [
        Pole {
            use_: Address {
                face: 0,
                wire: 0,
                edge: 3,
            },
            point: [0.; 3],
        },
        Pole {
            use_: Address {
                face: 1,
                wire: 0,
                edge: 0,
            },
            point: [0.; 3],
        },
    ];
    let shell = assemble_with_poles(&faces, &pairs, &poles, 1000000)
        .unwrap()
        .shell
        .unwrap();
    let charts = shell.inspect_face_charts(1000, 0).unwrap();
    assert!(charts.all_injective);
    assert!(
        charts
            .faces
            .iter()
            .all(|f| f.quotient.as_ref().is_some_and(|q| q.proven))
    );
    assert!(charts.spans <= 1000 && charts.spans >= 512);
    assert!(!shell.inspect_face_charts(255, 0).unwrap().all_injective);
    // These two charts overlap; per-face injectivity is not embedding.
    assert!(shell.regions().is_none());
}
fn tetrahedron() -> (Vec<Vec<Wire>>, Vec<Pair>) {
    let points = [[0., 0., 0.], [1., 0., 0.], [0., 1., 0.], [0., 0., 1.]];
    let triangles = [[0, 2, 1], [0, 1, 3], [1, 2, 3], [2, 0, 3]];
    let mut pending = BTreeMap::new();
    let mut pairs = Vec::new();
    let mut faces = Vec::new();
    for (face, t) in triangles.iter().enumerate() {
        let [a, b, c] = t.map(|i| points[i]);
        let fourth: Vec<_> = (0..3).map(|i| b[i] + c[i] - a[i]).collect();
        let s = Surface {
            degree_u: 1,
            degree_v: 1,
            knots_u: vec![0., 0., 1., 1.],
            knots_v: vec![0., 0., 1., 1.],
            control_points: vec![vec![a.to_vec(), c.to_vec()], vec![b.to_vec(), fourth]],
            weights: vec![vec![1.; 2]; 2],
            periodic_u: false,
            periodic_v: false,
        };
        let uv = [[0., 0.], [1., 0.], [0., 1.]];
        let mut fragments = Vec::new();
        for edge in 0..3 {
            let next = (edge + 1) % 3;
            let pc = Curve::from_polyline(vec![uv[edge].to_vec(), uv[next].to_vec()]).unwrap();
            fragments.push(
                Fragment::new(&s, &pc, Endpoint::Parameter(0.), Endpoint::Parameter(1.))
                    .unwrap(),
            );
            let address = Address {
                face,
                wire: 0,
                edge,
            };
            let key = (t[edge].min(t[next]), t[edge].max(t[next]));
            if let Some((old, world)) = pending.remove(&key) {
                pairs.push(Pair {
                    uses: [old, address],
                    world,
                    world_reversed: [false, true],
                    cutters: [None, None],
                });
            } else {
                pending.insert(
                    key,
                    (
                        address,
                        Curve::from_polyline(vec![
                            points[t[edge]].to_vec(),
                            points[t[next]].to_vec(),
                        ])
                        .unwrap(),
                    ),
                );
            }
        }
        faces.push(vec![Wire::new(&fragments).unwrap()]);
    }
    assert!(pending.is_empty());
    (faces, pairs)
}
#[test]
fn tetrahedron_pairs_produce_shared_vertex_owners_and_refuse_missing_or_duplicate_uses() {
    let (faces, mut pairs) = tetrahedron();
    let report = assemble(&faces, &pairs, 100_000_000).unwrap();
    assert!(
        report.shell.is_some(),
        "{} pair {:?}",
        report.reason,
        report.uncertain_pair
    );
    let shell = report.shell.unwrap();
    assert_eq!(shell.edges().len(), 6);
    let topology = crate::source_vertex_links::inspect(&shell, 12).unwrap();
    assert!(topology.all_manifold);
    assert_eq!(topology.links.len(), 4);
    assert!(topology.links.iter().all(|v| v.cycle.len() == 3));
    assert!(topology.euler_characteristic.is_none());
    assert!(
        !crate::source_vertex_links::inspect(&shell, 11)
            .unwrap()
            .all_manifold
    );
    assert!(crate::source_allowed_contact::certify(&shell, [0, 1], 100_000_000, 2).is_err());
    assert!(
        crate::source_fiber_contact::certify(&shell, [0, 1], 100_000_000, 2, 10000).is_err()
    );
    let owners: std::collections::BTreeSet<_> = shell
        .vertices()
        .iter()
        .flatten()
        .flatten()
        .flatten()
        .copied()
        .collect();
    assert_eq!(owners.len(), 4);
    for pair in shell.uses() {
        let vertex = |a: Address| shell.vertices()[a.face][a.wire][a.edge];
        assert_eq!(vertex(pair[0]), [vertex(pair[1])[1], vertex(pair[1])[0]]);
    }
    assert!(assemble(&faces, &pairs[..5], 100_000_000).is_err());
    pairs[1].uses[0] = pairs[0].uses[0];
    assert!(assemble(&faces, &pairs, 100_000_000).is_err());
    assert!(
        crate::source_shell_geometry::qualify(
            shell,
            crate::source_shell_geometry::Limits {
                tolerance_uv: 1e-8,
                corners: 12,
                spans: 100,
                linear_cells: 100,
                pairs: crate::face_contacts::Limits {
                    pairs: 6,
                    cells: 1000,
                    domain_cells: 1000,
                    cells_per_pair: 100,
                    domain_cells_per_pair: 100
                },
                exact_work: 100_000_000,
                driver_cells: 100,
            }
        )
        .is_err()
    );
}
#[test]
fn root_partition_of_shared_edge_preserves_closed_shell_and_original_definitions() {
    root_partition_control(false, false);
}
#[test]
fn irrational_root_partition_preserves_closed_body_and_exact_source_topology() {
    root_partition_control(true, false);
}
#[test]
fn curved_shell_preserves_roots_and_replays_inverse_contacts_volume() {
    root_partition_control(true, true);
}
fn root_partition_control(irrational: bool, curved: bool) {
    use crate::source_boundary_fragment::Role;
    let (mut faces, mut pairs) = tetrahedron();
    if curved {
        // Exact polynomial shear F(x,y,z)=(x,y,z+x*x/4), determinant one.
        // Elevate the affine charts to biquadratic Bezier coefficients.
        for face in &mut faces {
            let original=face[0].edges()[0].surface();
            let a=&original.control_points[0][0];
            let b:Vec<_>=(0..3).map(|k|original.control_points[1][0][k]-a[k]).collect();
            let c:Vec<_>=(0..3).map(|k|original.control_points[0][1][k]-a[k]).collect();
            let controls=(0..3).map(|i| (0..3).map(|j| {
                let mut q:Vec<_>=(0..3).map(|k|a[k]+b[k]*(i as f64/2.)+c[k]*(j as f64/2.)).collect();
                let square=a[0]*a[0]+a[0]*b[0]*i as f64+a[0]*c[0]*j as f64
                    +if i==2 {b[0]*b[0]} else {0.}
                    +if j==2 {c[0]*c[0]} else {0.}
                    +0.5*b[0]*c[0]*(i*j) as f64;
                q[2]+=square/4.;q
            }).collect()).collect();
            let surface=Surface {degree_u:2,degree_v:2,periodic_u:false,periodic_v:false,
                knots_u:vec![0.,0.,0.,1.,1.,1.],knots_v:vec![0.,0.,0.,1.,1.,1.],
                control_points:controls,weights:vec![vec![1.;3];3]};
            let mut leaves=surface.control_points.iter().flatten().flatten().map(|v|
                cad_predicates::AuthoredScalar::Binary64Bits(v.to_bits())).collect::<Vec<_>>();
            leaves.push(cad_predicates::AuthoredScalar::Binary64Bits(0.25f64.to_bits()));
            let arena=cad_predicates::SourceArena::authored("curved-body-shear",1,leaves).unwrap();
            let tolerance=cad_predicates::ToleranceContext::default_valid();
            let mut predicate=cad_predicates::PredicateContext::new(&arena,&tolerance,
                cad_predicates::Limits::default(),None);
            let refs=std::array::from_fn(|i|std::array::from_fn(|j|std::array::from_fn(|k|
                arena.leaf(9*i+3*j+k).unwrap())));
            let proof=cad_predicates::quadratic_shear_chart_identity(&mut predicate,refs,
                arena.leaf(27).unwrap(),0,2).unwrap();
            assert_eq!(proof.outcome,cad_predicates::ParameterIdentity::Equal);
            let inverse=crate::source_inverse_shear::qualify(&surface,[0,2],0.25,100000).unwrap();
            let certificate=inverse.certificate.expect(inverse.reason);
            assert_eq!(certificate.source(),&surface);
            assert_eq!(certificate.inverse().degree_u,1);
            assert_eq!(certificate.inverse().degree_v,1);
            for wire in face {
                let edges=wire.edges().iter().map(|e|Fragment::new(&surface,e.curve(),
                    Endpoint::Parameter(0.),Endpoint::Parameter(1.)).unwrap()).collect::<Vec<_>>();
                *wire=Wire::new(&edges).unwrap();
            }
        }
        for pair in &mut pairs {
            let a=&pair.world.control_points[0];let b=&pair.world.control_points[1];
            let mut first=a.clone();first[2]+=a[0]*a[0]/4.;
            let mut last=b.clone();last[2]+=b[0]*b[0]/4.;
            let mut middle:Vec<_>=(0..3).map(|k|(a[k]+b[k])/2.).collect();
            middle[2]+=a[0]*b[0]/4.;
            pair.world=Curve {degree:2,periodic:false,knots:vec![0.,0.,0.,1.,1.,1.],
                control_points:vec![first,middle,last],weights:vec![1.;3]};
        }
    }
    let context = cad_predicates::ToleranceContext::default_valid();
    let mut regions = faces
        .iter()
        .map(|face| {
            let surface = face[0].edges()[0].surface();
            let boundaries = face
                .iter()
                .map(|wire| {
                    wire.edges()
                        .iter()
                        .map(|e| {
                            let c = e.curve();
                            let a = &c.control_points[0];
                            let b = &c.control_points[1];
                            let first=surface.evaluate(a[0],a[1]).unwrap().point.to_vec();
                            let last=surface.evaluate(b[0],b[1]).unwrap().point.to_vec();
                            let curve=if curved {
                                let mut middle:Vec<_>=(0..3).map(|k|(first[k]+last[k])/2.).collect();
                                middle[2]-=(last[0]-first[0])*(last[0]-first[0])/8.;
                                Curve {degree:2,periodic:false,knots:vec![0.,0.,0.,1.,1.,1.],
                                    control_points:vec![first,middle,last],weights:vec![1.;3]}
                            } else {Curve::from_polyline(vec![first,last]).unwrap()};
                            crate::trimmed_face_recipe::Boundary {
                                curve,
                                pcurve: c.clone(),
                                reversed: false,
                            }
                        })
                        .collect()
                })
                .collect::<Vec<Vec<_>>>();
            let report = crate::source_contour_proposal::qualify_original_region(
                &context,
                surface,
                &boundaries,
                1e-8,
                crate::trimmed_face_recipe::Limits {
                    pairs: 1000,
                    region_cells: 10000,
                    domain_cells: 10000,
                    agreement_cells: 10000,
                },
            )
            .unwrap();
            let mut damaged = boundaries.clone();
            damaged[0][0].curve.control_points[0][0] += 1e-3;
            let refused = crate::source_contour_proposal::qualify_original_region(
                &context,
                surface,
                &damaged,
                1e-8,
                crate::trimmed_face_recipe::Limits {
                    pairs: 1000,
                    region_cells: 10000,
                    domain_cells: 10000,
                    agreement_cells: 10000,
                },
            )
            .unwrap();
            assert!(refused.region.is_none());
            assert!(
                report.region.is_some(),
                "{} / {}",
                report.reason,
                report.audit.reason
            );
            report.region.unwrap()
        })
        .collect::<Vec<_>>();
    let split_index=if curved {pairs.iter().position(|p|
        p.world.control_points.first().unwrap()[0]!=p.world.control_points.last().unwrap()[0]).unwrap()} else {0};
    let old = pairs.remove(split_index);
    for (i, address) in old.uses.iter().enumerate() {
        let edge = &faces[address.face][address.wire].edges()[address.edge];
        let c = edge.curve();
        let t = if i == 0 { 0.25 } else { 0.75 };
        let a = &c.control_points[0];
        let b = &c.control_points[1];
        let point = [a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])];
        let normal = [-(b[1] - a[1]), b[0] - a[0]];
        let cutter = if irrational {
            // q(t)=a+d*t+n*(t²-1/2), reflected along d on the other use.
            // The boundary root is sqrt(1/2), or 1-sqrt(1/2), not a
            // floating point authored parameter. All controls are dyadic.
            let controls = [(if i == 0 { 0. } else { 1. }, -0.5),
                (0.5, -0.5), (if i == 0 { 1. } else { 0. }, 0.5)]
                .map(|(along,across)| (0..2).map(|axis|
                    a[axis]+along*(b[axis]-a[axis])+across*normal[axis]
                ).collect());
            Curve { periodic:false,degree:2,knots:vec![0.,0.,0.,1.,1.,1.],
                control_points:controls.to_vec(),weights:vec![1.;3] }
        } else {
            Curve::from_polyline(vec![
                vec![point[0] - normal[0], point[1] - normal[1]],
                vec![point[0] + normal[0], point[1] + normal[1]],
            ]).unwrap()
        };
        if irrational {
            let broad = crate::source_contact_point::qualify(edge.surface(), c, &cutter, [[0.,1.];2], 10000).unwrap();
            assert!(broad.point.is_none());
        }
        let selector = if irrational {
            [if i == 0 { [0.7,0.71] } else { [0.29,0.3] }, [0.7,0.71]]
        } else { [[0.,1.];2] };
        let point_report = crate::source_contact_point::qualify(edge.surface(), c, &cutter, selector, 10000).unwrap();
        let p = point_report.point.expect(point_report.reason);
        assert!(
            regions[address.face]
                .split_boundary(address.wire, address.edge, &p, Role::Contact)
                .is_err()
        );
        regions[address.face] = regions[address.face]
            .split_boundary(address.wire, address.edge, &p, Role::Boundary)
            .unwrap();
        let parts = edge.split_at(&p, Role::Boundary).unwrap();
        assert_eq!(parts[0].curve(), c);
        assert_eq!(parts[1].curve(), c);
        let mut edges = faces[address.face][address.wire].edges().to_vec();
        edges.splice(address.edge..address.edge + 1, parts);
        faces[address.face][address.wire] = Wire::new(&edges).unwrap();
    }
    for pair in &mut pairs {
        for address in &mut pair.uses {
            for split in old.uses {
                if address.face == split.face
                    && address.wire == split.wire
                    && address.edge > split.edge
                {
                    address.edge += 1;
                }
            }
        }
    }
    let [a, b] = old.uses;
    pairs.push(Pair {
        uses: [
            a,
            Address {
                edge: b.edge + 1,
                ..b
            },
        ],
        world: old.world.clone(),
        world_reversed: old.world_reversed,
        cutters: [None, None],
    });
    pairs.push(Pair {
        uses: [
            Address {
                edge: a.edge + 1,
                ..a
            },
            b,
        ],
        world: old.world,
        world_reversed: old.world_reversed,
        cutters: [None, None],
    });
    let r = assemble_regions(&regions, &pairs, 100_000_000).unwrap();
    assert!(r.shell.is_some(), "{} {:?}", r.reason, r.uncertain_pair);
    let shell = r.shell.unwrap();
    crate::source_shell_restore::assert_replay(&shell);
    assert_eq!(shell.regions().unwrap().len(), 4);
    let network = crate::source_boundary_network::inspect(&shell, 14, 14).unwrap();
    assert_eq!(network.vertices.len(), 5);
    assert_eq!(network.endpoints, 14);
    assert_eq!(network.spans, 14);
    let root_vertex = network.vertices.iter().find(|v| v.ends.len() == 2).unwrap();
    if curved {
        assert!(shell.faces().iter().all(|face| face[0].edges()[0].surface().degree_u==2));
        assert!(shell.edges().iter().any(|edge|edge.world().degree==2));
        let display=crate::source_boundary_display::prepare(&shell,8,14,14).unwrap();
        assert_eq!(display.edges.len(),7);
        for [edge,end] in &root_vertex.ends {
            let bounds=shell.edges()[*edge].uses()[0].parameter_bounds();
            assert!(bounds.iter().any(|b|b[0]<b[1]));
            let _=end;
        }
        for face in shell.faces() {
            let report=crate::source_inverse_shear::qualify(face[0].edges()[0].surface(),[0,2],0.25,100000).unwrap();
            let certificate=report.certificate.expect(report.reason);
            for wire in face {for original in wire.edges() {
                let result=crate::source_inverse_shear::transport_fragment(&certificate,original,10000).unwrap();
                let inverse=result.fragment.expect(result.reason);
                assert_eq!(inverse.curve(),original.curve());
                assert_eq!(inverse.parameter_bounds(),original.parameter_bounds());
                assert_eq!(inverse.reversed(),original.reversed());
                assert_eq!(inverse.surface(),certificate.inverse());
                for (a,b) in original.endpoints().iter().zip(inverse.endpoints()) {
                    match (a,b) {
                        (Endpoint::Crossing {point:a,role:ar},Endpoint::Crossing {point:b,role:br})=>{
                            assert_eq!(ar,br);assert_eq!(a.boundary(),b.boundary());
                            assert_eq!(a.contact(),b.contact());assert_eq!(a.selector(),b.selector());
                            assert_ne!(a.world_box(),b.world_box());
                        },
                        (Endpoint::Parameter(a),Endpoint::Parameter(b))=>assert_eq!(a,b),
                        _=>panic!("Endpoint kind changed"),
                    }
                }
            }}
        }
        for source in shell.regions().unwrap() {
            let chart=crate::source_inverse_shear::qualify(source.loops()[0][0].surface(),[0,2],0.25,100000).unwrap();
            let certificate=chart.certificate.expect(chart.reason);
            let limits=crate::source_region_restore::Limits {
                region:crate::trimmed_face_recipe::Limits {pairs:1000,region_cells:10000,domain_cells:10000,agreement_cells:10000},
                search_cells:10000,point_checks:10000,mapping_cells:10000,driver_cells:10000,
                membership_cells:10000,controls:10000,winding_cells:10000,steps:64,
            };
            let exhausted=crate::source_inverse_shear::transport_region(&certificate,source,&limits,1).unwrap();
            assert!(exhausted.region.is_none());
            let transported=crate::source_inverse_shear::transport_region(&certificate,source,&limits,1000000).unwrap();
            let inverse=transported.region.expect(transported.reason);
            assert_eq!(inverse.source_loop_indices(),source.source_loop_indices());
            assert_eq!(inverse.loops().len(),source.loops().len());
            for (a,b) in source.loops().iter().flatten().zip(inverse.loops().iter().flatten()) {
                assert_eq!(a.curve(),b.curve());assert_eq!(a.parameter_bounds(),b.parameter_bounds());
                assert_eq!(a.reversed(),b.reversed());
            }
        }
        let replay_limits=crate::source_region_restore::Limits {
            region:crate::trimmed_face_recipe::Limits {pairs:1000,region_cells:10000,domain_cells:10000,agreement_cells:10000},
            search_cells:10000,point_checks:10000,mapping_cells:10000,driver_cells:10000,
            membership_cells:10000,controls:10000,winding_cells:10000,steps:64,
        };
        let inverse=crate::source_inverse_shear::transport_shell(&shell,[0,2],0.25,&replay_limits,100_000_000).unwrap();
        assert_eq!(inverse.root_checks,2);
        let inverse=inverse.shell.expect(inverse.reason);
        assert_eq!(inverse.vertices(),shell.vertices());
        assert_eq!(inverse.faces().len(),shell.faces().len());
        assert_eq!(inverse.edges().len(),shell.edges().len());
        let inverse_geometry=crate::source_shell_geometry::qualify(inverse,
            crate::source_shell_geometry::Limits {
                tolerance_uv:1e-8,corners:14,spans:1000,linear_cells:1000,
                pairs:crate::face_contacts::Limits {pairs:6,cells:10000,domain_cells:10000,
                    cells_per_pair:1000,domain_cells_per_pair:1000},
                exact_work:100_000_000,driver_cells:10000,
            }).unwrap();
        assert!(inverse_geometry.geometry.is_some(),"{}",inverse_geometry.reason);
        let replay_body_limits=|| crate::source_body_restore::Limits {
            shell:crate::source_shell_restore::Limits {
                regions:crate::source_region_restore::Limits {
                    region:crate::trimmed_face_recipe::Limits {pairs:1000,region_cells:10000,domain_cells:10000,agreement_cells:10000},
                    search_cells:10000,point_checks:10000,mapping_cells:10000,driver_cells:10000,
                    membership_cells:10000,controls:10000,winding_cells:10000,steps:64,
                },exact_work:100_000_000,driver_cells:10000,
            },
            embedding:crate::source_shell_geometry::Limits {
                tolerance_uv:1e-8,corners:14,spans:1000,linear_cells:1000,
                pairs:crate::face_contacts::Limits {pairs:6,cells:10000,domain_cells:10000,
                    cells_per_pair:1000,domain_cells_per_pair:1000},
                exact_work:100_000_000,driver_cells:10000,
            },
            volume:crate::source_volume::Limits {
                axis:2,origin:0.,absolute_error:0.02,tolerance_uv:1e-8,
                cells:10000,spans:100000,domain_cells:1000000,
            },
        };
        let primary=crate::source_shell_restore::restore(shell.definition().unwrap(),&replay_body_limits().shell).unwrap().shell.unwrap();
        let admitted=crate::source_shell_geometry::qualify(primary,
            crate::source_shell_geometry::Limits {
                tolerance_uv:1e-8,corners:14,spans:1000,linear_cells:1000,
                pairs:crate::face_contacts::Limits {pairs:6,cells:10000,domain_cells:10000,
                    cells_per_pair:1000,domain_cells_per_pair:1000},
                exact_work:100_000_000,driver_cells:10000,
            }).unwrap();
        // Closed incidence and injective charts cannot authorize unproven contacts.
        // The primary contact path still refuses; only a fresh inverse proof admits this fixture.
        assert!(admitted.geometry.is_none());
        assert_eq!(admitted.reason,"source-shell-different-face-contacts-unproven");
        let embedding=crate::source_shell_geometry::qualify_with_inverse_shear(shell,
            replay_body_limits().embedding,[0,2],0.25,&replay_limits).unwrap();
        assert!(embedding.geometry.is_some(),"{}",embedding.reason);
        let geometry=embedding.geometry.unwrap();
        let proof=geometry.inverse_shear().unwrap();
        assert_eq!(proof.axes(),[0,2]);assert_eq!(proof.coefficient(),0.25);
        assert!(proof.inverse().contacts().all_pairs_qualified);
        let volume=crate::source_volume::qualify(geometry,replay_body_limits().volume).unwrap();
        assert!(volume.body.is_some(),"{} {:?}",volume.reason,volume.signed_bounds);
        let body=volume.body.unwrap();
        assert!(body.volume()[0]<=1./6. && body.volume()[1]>=1./6.);
        for endpoint in body.geometry().shell().faces().iter().flatten().flat_map(|wire|wire.edges()).flat_map(|edge|edge.endpoints()) {
            if let Endpoint::Crossing {point,..}=endpoint {
                let refined=crate::source_root_refinement::qualify(point,1e-7,16,10000).unwrap();
                let proof=refined.refinement.expect(refined.reason);
                assert_eq!(proof.original().definition(),point.definition());
                assert!(proof.diameter_bound()[1]<=1e-7);
            }
        }
        eprintln!("curved Body volume {:?}; contact exact work {}, spans {}",body.volume(),embedding.exact_work,embedding.spans);
        assert_eq!(body.definition().unwrap()["inverseShear"],value_codec::json!({"axes":[0,2],"coefficient":0.25}));
        let exhausted=crate::source_exchange_endpoints::prepare(&body,1e-7,crate::source_exchange_endpoints::Limits {
            root_checks:1000,mapping_cells:10000,replay_mapping_per_use:10000,
            exact_work:1,driver_cells:10000,spans:14,endpoints:14,
        }).unwrap();
        assert!(exhausted.prepared.is_none());
        assert!(crate::source_exchange_endpoints::prepare(&body,1e-7,crate::source_exchange_endpoints::Limits {
            root_checks:1000,mapping_cells:10000,replay_mapping_per_use:10000,
            exact_work:100_000_000,driver_cells:10000,spans:14,endpoints:13,
        }).is_err());
        let prepared=crate::source_exchange_endpoints::prepare(&body,1e-7,crate::source_exchange_endpoints::Limits {
            root_checks:1000,mapping_cells:10000,replay_mapping_per_use:10000,
            exact_work:100_000_000,driver_cells:10000,spans:14,endpoints:14,
        }).unwrap();
        let endpoints=prepared.prepared.expect(prepared.reason);
        assert_eq!(endpoints.original(),&body.definition().unwrap());
        assert_eq!(endpoints.vertices().len(),5);assert_eq!(endpoints.restrictions().len(),7);
        for vertex in endpoints.vertices() {
            assert!(vertex.error_upper<=1e-7);
            for axis in 0..3 {assert!(vertex.point[axis]>=vertex.bounds[axis][0] && vertex.point[axis]<=vertex.bounds[axis][1]);}
        }
        for (index,restriction) in endpoints.restrictions().iter().enumerate() {
            assert_eq!(restriction.edge().world(),body.geometry().shell().edges()[index].world());
        }
        let trims=crate::source_exchange_trims::prepare(&body,&endpoints,1e-7,100000).unwrap().expect("bounded trim endpoints");
        assert_eq!(trims.edges().len(),7);
        for edge in trims.edges() {
            assert!(edge.canonical()[0]<edge.canonical()[1]);
            assert!(edge.error_upper().iter().flatten().all(|e|*e<=1e-7));
        }
        assert!(crate::source_exchange_trims::prepare(&body,&endpoints,1e-7,1).unwrap().is_none());
        assert!(crate::source_exchange_trims::prepare(&body,&endpoints,1e-30,100000).unwrap().is_none());
        // The AP242 candidate for this body is checked in cad-step
        // (tests/source_exchange_step.rs) from the definition this hook writes.
        if let Ok(path)=std::env::var("CAD_SOURCE_CURVED_DEFINITION_OUTPUT") {std::fs::write(path,value_codec::to_string(&body.definition().unwrap()).unwrap()).unwrap();}
        let definition=body.definition().unwrap();
        let restored=crate::source_body_restore::restore(definition.clone(),replay_body_limits()).unwrap();
        let replayed=restored.body().expect(restored.reason());
        assert_eq!(replayed.definition().unwrap(),definition);
        assert!(replayed.geometry().inverse_shear().is_some());
        let mut damaged=definition.clone();damaged["inverseShear"]["coefficient"]=value_codec::json!(0.5);
        assert!(crate::source_body_restore::restore(damaged,replay_body_limits()).unwrap().body().is_none());
        if let (Ok(template),Ok(output))=(std::env::var("CAD_CURVED_SHEAR_BODY_FIXTURE_TEMPLATE"),std::env::var("CAD_CURVED_SHEAR_BODY_FIXTURE_OUTPUT")) {
            let mut request=value_codec::from_str::<value_codec::Value>(&std::fs::read_to_string(template).unwrap()).unwrap();
            request["definition"]=definition.clone();
            std::fs::write(output,value_codec::to_string(&request).unwrap()).unwrap();
        }
        let mut omitted=definition;omitted.as_object_mut().unwrap().remove("inverseShear");
        assert!(crate::source_body_restore::restore(omitted,replay_body_limits()).unwrap().body().is_none());

        return;
    }
    assert!(root_vertex.poles.is_empty());
    for count in [1, 2, 8] {
        let preview = crate::source_boundary_display::prepare(&shell, count, 14, 14).unwrap();
        let mut common = None;
        for [edge, end] in &root_vertex.ends {
            let displayed = &preview.edges[*edge];
            assert_eq!(displayed.vertices[*end], root_vertex.id);
            let segment = &displayed.segments[if *end == 0 { 0 } else { count - 1 }];
            let point = segment.1[*end];
            if let Some(previous) = common { assert_eq!(point, previous); }
            common = Some(point);
            for axis in 0..3 {
                assert!(point[axis] >= root_vertex.bounds[axis][0]);
                assert!(point[axis] <= root_vertex.bounds[axis][1]);
                assert!(segment.2[axis][0] <= root_vertex.bounds[axis][0]);
                assert!(segment.2[axis][1] >= root_vertex.bounds[axis][1]);
            }
        }
    }
    assert!(crate::source_boundary_display::prepare(&shell, 0, 14, 14).is_err());
    assert!(crate::source_boundary_display::prepare(&shell, 4097, 14, 14).is_err());
    // Both halves keep their original carrier and independent root recipes.
    // The shared vertex enclosure must be inside each canonical end box.
    for [edge, end] in &root_vertex.ends {
        let restriction = crate::source_edge_restriction::Restriction::from_edge(
            &shell.edges()[*edge],
        );
        let parameter = restriction.parameter_bounds().unwrap()[*end];
        let domain = restriction.edge().world().domain();
        assert!(parameter[0] > domain[0] && parameter[1] < domain[1]);
        if irrational {
            assert!(parameter[0] < parameter[1]);
            assert!(restriction.edge().uses().iter().any(|fragment|
                fragment.endpoints().iter().any(|endpoint|
                    matches!(endpoint, crate::source_boundary_fragment::Endpoint::Crossing { .. }))));
        }
        // Root/mapped restrictions never gain literal canonical corner
        // authority through the trimmed planar endpoint shortcut.
        for (slot,address) in shell.uses()[*edge].iter().enumerate() {
            let fragment=&shell.edges()[*edge].uses()[slot];
            for endpoint in 0..2 {
                if shell.edges()[*edge].ranges().is_some()
                    || matches!(fragment.endpoints()[endpoint],crate::source_boundary_fragment::Endpoint::Crossing { .. }) {
                    assert!(crate::source_vertex_contact::carrier_corner(&shell,*address,endpoint).is_none());
                }
            }
        }
        let bounds = restriction.endpoint_boxes(2).unwrap()[*end];
        for axis in 0..3 {
            assert!(root_vertex.bounds[axis][0] >= bounds[axis][0]);
            assert!(root_vertex.bounds[axis][1] <= bounds[axis][1]);
        }
    }
    assert!(crate::source_boundary_network::inspect(&shell, 13, 14).is_err());
    assert!(crate::source_boundary_network::inspect(&shell, 14, 13).is_err());
    let topology = crate::source_vertex_links::inspect(&shell, 14).unwrap();
    assert!(topology.all_manifold);
    assert_eq!(topology.links.len(), 5);
    assert_eq!(topology.euler_characteristic, Some(2));
    assert_eq!(topology.genus, Some(0));
    assert_eq!(
        topology.links.iter().filter(|v| v.cycle.len() == 2).count(),
        1
    );
    for a in 0..4 {
        for b in a + 1..4 {
            let contact =
                crate::source_allowed_contact::certify(&shell, [a, b], 100_000_000, 2).unwrap();
            assert!(
                contact.certificate.is_some(),
                "{} faces {:?}",
                contact.reason,
                [a, b]
            );
        }
    }
    let mut fiber_pairs = 0;
    for a in 0..4 {
        for b in 0..4 {
            if a == b {
                continue;
            }
            let r = crate::source_fiber_contact::certify(&shell, [a, b], 100_000_000, 2, 10000)
                .unwrap();
            if let Some(c) = r.certificate {
                fiber_pairs += 1;
                assert_eq!(c.faces(), [a, b]);
                assert!(!c.edges().is_empty());
                assert_eq!(c.regions()[1].loops().len(), regions[b].loops().len());
                assert_eq!(c.fiber().surface(), regions[b].loops()[0][0].surface());
            }
        }
    }
    assert!(fiber_pairs > 0);
    let fiber_audit = crate::source_face_contacts::inspect_shell_with_boundary_fibers(
        &shell,
        1e-8,
        crate::face_contacts::Limits {
            pairs: 6,
            cells: 1,
            domain_cells: 1,
            cells_per_pair: 1,
            domain_cells_per_pair: 1,
        },
        100_000_000,
        128,
        10000,
    )
    .unwrap();
    assert!(fiber_audit.all_pairs_qualified);
    assert_eq!(fiber_audit.pairs.len(), 6);
    // The scheduler now selects the already proven shared-line proof
    // before fiber guesses; the direct fiber assertions above remain.
    assert!(fiber_audit.pairs.iter().all(|p| p.allowed.is_some()));
    assert_eq!(fiber_audit.cells, 0);
    let exhausted = crate::source_face_contacts::inspect_shell_with_boundary_fibers(
        &shell,
        1e-8,
        crate::face_contacts::Limits {
            pairs: 6,
            cells: 1,
            domain_cells: 1,
            cells_per_pair: 1,
            domain_cells_per_pair: 1,
        },
        1,
        128,
        10000,
    )
    .unwrap();
    assert!(!exhausted.all_pairs_qualified);
    assert!(exhausted.pairs.iter().all(|p| p.fiber.is_none()));
    assert!(exhausted.pairs[0].result.is_some());

    assert!(
        crate::source_fiber_contact::certify(&shell, [0, 1], 1, 2, 100)
            .unwrap()
            .certificate
            .is_none()
    );
    assert!(
        crate::source_fiber_contact::certify(&shell, [0, 1], 100_000_000, 1, 100)
            .unwrap()
            .certificate
            .is_none()
    );
    let allowed = crate::source_face_contacts::inspect_shell_with_allowed(
        &shell,
        1e-8,
        crate::face_contacts::Limits {
            pairs: 6,
            cells: 1,
            domain_cells: 1,
            cells_per_pair: 1,
            domain_cells_per_pair: 1,
        },
        100_000_000,
        12,
    )
    .unwrap();
    assert!(allowed.all_pairs_qualified);
    assert!(!allowed.all_pairs_absence_proven);
    assert_eq!(allowed.pairs.len(), 6);
    assert_eq!(allowed.cells, 0);
    assert!(
        allowed
            .pairs
            .iter()
            .all(|p| p.allowed.is_some() && p.result.is_none())
    );
    let limited = crate::source_face_contacts::inspect_shell_with_allowed(
        &shell,
        1e-8,
        crate::face_contacts::Limits {
            pairs: 1,
            cells: 1,
            domain_cells: 1,
            cells_per_pair: 1,
            domain_cells_per_pair: 1,
        },
        1,
        1,
    )
    .unwrap();
    assert!(!limited.all_pairs_qualified);
    assert!(limited.pairs[0].allowed.is_none());
    assert!(
        limited.pairs[0]
            .result
            .as_ref()
            .is_some_and(|r| !r.absence_proven)
    );
    let stopped = crate::source_allowed_contact::certify(&shell, [0, 1], 1, 2).unwrap();
    assert!(stopped.certificate.is_none() && stopped.exact_work <= 1);
    let stopped =
        crate::source_allowed_contact::certify(&shell, [0, 1], 100_000_000, 1).unwrap();
    assert!(stopped.certificate.is_none());
    assert!(shell.inspect_face_charts(4, 0).unwrap().all_injective);
    let pairs = crate::source_face_contacts::inspect_shell(
        &shell,
        1e-8,
        crate::face_contacts::Limits {
            pairs: 1,
            cells: 2,
            domain_cells: 2,
            cells_per_pair: 1,
            domain_cells_per_pair: 1,
        },
    )
    .unwrap();
    assert_eq!(pairs.total_pairs, 6);
    assert_eq!(pairs.pairs.len(), 1);
    assert_eq!(pairs.pairs[0].faces, [0, 1]);
    assert_eq!(pairs.next_pair, Some([0, 2]));
    assert!(!pairs.all_pairs_absence_proven);
    assert!(
        !pairs.pairs[0]
            .result
            .as_ref()
            .unwrap()
            .unresolved
            .is_empty()
    );
    for (face, region) in shell.regions().unwrap().iter().enumerate() {
        assert_eq!(region.source_loop_indices(), &[0]);
        for (i, edge) in region.loops()[0].iter().enumerate() {
            assert_eq!(
                edge.definition(),
                shell.faces()[face][0].edges()[i].definition()
            );
        }
    }
    assert_eq!(shell.edges().len(), 7);
    let owners: std::collections::BTreeSet<_> = shell
        .vertices()
        .iter()
        .flatten()
        .flatten()
        .flatten()
        .copied()
        .collect();
    assert_eq!(owners.len(), 5);
    for pair in shell.uses() {
        let vertex = |a: Address| shell.vertices()[a.face][a.wire][a.edge];
        assert_eq!(vertex(pair[0]), [vertex(pair[1])[1], vertex(pair[1])[0]]);
    }
    let admitted = crate::source_shell_geometry::qualify(
        shell,
        crate::source_shell_geometry::Limits {
            tolerance_uv: 1e-8,
            corners: 14,
            spans: 1000,
            linear_cells: 1000,
            pairs: crate::face_contacts::Limits {
                pairs: 6,
                cells: 10000,
                domain_cells: 10000,
                cells_per_pair: 1000,
                domain_cells_per_pair: 1000,
            },
            exact_work: 100_000_000,
            driver_cells: 10000,
        },
    )
    .unwrap();
    assert!(admitted.geometry.is_some(), "{}", admitted.reason);
    let geometry = admitted.geometry.unwrap();
    assert_eq!(geometry.topology().genus, Some(0));
    let volume = crate::source_volume::qualify(
        geometry,
        crate::source_volume::Limits {
            axis: 2,
            origin: 0.,
            absolute_error: 0.02,
            tolerance_uv: 1e-8,
            cells: 10000,
            spans: 100000,
            domain_cells: 1000000,
        },
    )
    .unwrap();
    assert!(
        volume.body.is_some(),
        "{} {:?}",
        volume.reason,
        volume.signed_bounds
    );
    let body = volume.body.unwrap();
    assert!(crate::source_body_model::convert(&body, 1e-7).is_err());
    let source_model = crate::source_body_topology::convert(&body, 1e-7, 14, 14).unwrap();
    assert_eq!(source_model.definition(), &body.definition().unwrap());
    let indexed = source_model.topology();
    assert_eq!(indexed.vertices.len(), 5);
    assert_eq!(indexed.edges.len(), 7);
    for (i,edge) in indexed.edges.iter().enumerate() {
        let crate::source_body_topology::Carrier::Edge(restriction) = &edge.curve else { panic!("Unexpected pole"); };
        assert_eq!(restriction.definition(), body.edge_restriction(i).unwrap().definition());
    }
    for (face,wires) in body.geometry().shell().faces().iter().enumerate() {
        for (wire,source) in wires.iter().enumerate() {
            let loop_index = if wire == 0 { indexed.faces[face].outer } else { indexed.faces[face].holes[wire-1] };
            for (edge,fragment) in source.edges().iter().enumerate() {
                assert_eq!(indexed.loops[loop_index].coedges[edge].pcurve.definition(), fragment.definition());
            }
        }
    }
    assert!(crate::source_body_topology::convert(&body, 0., 14, 14).is_err());
    assert!(crate::source_body_topology::convert(&body, 1e-7, 13, 14).is_err());
    let seam_limits = || crate::source_seam_tangency::Limits {
        max_sine_squared: 1e-6,
        cells: 100,
        curve_spans: 200,
        normal_spans: 200,
    };
    // A valid tetrahedron is intentionally sharp; volume admission must
    // not silently label its selected shared edge tangent.
    assert!(
        body.qualify_edge_tangency(0, seam_limits())
            .unwrap()
            .seam
            .is_none()
    );
    assert!(
        body.qualify_edge_tangency(body.geometry().shell().edges().len(), seam_limits())
            .is_err()
    );
    let center = Curve::from_polyline(vec![vec![0., 0., 0.], vec![0., 0., 0.]]).unwrap();
    let radius = Curve::from_polyline(vec![vec![1., 0.], vec![1., 0.]]).unwrap();
    assert!(
        body.qualify_face_radius(0, &center, &radius, 1e-6, 100, 100_000_000)
            .unwrap()
            .certificate
            .is_none()
    );
    assert!(
        body.qualify_face_radius(
            body.geometry().shell().faces().len(),
            &center,
            &radius,
            1e-6,
            100,
            100_000_000
        )
        .is_err()
    );
    let bounds = body.volume();
    assert!(bounds[0] <= 1. / 6. && 1. / 6. <= bounds[1]);
    assert!(!body.reverse_orientation());
    if irrational {
        if let Some(path) = std::env::var_os("CAD_IRRATIONAL_BODY_FIXTURE_OUTPUT") {
            let template = std::env::var_os("CAD_IRRATIONAL_BODY_FIXTURE_TEMPLATE").unwrap();
            let mut request: value_codec::Value = value_codec::from_str(&std::fs::read_to_string(template).unwrap()).unwrap();
            request["definition"] = body.definition().unwrap();
            std::fs::write(path, value_codec::to_string(&request).unwrap()).unwrap();
        }
    }
}
#[test]
fn chart_audit_catches_folded_geometry_even_when_exact_boundary_incidence_closes() {
    let (mut faces, pairs) = tetrahedron();
    let shell = assemble(&faces, &pairs, 100_000_000)
        .unwrap()
        .shell
        .unwrap();
    let charts = shell.inspect_face_charts(4, 0).unwrap();
    assert!(charts.all_injective);
    assert_eq!(charts.spans, 4);
    let stopped = shell.inspect_face_charts(1, 0).unwrap();
    assert!(!stopped.all_injective);
    assert_eq!(stopped.spans, 1);
    assert_eq!(stopped.faces.len(), 4);
    assert!(stopped.faces[1].contraction.is_none());
    let s = faces[0][0].edges()[0].surface();
    let a = &s.control_points[0][0];
    let b = &s.control_points[1][0];
    let c = &s.control_points[0][1];
    // Affine face plus exact polynomial bubble 16*u*v*(1-u-v)
    // in its u direction. All three original triangle boundaries stay
    // unchanged while an interior directional derivative changes sign.
    let controls = (0..3)
        .map(|i| {
            (0..3)
                .map(|j| {
                    let u = i as f64 / 2.;
                    let v = j as f64 / 2.;
                    let delta = 16.
                        * (u * v - if i == 2 { v } else { 0. } - if j == 2 { u } else { 0. });
                    (0..3)
                        .map(|k| a[k] + (u + delta) * (b[k] - a[k]) + v * (c[k] - a[k]))
                        .collect()
                })
                .collect()
        })
        .collect();
    let folded = Surface {
        degree_u: 2,
        degree_v: 2,
        knots_u: vec![0., 0., 0., 1., 1., 1.],
        knots_v: vec![0., 0., 0., 1., 1., 1.],
        control_points: controls,
        weights: vec![vec![1.; 3]; 3],
        periodic_u: false,
        periodic_v: false,
    };
    assert_eq!(
        folded.evaluate(0.375, 0.25).unwrap().point,
        folded.evaluate(0.625, 0.25).unwrap().point
    );
    let edges: Vec<_> = faces[0][0]
        .edges()
        .iter()
        .map(|e| {
            Fragment::new(
                &folded,
                e.curve(),
                e.endpoints()[0].clone(),
                e.endpoints()[1].clone(),
            )
            .unwrap()
        })
        .collect();
    faces[0][0] = Wire::new(&edges).unwrap();
    let r = assemble(&faces, &pairs, 100_000_000).unwrap();
    assert!(r.shell.is_some(), "{} {:?}", r.reason, r.uncertain_pair);
    let charts = r.shell.unwrap().inspect_face_charts(4, 0).unwrap();
    assert!(!charts.all_injective);
    assert!(!charts.faces[0].injectivity_proven());
    assert!(charts.faces[1..].iter().all(|f| f.injectivity_proven()));
    let context = cad_predicates::ToleranceContext::default_valid();
    let regions = faces
        .iter()
        .enumerate()
        .map(|(face, wires)| {
            let boundaries = wires
                .iter()
                .enumerate()
                .map(|(wire, w)| {
                    w.edges()
                        .iter()
                        .enumerate()
                        .map(|(edge, e)| {
                            let address = Address { face, wire, edge };
                            let p = pairs.iter().find(|p| p.uses.contains(&address)).unwrap();
                            let index = p.uses.iter().position(|a| *a == address).unwrap();
                            let mut world = p.world.clone();
                            if p.world_reversed[index] {
                                world.control_points.reverse();
                                world.weights.reverse();
                            }
                            crate::trimmed_face_recipe::Boundary {
                                curve: world,
                                pcurve: e.curve().clone(),
                                reversed: false,
                            }
                        })
                        .collect::<Vec<_>>()
                })
                .collect::<Vec<_>>();
            let r = crate::source_contour_proposal::qualify_original_region(
                &context,
                wires[0].edges()[0].surface(),
                &boundaries,
                1e-8,
                crate::trimmed_face_recipe::Limits {
                    pairs: 10000,
                    region_cells: 10000,
                    domain_cells: 10000,
                    agreement_cells: 10000,
                },
            )
            .unwrap();
            assert!(r.region.is_some(), "face {} {}", face, r.reason);
            r.region.unwrap()
        })
        .collect::<Vec<_>>();
    let shell = assemble_regions(&regions, &pairs, 100_000_000)
        .unwrap()
        .shell
        .unwrap();
    let admission = crate::source_shell_geometry::qualify(
        shell,
        crate::source_shell_geometry::Limits {
            tolerance_uv: 1e-8,
            corners: 12,
            spans: 1000,
            linear_cells: 0,
            pairs: crate::face_contacts::Limits {
                pairs: 6,
                cells: 10000,
                domain_cells: 10000,
                cells_per_pair: 1000,
                domain_cells_per_pair: 1000,
            },
            exact_work: 100_000_000,
            driver_cells: 10000,
        },
    )
    .unwrap();
    assert!(admission.geometry.is_none());
    assert_eq!(admission.reason, "source-shell-chart-injectivity-unproven");
    assert_eq!(admission.pairs, 0);
    assert_eq!(admission.uncertain_face, Some(0));
}
#[test]
fn disconnected_closed_components_and_exhausted_work_are_not_a_shell() {
    let (mut faces, mut pairs) = tetrahedron();
    let stopped = assemble(&faces, &pairs, 1).unwrap();
    assert!(stopped.shell.is_none() && stopped.uncertain_pair.is_some());
    assert!(stopped.work_used <= 1);
    let (other, mut more) = tetrahedron();
    for pair in &mut more {
        for address in &mut pair.uses {
            address.face += faces.len();
        }
    }
    faces.extend(other);
    pairs.extend(more);
    let r = assemble(&faces, &pairs, 100_000_000).unwrap();
    assert!(r.shell.is_none());
    assert_eq!(r.reason, "source-shell-disconnected");
}
#[test]
fn exact_geometry_mismatch_never_produces_partial_shell() {
    let (faces, mut pairs) = tetrahedron();
    pairs[0].world.control_points[0][0] += 1e-12;
    let r = assemble(&faces, &pairs, 100_000_000).unwrap();
    assert!(r.shell.is_none());
    assert_eq!(r.uncertain_pair, Some(0));
}
