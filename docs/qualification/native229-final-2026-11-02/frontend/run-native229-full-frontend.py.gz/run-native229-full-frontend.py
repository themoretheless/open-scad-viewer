from pathlib import Path
import json,hashlib,subprocess,os,datetime
q=Path('/Users/themoretheless/.codex/tmp/architecture-recovery-20261031');own=json.loads(Path('docs/qualification/own-rust-cad-v86.json').read_text());node=q/'node-runtime-22.23.4/node-v22.23.4-darwin-arm64/bin/node'
def source_hash():
 h=hashlib.sha256()
 for p in own['sourceBundle']['paths']:h.update(p.encode()+b'\0'+Path(p).read_bytes()+b'\n')
 return h.hexdigest()
assert source_hash()==own['sourceBundle']['sha256']
wasm=Path('public/wasm/geometry-kernel.wasm');assert hashlib.sha256(wasm.read_bytes()).hexdigest()==own['wasm']['sha256']
state={'sourceRecord':'OwnRust86','sourceSha256':own['sourceBundle']['sha256'],'wasmSha256':own['wasm']['sha256'],'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'terminal':False,'maxWorkers':2,'testTimeout':90000,'qualificationClaim':'none'}
p=q/'native229-full-frontend-state.json';p.write_text(json.dumps(state,indent=2)+'\n');env=dict(os.environ,VITEST_MAX_WORKERS='2')
with (q/'native229-full-frontend.log').open('wb') as out:
 result=subprocess.run(['caffeinate','-i',str(node),'node_modules/vitest/vitest.mjs','run','--testTimeout','90000','--reporter','default','--reporter','json','--outputFile.json',str(q/'native229-full-frontend.json')],env=env,stdout=out,stderr=subprocess.STDOUT)
state.update(terminal=True,exitCode=result.returncode,endedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceUnchanged=source_hash()==own['sourceBundle']['sha256'],artifactUnchanged=hashlib.sha256(wasm.read_bytes()).hexdigest()==own['wasm']['sha256']);p.write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(state));raise SystemExit(result.returncode or (0 if state['sourceUnchanged'] and state['artifactUnchanged'] else 1))
